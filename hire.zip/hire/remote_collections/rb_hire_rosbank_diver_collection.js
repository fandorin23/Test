//������� ���������� � �������
/*
	<wvars>
		<wvar>
			<name>type</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>person_id</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>kurator_id</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>status_id</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>fullname</name>
			<type>string</type>
			<position>5</position>
		</wvar>
		<wvar>
			<name>region</name>
			<type>string</type>
			<position>6</position>
		</wvar>
	</wvars>
*/

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable indent */
RESULT = new Array();
arr_kurators = new Array();
		
function get_kurator_fullname( kur_id )
{
	kur_id = OptInt( kur_id );
	if( kur_id == undefined )
		return "";
	kur = ArrayOptFind( arr_kurators, "This.id == " + kur_id );
	if( kur == undefined )
	{
		try
		{
			kur = OpenDoc( UrlFromDocID( kur_id ) ).TopElem;
		}
		catch( ex )
		{
			return "";
		}
		arr_kurators.push( { id: kur_id, top_elem: kur } );
	}
	else
		kur = kur.top_elem;
				
	return kur.fullname;
}

switch( type )
{
	case "subdivision":
		arrRegions = new Array();
		arrRegions = XQuery( "for $i in places where contains( $i/name, '" + region + "' ) return $i" );	
		xarrSubdivisions = XQuery( "for $i in subdivisions where doc-contains( $i/id, 'wt_data', '[in_business=true]' )  and MatchSome( $i/place_id, ( " + ArrayMerge( arrRegions, "This.id", "," ) + " ) ) return $i" );
		if( ArrayOptFirstElem( xarrSubdivisions ) != undefined )
		{
			xarrSubGroupSubs = ArraySelectAll( XQuery( "for $i in subdivision_group_subdivisions where MatchSome( $i/subdivision_id, ( " + ArrayMerge( xarrSubdivisions, "This.id", "," ) + " ) ) and contains( $i/code, '!hire_diver' ) return $i" ), "This.subdivision_id" );
			//RESULT = ArrayExtract( ArraySelectDistinct( xarrSubGroupSubs, "This.subdivision_id" ), "{id: This.subdivision_id.Value,name: This.subdivision_name.Value, vertical: This.name.Value }" );
			xarrPositions = XQuery( "for $i in positions where ( $i/position_date = null() or $i/position_date <= date( '" + Date() + "' ) ) and ( $i/position_finish_date = null() or $i/position_finish_date > date( '" + Date() + "' ) ) and  $i/is_boss = true() and MatchSome( $i/parent_object_id, ( " + ArrayMerge( xarrSubdivisions, "This.id", "," ) + " ) ) return $i" );
			for( elem in  ArrayIntersect( xarrSubdivisions, xarrPositions, "This.id", "This.parent_object_id" ) )
			{
				obj = new Object();
				obj.id = elem.id.Value;
				obj.name = elem.name.Value;
				gs = ArrayOptFind( xarrSubGroupSubs, "This.subdivision_id == elem.id" )
				obj.vertical = gs != undefined ? gs.name.Value : "";
				obj.region = elem.place_id.HasValue ? elem.place_id.ForeignElem.name.Value : "";
				RESULT.push( obj );
			}
		}
		break;
		
	case "my":
		function get_status( top_elem, req )
		{
			switch( req.workflow_state )
			{
				case "reject":
					if( top_elem == null )
						top_elem = OpenDoc( UrlFromDocID( req.id ) ).TopElem;
					wl = ArrayOptFirstElem( ArraySort( top_elem.workflow_log_entrys, "This.create_date", "-" ) );
					if( wl == undefined )
						return req.workflow_state_name.Value;
					if( wl.begin_state == "manager" )
						return "��������� �������������";
					else if( wl.begin_state == "subdivision" )
						return "��������� � �������������";
					else
						return req.workflow_state_name.Value;
					
				default:
					return req.workflow_state_name.Value;
			}
		}
		requestTypeID = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_diver_request' return $i" ) ).id;
		conds = new Array();
		//conds.push( "( $i/person_id = " + curUserID + " or doc-contains( $i/id, 'wt_data', '[kurator_id=" + curUserID + "]' ) )" );
		conds.push( "( $i/person_id = " + curUserID + " )" );
		conds.push( "$i/request_type_id = " + requestTypeID );
		if( OptInt( person_id ) != undefined )
			conds.push( "$i/person_id = " + person_id );
			
		if( OptInt( kurator_id ) != undefined )
			conds.push( "doc-contains( $i/id, 'wt_data', '[kurator_id=" + kurator_id + "]' )" );
			
		xarrRequests = XQuery( "for $i in requests where " + ArrayMerge( conds, "This", " and " ) + " return $i" );
		
		for( elem in xarrRequests )
		{
			teRequest = null;
			obj = new Object();
			obj.id = elem.id.Value;
			obj.create_date = StrDate( elem.create_date, false );
			obj.code = elem.code.Value;
			obj.person_fullname = elem.person_fullname.Value;
			obj.subdivision_name = elem.object_name.Value;
			kurator_fullname = "";
			if( OptInt( kurator_id ) != undefined )
				kurator_fullname = get_kurator_fullname( OptInt( kurator_id ) );
			else
			{
				teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
				kurator_fullname = get_kurator_fullname( teRequest.custom_elems.ObtainChildByKey( "kurator_id" ).value );
			}
			obj.kurator_fullname = String( kurator_fullname );
			obj.workflow_state_name = get_status( teRequest, elem ); elem.workflow_state_name.Value;
			RESULT.push( obj );
		}
		RESULT = ArraySort( RESULT, "Date( This.create_date )", "-" );
		break;
		
	case "sogl":
	
		function check_sogl( top_elem )
		{
			return ArrayOptFind( top_elem.workflow_log_entrys, "This.person_id == curUserID && ( This.finish_state == 'subdivision' || This.finish_state == 'sogl' || This.finish_state == 'sogl_and_send'  ) " ) != undefined;
		}
		function check_reject( top_elem )
		{
			return ArrayOptFind( top_elem.workflow_log_entrys, "This.person_id == curUserID" ) != undefined;
		}
		requestTypeID = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_diver_request' return $i" ) ).id;
		
		
		xarrRequests = new Array();
		status_name = "";
		arr_status = new Array();
		if( OptInt( status_id ) != undefined )
			arr_status.push( status_id );
		else
			arr_status = new Array( 0, 1, 2 );

		dop_cond = "";
		if( fullname != "" )
			dop_cond = " and contains( $i/person_fullname, '" + fullname + "' ) ";
		for( status in arr_status )
		{
			conds = new Array();
			switch( Int( status ) )
			{
				case 0:
					status_name = "�����";
					xarrPositions = XQuery( "for $i in positions where $i/basic_collaborator_id = " + curUserID + " and ( $i/position_date = null() or $i/position_date <= date( '" + Date() + "' ) ) and ( $i/position_finish_date = null() or $i/position_finish_date > date( '" + Date() + "' ) ) and  $i/is_boss = true() return $i" );
					conds.push( " $i/workflow_state = 'manager' " );
					if( ArrayOptFirstElem( xarrPositions ) != undefined )
						conds.push( " ( $i/workflow_state = 'subdivision' and MatchSome( $i/object_id, ( " + ArrayMerge( xarrPositions, "This.parent_object_id", "," ) + " ) ) ) " );
					xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + requestTypeID + " and ( " + ArrayMerge( conds, "This", " or " ) + " ) " + dop_cond + " return $i" );
					break;
				
				case 1:
					status_name = "�����������";
					conds.push( " $i/workflow_state = 'subdivision' " );
					conds.push( " ( $i/workflow_state = 'sogl' or $i/workflow_state = 'sogl_and_send' ) " );
					xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + requestTypeID + " and ( " + ArrayMerge( conds, "This", " or " ) + " ) " + dop_cond + " return $i" );
					break;
				case 2:
					status_name = "���������";
					conds.push( " $i/workflow_state = 'reject' " );
					xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + requestTypeID + " and ( " + ArrayMerge( conds, "This", " or " ) + " ) " + dop_cond + " return $i" );
					break;
			}
			for( elem in xarrRequests )
			{
				obj = new Object();
				obj.id = elem.id.Value;
				obj.create_date = StrDate( elem.create_date, false );
				obj.sort_create_date = elem.create_date;
				obj.code = elem.code.Value;
				obj.person_fullname = elem.person_fullname.Value;
				pers = elem.person_id.OptForeignElem;
				obj.person_subdivision_name = pers != undefined ? pers.position_parent_name.Value : "";
				obj.subdivision_name = elem.object_name.Value;
				kurator_fullname = "";
				teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;

				switch( Int( status ) )
				{
					case 0:
						if( elem.workflow_state == "manager" )
						{
							if( OptInt( teRequest.workflow_fields.ObtainChildByKey( "manager_id" ).value ) != curUserID )
								continue;
						}
						break;
					case 1:

						if( !( ( teRequest.workflow_state == "sogl" || teRequest.workflow_state == "sogl_and_send" ) && OptInt( teRequest.workflow_fields.ObtainChildByKey( "kurator_id" ).value ) == curUserID ) && !check_sogl( teRequest ) )
							continue;
						break;

					case 2:
						if( !check_reject( teRequest ) )
							continue;
						break;
				}

				kurator_fullname = get_kurator_fullname( teRequest.custom_elems.ObtainChildByKey( "kurator_id" ).value );
				obj.kurator_fullname = String( kurator_fullname );
				obj.workflow_state_name = status_name;
				RESULT.push( obj );
			}
		}
		RESULT = ArraySelectDistinct( RESULT, "This.id" );
		RESULT = ArraySort( RESULT, "Date( This.sort_create_date )", "-" );
		break;
}