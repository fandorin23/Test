//������� ������������� ��� ��������

/*
	<wvars>
		<wvar>
			<name>search</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>xquery</name>
			<type>string</type>
			<position>2</position>
		</wvar>
	</wvars>
*/

function get_childs( parent_id, type )
{
	//alert( "tree_subdivision_rosbank get_childs " + parent_id );

	//for( elem in ArraySelect( arr_subd, "OptInt( This." + ( type == "org" ? "org_id" : "parent_object_id" ) + " ) == OptInt( '" + parent_id + "' )" +  ( type == "org" ? " && OptInt( This.parent_object_id ) == undefined" : "" ) ) )
	for( elem in XQuery( "for $i in subdivisions where $i/" + ( type == "org" ? "org_id" : "parent_object_id" ) + " = " + parent_id + ( type == "org" ? " and $i/parent_object_id = null()" : "" )  +  " and $i/is_disbanded != true() return $i" ) )
	{
		obj = new Object();
		obj.id = elem.id.Value;
		obj.parent_id = parent_id;
		obj.name = elem.name.Value;
		if( elem.is_disbanded )
		{
			obj.name += " [ �������������� ]";
		}
		obj.icon = ( elem.is_disbanded ? "/ico/subdivision_gray.ico" : "/ico/subdivision.ico" );
		RESULT.push( obj );
		get_childs( elem.id.Value, "" );
	}
	//alert( "tree_subdivision_rosbank get_childs finish " + parent_id );
}

function get_parent( el, type, b )
{
	if( el == undefined )
		return
	obj = new Object();
	obj.id = el.id.Value;
	obj.parent_id = ( type == "sub" && el.parent_object_id.HasValue ? el.parent_object_id.Value : ( type == "sub" ? el.org_id.Value : "" ) );
	obj.name = el.name.Value;	
	if( type == "sub" && el.is_disbanded )
	{
		dSub = OpenDoc( UrlFromDocID( el.id ) ).TopElem
		if( b && dSub.disbanded_date < Date() )
			return
		obj.name += " [ �������������� " + StrDate( dSub.disbanded_date.Value, false, false ) + " ]";
	}
	obj.isExpanded = true;
	if( type == "sub" )
		obj.icon = ( el.is_disbanded ? "/ico/subdivision_gray.ico" : "/ico/subdivision.ico" );
	else
		obj.icon =  "/ico/org.ico";
	RESULT.push( obj );
	if( type == "sub" && el.parent_object_id.HasValue )
		get_parent( el.parent_object_id.ForeignElem, "sub", false );
	else if( type == "sub" )
		get_parent( ArrayOptFirstElem( XQuery( "for $i in orgs where $i/id = " + el.org_id + " return $i" ) ), "org", false );
}

//alert( "tree_subdivision_rosbank start" );

//alert( "tree_subdivision_rosbank get arr" );
RESULT = new Array();
if( search == "" && xquery == "" )
	for( org in XQuery( "for $i in orgs return $i" ) )
	{
		obj = new Object();
		obj.id = org.id.Value;
		obj.parent_id = "";
		obj.name = org.disp_name.Value;
		obj.icon =  "/ico/org.ico";
		RESULT.push( obj );
		//get_childs( org.id.Value, "org" );
		//for( elem in XQuery( "for $i in subdivisions where $i/org_id = " + org.id  +  " and $i/is_disbanded != true() return $i" ) )
		for( elem in XQuery( "sql: select s.id, s.name, s.parent_object_id, s.is_disbanded, su.data.value( '(subdivision/disbanded_date)[1]', 'nvarchar(max)' ) as disbanded_date from subdivisions s inner join subdivision su on su.id = s.id where s.is_disbanded = 0 and s.org_id = " + org.id ) )
		{
			if( elem.disbanded_date.HasValue && Date( elem.disbanded_date ) < Date() )
				continue;
			obj = new Object();
			obj.id = elem.id.Value;
			obj.parent_id = elem.parent_object_id.HasValue ? elem.parent_object_id.Value : org.id.Value;
			obj.name = elem.name.Value;
			if( elem.disbanded_date.HasValue )
			{
				obj.name += " [ �������������� " + elem.disbanded_date + " ]";
			}
			obj.icon = ( elem.is_disbanded ? "/ico/subdivision_gray.ico" : "/ico/subdivision.ico" );
			RESULT.push( obj );
			//get_childs( elem.id.Value, "" );
		}
	}
else
{
	for( elem in XQuery( "for $i in subdivisions where contains( $i/name, '" + search + "' ) " + ( xquery != "" ? " and " + UrlDecode( xquery ) : "" ) + " return $i" ) )
	{
		get_parent( elem, "sub", true );
		get_childs( elem.id.Value, "" );
	}
	RESULT = ArraySelectDistinct( RESULT, "This.id" );
}