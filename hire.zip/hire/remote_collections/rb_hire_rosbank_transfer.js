//������� ��� ���������
/*
	<wvars>
		<wvar>
			<name>type</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>status_id</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>request_sogl_code</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>fullname</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>manager_fullname</name>
			<type>string</type>
			<position>5</position>
		</wvar>
	</wvars>
*/

function workflow_state_name( name )
{
	switch( name )
	{
		case "hr":
		case "hr_go":
		case "hr_go_net":
			return "� HR-��������";
		case "complete":
		case "complete_ur":
			return "�������";
		case "draft":
			return "��������";
		case "cuchr":
		case "cuchr_go":
			return "� HR-������";
		case "im":
			return "� Int.Mobility";
		case "dmto":
			return "� ���";
		case "ukil":
			return "� ����";
		case "person":
			return "� ����������";
		case "sogl_manager":
			return "� ������������";
		case "candidate":
			return "����� ���������";
		case "cancel":
			return "��������";
		case "sv_hr":
			return "��+HR-�������";
		case "sb":
			return "������ ������������";
		case "podbor":
			return "� ������";
		case "reject":
			return "���������";

		case "staff":
			return "� �������������� �� ��";
	}
	return "";
}
function get_value( name, doc )
{
	if( doc.workflow_fields.GetOptChildByKey( name ) != undefined )
		return doc.workflow_fields.GetOptChildByKey( name ).value.Value;
	else if( doc.custom_elems.GetOptChildByKey( name ) != undefined )
		return doc.custom_elems.GetOptChildByKey( name ).value.Value;
	else
		return "";
}

function isSogl( doc )
{
	arr = ArraySelect( doc.workflow_log_entrys, "This.person_id == " + curUserID );
	if( ArrayOptFirstElem( arr ) == undefined )
		return false;
	last = ArrayMax( arr, "This.create_date" );
	if( last.finish_state != "reject" && last.finish_state != "draft" )
		return true;
		
	return false;
}

function isReject( doc )
{
	arr = ArraySelect( doc.workflow_log_entrys, "This.person_id == " + curUserID );
	if( ArrayOptFirstElem( arr ) == undefined )
		return false;
	last = ArrayMax( arr, "This.create_date" );
	if( last.finish_state == "reject" )
		return true;
		
	return false;
}
function get_state( doc )
{
	//alert( get_state )
	if( doc.workflow_state == "cancel" )
		return ( "��������" );
	if( isSogl( doc ) )
		return ( "�����������" );
	if( isReject( doc ) )
		return ( "���������" );
	return "�����";
}
function get_state_name( status_id )
{
	if( status_id == "new" )
		return "�����";
	if( status_id == "cancel" )
		return ( "��������" );
	if( status_id == "sogl" )
		return ( "�����������"  );
	if( status_id == "reject" )
		return ( "���������" );
}

function get_status_reject_cancel( doc )
{
	log_states = new Array();
	if( doc.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
	{
		//alert( doc.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value );
		log_states = OpenDocFromStr( doc.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
	}
	m = undefined
	if( ArrayOptFirstElem( log_states ) != undefined )
		m = ArrayMax( log_states, "This.ChildIndex" )
		//m = ArrayMin( log_states, "This.ChildExists( 'create_date' ) && This.create_date.HasValue ? DateDiff( Date(), Date( This.create_date ) ) : 99999999999" )
		
	//if( m != undefined )
	//	alert( m.Xml )
	return ( m != undefined && m.ChildExists( "finish_state" ) ? ( m.finish_state == "reject" ? ( "���������" ) : (  "��������" ) ) : "" );
}

function check_group( arr, code )
{
	if( code == "international_mobility" )
		return ArrayOptFind( arr, "This.code == '" + code + "'" ) != undefined;
	if( get_value( "podbor_for", dRequest ) == "net"  && code == "hr" )
		return ArrayOptFind( arr, "This.code == '" + code + "_go_net'" ) != undefined;
	else if( get_value( "podbor_for", dRequest ) == "go"  && code == "hr" )
		return ArrayOptFind( arr, "This.code == '" + code + "_go'" ) != undefined;
	else
	{
		return ArrayOptFind( arr, "This.code == '" + code + "_" + ( get_value( "hub_id", dRequest ) ) + "'" ) != undefined;
	}

}
function check_group_sb( arr, code )
{
	if( code == "international_mobility" )
		return ArrayOptFind( arr, "This.code == '" + code + "'" ) != undefined;
	if( get_value( "podbor_for", dRequest ) == "net"  && code == "hr" )
		return ArrayOptFind( arr, "This.code == '" + code + "_go_net'" ) != undefined;
	else if( get_value( "podbor_for", dRequest ) == "go"  && code == "hr" )
		return ArrayOptFind( arr, "This.code == 'go_" + code + "'" ) != undefined;
	else
	{
		return ArrayOptFind( arr, "This.code == '" + ( get_value( "hub_id", dRequest ) ) + "_" + code + "'" ) != undefined;
	}

}

function get_object( id )
{
	id = OptInt( id );
	gr = ArrayOptFind( arrObjectDoc, "This.id == " + id );
	if( gr == undefined )
	{
		gr = new Object();
		gr.id = id;
		gr.doc = OpenDoc( UrlFromDocID( id ) );
		arrObjectDoc.push( gr );
	}
	return gr;
}

function get_query_elem( id, catalog, field )
{
	if( OptInt( id ) == undefined )
		return ""; 
	catRes = ArrayOptFirstElem( XQuery( "for $i in " + catalog + " where $i/id = " + id + " return $i" ) );
	if( catRes != undefined )
		return catRes.Child( field ).Value;
	return "";
}

function get_hub_name( name )
{
	switch( name )
	{
		case "go":
			return "��";
		case "east":
			return "��������� ���";
		case "west":
			return "�������� ���";
	}
	return "";
}
function get_sub_staff( TE )
{
	if( tools_web.is_true( TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) )
	{
		subname = TE.workflow_fields.ObtainChildByKey( "subdivision_name" ).value.Value
		return subname;
	}
	else if( OptInt( TE.workflow_fields.ObtainChildByKey( "subdivision_after" ).value ) != undefined )
		try
		{
		
			sub = OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "subdivision_after" ).value ) ) ).TopElem;
			return sub.name.Value
			dSub = sub;
			nArr = new Array();
			ind = 0
			do
			{
				nArr.push( { name: dSub.name, ind: ind } )
				ind++;
				if( !dSub.parent_object_id.HasValue )
				{
					nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
					break
				}
				else
					dSub = dSub.parent_object_id.OptForeignElem;
			}
			while( true )
			nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
			sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")
			return sub_staff_name;
		}
		catch( ex )
		{
			alert( ex )
		}
	return "";
}

function write_object( iId, teObject, state )
{
	if( teObject == null )
		teObject = get_object( iId ).doc.TopElem;
	obj = new Object();
	obj.id = iId;
	obj.create_date = StrDate( teObject.create_date, true, false );
	obj.code = teObject.code.Value;
	obj.person_fullname = teObject.person_fullname.Value;
	obj.fullname = get_query_elem( get_value( "collaborator_id", teObject ), "collaborators", "fullname" );
	obj.state_name = state;
	obj.go = get_hub_name( get_value( "hub_id", teObject ) );
	obj.position_before = get_value( "CollaboratorPositionName", teObject );
	arrSubs = String( get_value( "CollaboratorPositionParentName", teObject ) ).split( " -> " );
	obj.subdivision_before = arrSubs[ ArrayCount( arrSubs ) - 1 ];
	
	if( tools_web.is_true( get_value( "new_position_after", teObject ) ) )
		obj.position_after = get_value( "position_after_name", teObject );
	else if( OptInt( get_value( "position_after", teObject ) ) != undefined )
		obj.position_after = get_query_elem( get_value( "position_after", teObject ), "cc_jobs", "name" )
		
	obj.subdivision_after = get_sub_staff( teObject )

	if( type == "my" && teObject.workflow_state != "complete" && teObject.workflow_state != "cancel" )
	{
		obj.action = teObject.workflow_state == "cancel" ? "������� � ������" : "��������";
		obj.action_url = ( teObject.workflow_state == "cancel" ? "" : "CONFIRM=" + ( "�� �������, ��� ������ �������� ������ � " + teObject.code + " �� ������� " + obj.fullname + "?

�� ������� ������������ ����� ������, ����� ������� ������ ��� ������� ������ �� �������, ����� �� ������ ������������ (�� �������� ����� ����� ��������������� ����������� ���� � ��������� �� ������������)." ) ) + ";SET=SetStatusTransfer/object_id," + iId + ";SET=SetStatusTransfer/status_id," + ( teObject.workflow_state == "cancel" ? "draft" : "cancel" ) + ";ACTION=SetStatusTransfer;"
	}

	return obj;
}

function check_sogl( arr, hub_id, podbor_for )
{
	for( ws in arr )
	{
		if( ws.finish_state == "draft" )
			continue;
		if( ws.begin_state == "hr" && ArrayOptFind( arrGroups, "This.code == 'hr_" + ( podbor_for == "go" ? "go" : hub_id  ) + "'" ) != undefined )
			return true;
		if( ws.begin_state == "cuchr" && ArrayOptFind( arrGroups, "This.code == 'cuchr_" + hub_id + "'" ) != undefined )
			return true;
		if( ws.begin_state == "staff" && ArrayOptFind( arrGroups, "This.code == 'staff_go'" ) != undefined )
			return true;
		if( ws.begin_state == "cuchr_go" && ArrayOptFind( arrGroups, "This.code == 'cuchr_go'" ) != undefined )
			return true;
		if( ws.begin_state == "hr_go" && ArrayOptFind( arrGroups, "This.code == 'hr_go_net'" ) != undefined )
			return true;
		if( ws.begin_state == "dmto" && ArrayOptFind( arrGroups, "This.code == 'dmto_" + hub_id + "'" ) != undefined )
			return true;
	}
	return false
}

if ( PAGING.INDEX != null && PAGING.SIZE != null )
{
	PAGING.MANUAL = true;
	iStartNum = PAGING.SIZE * PAGING.INDEX;
}
RESULT = new Array()
arrObjectDoc = new Array();
switch( type )
{
	case "my":

		conds = new Array();
		conds.push( "$i/request_type_id = 6638117078853910082" );
		conds.push( "$i/person_id = " + curUserID ) 
		if( status_id != "all" && status_id != "" )
		{
			if( status_id == "job" )
				conds.push( "( $i/workflow_state != 'cancel' and $i/workflow_state != 'complete' )" );
			else
				conds.push( "$i/workflow_state = " + XQueryLiteral( status_id ) );
		}
		if( request_sogl_code != undefined )
			conds.push( "contains( $i/code, " + XQueryLiteral( request_sogl_code ) + " )" );
		arrResult =  XQuery( "for $i in requests where " + ArrayMerge( conds, "This", " and " ) + " order by $i/create_date descending return $i" );
		
			
		for( elem in arrResult )
			RESULT.push( write_object( elem.id.Value, null, ( elem.workflow_state_name.HasValue ? elem.workflow_state_name.Value : ( workflow_state_name( elem.workflow_state ) ) ) ) );

		if( fullname != "" )
			RESULT = ArraySelect( RESULT, "StrContains( This.fullname, " + XQueryLiteral( fullname ) + ", true )" );

		PAGING.TOTAL = ArrayCount( RESULT );
		if ( PAGING.INDEX != null && PAGING.SIZE != null )
			RESULT = ArrayRange( RESULT, iStartNum, PAGING.SIZE );
		break;
		
	case "sogl":
		xarrRequests = new Array();
		tmpArr = new Array();
		arrGroups = ArrayDirect( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " return $i" ) );
		
		conds = new Array();
		conds.push( "$i/request_type_id = 6638117078853910082" );
		//conds.push( "$i/person_id = " + curUserID ) 
		/*if( status_id != "all" && status_id != "" )
		{
			if( status_id == "in_job" )
				conds.push( "( $i/workflow_state != 'cancel' and $i/workflow_state != 'complete' )" );
			else
				conds.push( "$i/workflow_state = " + XQueryLiteral( status_id ) );
		}*/
		if( request_sogl_code != "" )
			conds.push( "contains( $i/code, " + XQueryLiteral( request_sogl_code ) + " )" );
		if( manager_fullname != "" )
			conds.push( "contains( $i/person_fullname, " + XQueryLiteral( manager_fullname ) + " )" );
		
			
		//alert("for $i in requests where " + ArrayMerge( conds, "This", " and " ) + " order by $i/create_date descending return $i")
		xarrRequests =  XQuery( "for $i in requests where " + ArrayMerge( conds, "This", " and " ) + " order by $i/create_date descending return $i" );
		

		function is_sogl( p_id )
		{
			return ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( p_id ) && ( This.finish_state == "sogl_manager" || This.finish_state == "hr_go" || This.finish_state == "hr" || This.finish_state == "cuchr" || This.finish_state == "dmto" || This.finish_state == "podbor" )' ) != undefined;
		}
		function is_sogl_sogl( pers_id )
		{
			if( OptInt( get_value( "sogl_collaborator_id", dRequest ) ) == OptInt( pers_id ) && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( pers_id ) && ( This.begin_state == "sogl_manager" )' ) == undefined )
				return true;
			else if( OptInt( get_value( "sogl_collaborator_id_2", dRequest ) ) == OptInt( pers_id ) && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( pers_id ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id", dRequest ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
				return true;
			else if( OptInt( get_value( "sogl_collaborator_id_3", dRequest ) ) == OptInt( pers_id ) && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( pers_id ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id", dRequest ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id_2", dRequest ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
				return true;
			return false;
		}
		
		isUKIL = ArrayOptFind( arrGroups, "This.code == 'ukil_go'" ) != undefined
		isSTAFF = ArrayOptFind( arrGroups, "This.code == 'staff_go'" ) != undefined
		
			for( elem in xarrRequests )
			{
					//alert( elem.id )
					dRequest = get_object( elem.id ).doc.TopElem;
					
					if( ( dRequest.workflow_state == "hr" || dRequest.workflow_state == "sv_hr" ) && check_group( arrGroups, "hr" ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( ( ( dRequest.workflow_state == "im" ) && check_group( arrGroups, "international_mobility" ) ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					
					else if( ( ( dRequest.workflow_state == "sb" ) && check_group( arrGroups, "sb" ) ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( ( ( dRequest.workflow_state == "dmto" ) && check_group( arrGroups, "dmto" ) ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( ( ( dRequest.workflow_state == "staff" ) && isSTAFF ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( dRequest.workflow_state == 'sogl_manager' && is_sogl_sogl( curUserID )  )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( dRequest.workflow_state == 'person' && OptInt( dRequest.workflow_fields.ObtainChildByKey( "collaborator_id" ).value ) == curUserID )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( dRequest.workflow_state == 'sb_utv' && check_group_sb( arrGroups, "sb" ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( ( dRequest.workflow_state == 'cuchr' && check_group( arrGroups, "cuchr" ) ) || ( dRequest.workflow_state == 'cuchr_go' && ArrayOptFind( arrGroups, "This.code == 'cuchr_go'" ) != undefined ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( check_sogl( dRequest.workflow_log_entrys, ( dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "go" ? "go" : dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value ), dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value ) )
						tmpArr.push( { id: elem.id, status: "�����������", create_date: dRequest.create_date } );
					else if( ArrayOptFind( dRequest.workflow_log_entrys, "This.person_id == " + curUserID + "&& This.begin_state.HasValue && This.begin_state != 'draft' && This.finish_state != 'draft'" ) != undefined )
						tmpArr.push( { id: elem.id, status: get_state( dRequest ), create_date: dRequest.create_date } );
					else if( ( dRequest.workflow_state != 'draft' && dRequest.workflow_state != 'reject'  && dRequest.workflow_state != 'cancel'  ) && ( StrContains( elem.app_instance_id, 'ukil' ) && isUKIL ) )
						tmpArr.push( { id: elem.id, status: "�����������", create_date: dRequest.create_date } );
					else if( StrContains( elem.app_instance_id, String( curUserID ) ) || ( StrContains( elem.app_instance_id, 'ukil' ) && isUKIL ) )
						tmpArr.push( { id: elem.id, status: get_status_reject_cancel( dRequest ), create_date: dRequest.create_date } );
						
					else
					{
						try
						{
								log_states = new Array();
								nArr = dRequest.workflow_log_entrys.Clone();
								if( dRequest.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
									log_states = OpenDocFromStr( dRequest.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
								if( ArrayOptFirstElem( log_states ) != undefined )
									nArr.AssignElem( log_states );
						}
						catch( err ){ alert("hire\remote_collections\rb_hire_rosbank_transfer.js err: " + err ); }
						if( check_sogl( nArr, ( dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "go" ? "go" : dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value ), dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value ) )
							tmpArr.push( { id: elem.id, status: get_status_reject_cancel( dRequest ), create_date: dRequest.create_date } );
					}
						
			}
			
			
			if( status_id != "all" )
				xarrRequests = ArraySelect( tmpArr, "This.status == '" + get_state_name( status_id ) + "'" );
			else
				xarrRequests = tmpArr;
		for( elem in xarrRequests )
		{

			dRequest = get_object( elem.id ).doc.TopElem;
			//if( manager_fullname != "" && !StrContains( dRequest.person_fullname, manager_fullname, true ) )
			//	continue;
			RESULT.push( write_object( OptInt( elem.id ), dRequest, elem.status ) );

		}
		if( fullname != "" )
			RESULT = ArraySelect( RESULT, "StrContains( This.fullname, " + XQueryLiteral( fullname ) + ", true  )" )
		
		RESULT = ArraySort( RESULT, "Date( This.create_date )", "-" );
		PAGING.TOTAL = ArrayCount( RESULT );
		if ( PAGING.INDEX != null && PAGING.SIZE != null )
			RESULT = ArrayRange( RESULT, iStartNum, PAGING.SIZE );
		
		break;
}