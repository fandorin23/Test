//������� ������ ( ������� )

/*
	<wvars>
		<wvar>
			<name>type</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>status_id</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>request_type_id</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>request_sogl_code</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>fullname</name>
			<type>string</type>
			<position>5</position>
		</wvar>
		<wvar>
			<name>candidate_fullname</name>
			<type>string</type>
			<position>6</position>
		</wvar>
		<wvar>
			<name>status_robot</name>
			<type>string</type>
			<position>7</position>
		</wvar>
	</wvars>
*/

function workflow_state_name( name )
{
	switch( name )
	{
		case "hr":
		case "hr_go":
		case "hr_go_net":
			return "� HR-��������";
		case "complete":
		case "complete_ur":
			if( OptInt( request_type_id ) == 6405549321361564798 )
				return "�������";
			else
				return "�������";
		case "draft":
			return "��������";
		case "cuchr":
		case "cuchr_go":
			return "� HR-������";
		case "im":
			return "� Int.Mobility";
		case "dmto":
			return "� ���";
		case "sogl_manager":
			return "� ������������";
		case "candidate":
			return "����� ���������";
		case "cancel":
			if( OptInt( request_type_id ) == 6405549321361564798 )
				return "��������";
			else
				return "��������";
		case "podbor":
			return "� ������";
		case "reject":
			if( OptInt( request_type_id ) == 6405549321361564798 )
				return "���������";
			else
				return "���������";
		case "staff":
			return "� �������������� �� ��";
	}
	return "";
}
function get_value( name, doc )
{
	if( doc.workflow_fields.GetOptChildByKey( name ) != undefined )
		return doc.workflow_fields.GetOptChildByKey( name ).value.Value;
	else if( doc.custom_elems.GetOptChildByKey( name ) != undefined )
		return doc.custom_elems.GetOptChildByKey( name ).value.Value;
	else
		return "";
}

function isSogl( doc )
{
	arr = ArraySelect( doc.workflow_log_entrys, "This.person_id == " + curUserID );
	if( ArrayOptFirstElem( arr ) == undefined )
		return false;
	last = ArrayMax( arr, "This.create_date" );
	if( last.finish_state != "reject" && last.finish_state != "draft" )
		return true;
		
	return false;
}

function isReject( doc )
{
	arr = ArraySelect( doc.workflow_log_entrys, "This.person_id == " + curUserID );
	if( ArrayOptFirstElem( arr ) == undefined )
		return false;
	last = ArrayMax( arr, "This.create_date" );
	if( last.finish_state == "reject" )
		return true;
		
	return false;
}
function get_state( doc )
{
	if( doc.workflow_state == "cancel" )
		return ( OptInt( request_type_id ) == 6405549321361564798 ? "��������" : "��������" );
	if( isSogl( doc ) )
		return ( OptInt( request_type_id ) == 6405549321361564798 ? "�����������" : "�����������" );
	if( isReject( doc ) )
		return ( OptInt( request_type_id ) == 6405549321361564798 ? "���������" : "���������" );
	return "�����";
}
function get_state_name( doc )
{
	if( status_id == "new" )
		return "�����";
	if( status_id == "cancel" )
		return ( OptInt( request_type_id ) == 6405549321361564798 ? "��������" : "��������" );
	if( status_id == "sogl" )
		return ( OptInt( request_type_id ) == 6405549321361564798 ? "�����������" : "�����������" );
	if( status_id == "reject" )
		return ( OptInt( request_type_id ) == 6405549321361564798 ? "���������" : "���������" );
}

function get_sogl_name( top_elem )
{
	p_id = OptInt( get_value( "sogl_person_id", top_elem ) );
	per_id = undefined;
	if(  p_id != undefined && ArrayOptFind( top_elem.workflow_log_entrys, 'This.person_id == OptInt( p_id ) && ( This.finish_state == "sogl_manager" || This.finish_state == "hr_go" || This.finish_state == "hr" || This.finish_state == "cuchr" || This.finish_state == "dmto" || This.finish_state == "podbor" )' ) == undefined )
	{
		per_id = p_id;
	}
	else
	{
		p_id = OptInt( get_value( "sogl_person_id_2", top_elem ) );
		if(  p_id != undefined && ArrayOptFind( top_elem.workflow_log_entrys, 'This.person_id == OptInt( p_id ) && ( This.finish_state == "sogl_manager" || This.finish_state == "hr_go" || This.finish_state == "hr" || This.finish_state == "cuchr" || This.finish_state == "dmto" || This.finish_state == "podbor" )' ) == undefined )
		{
			per_id = p_id;
		}
		else
		{
			p_id = OptInt( get_value( "sogl_person_id_3", top_elem ) );
			if(  p_id != undefined && ArrayOptFind( top_elem.workflow_log_entrys, 'This.person_id == OptInt( p_id ) && ( This.finish_state == "sogl_manager" || This.finish_state == "hr_go" || This.finish_state == "hr" || This.finish_state == "cuchr" || This.finish_state == "dmto" || This.finish_state == "podbor" )' ) == undefined )
			{
				per_id = p_id;
			}
		}
	}
	if( per_id != undefined )
	{
		coll = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/id = " + per_id + " return $i" ) );
		if( coll != undefined )
			return coll.fullname.Value;
	}
	return "";
}

function write_request( doc, id, st )
{
	try
	{
		st
	}
	catch( ex )
	{
		st = get_state( doc )
	}
	obj = new Object();
	obj.create_date = "";
	if( type == "my" || ArrayOptFirstElem( doc.workflow_log_entrys ) == undefined )
		obj.create_date = StrDate( doc.create_date.Value, true, false );
	else if( ArrayOptFirstElem( doc.workflow_log_entrys ) != undefined )
		obj.create_date = StrDate( ArrayMax( doc.workflow_log_entrys, "This.create_date" ).create_date.Value, true, false );
	obj.id = id;
	if( OptInt( request_type_id ) == 6462222737295559895 )
	{
		rrr = ArrayOptFirstElem( XQuery( "for $i in requests where $i/id = " + doc.object_id + " return $i" ) )
		if( rrr != undefined )
			obj.code = rrr.code.Value;
		else
			obj.code = "";
	}
	else
		obj.code = doc.code.Value;
	if( type == "sogl" )
		obj.person_fullname = doc.person_fullname.Value;
	if( type == "my" )
		obj.state_name = workflow_state_name( doc.workflow_state.Value );
	else
		obj.state_name = st;

	if( get_value( "podbor_for", doc ) != "" )
	{
		if( get_value( "podbor_for", doc ) == "go" )
			obj.go = "�������� ����";
		else if( get_value( "hub_id", doc ) == "west" )
			obj.go = "�������� ���";
		else if( get_value( "hub_id", doc ) == "east" )
			obj.go = "��������� ���";
	}
	if( get_value( "new_job", doc ) == "1" )
		obj.position = get_value( "job_name", doc );
	else
		try
		{
			obj.position = OptInt( get_value( "job_id", doc ) ) != undefined ? OpenDoc( UrlFromDocID( Int( get_value( "job_id", doc ) ) ) ).TopElem.name.Value : "";
		}
		catch( ex )
		{
			obj.position = "Object deleted";
		}

	if( get_value( "new_subdivision", doc ) == "1" )
		obj.subdivision = get_value( "subdivision_name", doc );
	else
		try
		{
			obj.subdivision = OptInt( get_value( "subdivision_id", doc ) ) != undefined ? OpenDoc( UrlFromDocID( Int( get_value( "subdivision_id", doc ) ) ) ).TopElem.name.Value : "";
		}
		catch( ex )
		{
			obj.subdivision = "Object deleted";
		}
		

	if( type == "my" )
	{
		if( doc.workflow_state == "sogl_manager" )
		{
			obj.sogl_name = get_sogl_name( doc );
		}
		//if( doc.workflow_state == "cancel" || doc.workflow_state == "complete" || doc.workflow_state == "complete_ur" || doc.workflow_state == "reject" )
		if( doc.workflow_state == "reject" )
		{
			if( doc.person_id == curUserID )
			{
				obj.action = "������� � ������";
				obj.action_url = "SET=EditObjectId," + id + ";SET=EditStatusId,draft;ACTION=SetStatusRosBank";
			}
		}
		else if( doc.workflow_state != "complete" && doc.workflow_state != "complete_ur" && doc.workflow_state != "cancel"  )
		{
			sConfirm = "CONFIRM=";
			if( OptInt( request_type_id ) == 6462222737295559895 )
			{
				sConfirm += ( "�� �������, ��� ������ �������� ������������� �� ����� ��������� " + doc.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value.Value + "? \n\n������������ ����� ������������� �� ���� �� ������� � ������� ���� ������" );
			}
			else
			{
				sConfirm += ( "�� �������, ��� ������ �������� ������ �� ����� " + doc.code + " " + obj.position + '? \n\n�� ������� ������������ ����� ������, ����� ������� ������  ��� ������� ������ �� �������, ����� �� ������ ������������ (�� �������� ����� ����� ��������������� ����������� ����  � ��������� �� ������������)' )
			}			
				
			obj.action = "��������";
			obj.action_url = sConfirm + ";SET=EditObjectId," + id + ";SET=EditStatusId,cancel;ACTION=SetStatusRosBank";
		}
	}
	if( OptInt( request_type_id ) == 6462222737295559895 )
	{
		obj.robot = tools_web.is_true( doc.workflow_fields.ObtainChildByKey( "robot" ).value ) ? "��" : "���";
		obj.candidate = doc.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value.Value;
		if( obj.candidate == "" )
			obj.candidate = "�� ������"
		obj.vacancy = "";
		dv = ArrayOptFirstElem( XQuery( "for $i in requests where $i/id = " + doc.object_id + " return $i" ) );
		if( dv != undefined )
			obj.vacancy = String( dv.code )
		obj.object_id = doc.object_id.Value;
		
		if( tools_web.is_true( doc.workflow_fields.ObtainChildByKey( "place_not_need" ).value ) )
		{
			obj.rab_mesto = "�� ���������"
		}
		else
		{
			iPlaceId = OptInt( doc.workflow_fields.ObtainChildByKey( "pomechenie_id" ).value );
			//alert(iPlaceId)
			if( iPlaceId != undefined )
				try
				{
					tePlace = OpenDoc( UrlFromDocID( iPlaceId ) ).TopElem;
					pom = tePlace.pomechenie_id.ForeignElem;
					obj.pomechenie = "'" + pom.pomechenie_nomer.Value;
					obj.rab_mesto_address = pom.zdanie_id.ForeignElem.zdanie_naimenovanie.Value;
					obj.etazh = pom.etazh_nomer.Value;
					obj.zona = pom.zona_naimenovanie.Value;
					obj.rab_mesto = tePlace.stol.Value;
				}
				catch( ex ){ alert( ex ) }
			
		}
		if( doc.workflow_fields.ObtainChildByKey( "forma_hire" ).value == "1001" || doc.workflow_fields.ObtainChildByKey( "forma_hire" ).value == "" )
			obj.start_date = doc.workflow_fields.ObtainChildByKey( "start_job_date" ).value.Value;
	}

	return obj;
}

function check_group( arr, code )
{
	if( code == "international_mobility" )
		return ArrayOptFind( arr, "This.code == '" + code + "'" ) != undefined;
	if( get_value( "podbor_for", dRequest ) == "net"  && code == "hr" && OptInt( request_type_id ) == 6462222737295559895 )
		return ArrayOptFind( arr, "This.code == '" + code + "_go_net'" ) != undefined;
	else if( get_value( "podbor_for", dRequest ) == "go"  && code == "hr" && OptInt( request_type_id ) == 6462222737295559895 )
		return ArrayOptFind( arr, "This.code == '" + code + "_go'" ) != undefined;
	else
	{
		return ArrayOptFind( arr, "This.code == '" + code + "_" + ( get_value( "podbor_for", dRequest ) == "go" && OptInt( request_type_id ) == 6405549321361564798 ? "go" : get_value( "hub_id", dRequest ) ) + "'" ) != undefined;
	}

}

function get_status_reject_cancel( doc )
{
	log_states = new Array();
	if( doc.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
		log_states = OpenDocFromStr( doc.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
	m = undefined
	if( ArrayOptFirstElem( log_states ) != undefined )
		m = ArrayMin( log_states, "This.ChildExists( 'create_date' ) && This.create_date.HasValue ? DateDiff( Date(), Date( This.create_date ) ) : 99999999999" )
	return ( m != undefined && m.ChildExists( "finish_state" ) ? ( m.finish_state == "reject" ? ( OptInt( request_type_id ) == 6405549321361564798 ? "���������" : "���������" ) : ( OptInt( request_type_id ) == 6405549321361564798 ? "��������" : "��������" ) ) : "" );
}

function check_sogl( arr, hub_id, podbor_for )
{
	for( ws in arr )
	{
		if( ws.finish_state == "draft" )
			continue;
		if( ws.begin_state == "hr" && ArrayOptFind( arrGroups, "This.code == 'hr_" + ( podbor_for == "go" ? "go" : OptInt( request_type_id ) != 6405549321361564798 ? "go_net" : hub_id  ) + "'" ) != undefined )
			return true;
		if( ws.begin_state == "cuchr" && ArrayOptFind( arrGroups, "This.code == 'cuchr_" + hub_id + "'" ) != undefined )
			return true;
		if( ws.begin_state == "staff" && ArrayOptFind( arrGroups, "This.code == 'staff_go'" ) != undefined )
			return true;
		if( ws.begin_state == "cuchr_go" && ArrayOptFind( arrGroups, "This.code == 'cuchr_go'" ) != undefined )
			return true;
		if( ws.begin_state == "cuchr" && ArrayOptFind( arrGroups, "This.code == 'robot_" + hub_id + "'" ) != undefined )
			return true;
		if( ws.begin_state == "cuchr_go" && ArrayOptFind( arrGroups, "This.code == 'robot_go'" ) != undefined )
			return true;
		if( ws.begin_state == "hr_go" && ArrayOptFind( arrGroups, "This.code == 'hr_go_net'" ) != undefined )
			return true;
		if( ws.begin_state == "dmto" && ArrayOptFind( arrGroups, "This.code == 'dmto_" + hub_id + "'" ) != undefined )
			return true;
	}
	return false
}

cond = "";



if ( PAGING.INDEX != null && PAGING.SIZE != null )
{
	PAGING.MANUAL = true;
	iStartNum = PAGING.SIZE * PAGING.INDEX;
}
RESULT = new Array()
switch( type )
{
	case "my":

		if( status_id == "in_job" )
			cond = " and $i/workflow_state != 'cancel' and $i/workflow_state != 'complete'  and $i/workflow_state != 'complete_ur' "
		else if( status_id == "hr" )
			cond = " and ( $i/workflow_state = 'hr_go' or $i/workflow_state = 'hr_go_net' or $i/workflow_state = 'hr' ) "
		else if( status_id == "complete" )
			cond = " and ( $i/workflow_state = 'complete' or $i/workflow_state = 'complete_ur' ) "
		else if( status_id == "cuchr" )
			cond = " and ( $i/workflow_state = 'cuchr' or $i/workflow_state = 'cuchr_go' ) "
		else if( status_id != "null" && status_id != "all" )
		{
			cond = " and $i/workflow_state = '" + status_id + "' "
		}
		if( OptInt( request_type_id ) != 6462222737295559895 && request_sogl_code != "" )
		{
			cond += " and contains( $i/code, '" + request_sogl_code + "' )"
		}
		
		arrRecrs = ArraySelect( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " return $i" ), "StrBegins( This.code, 'recr_' )" );
		xarrPodbs = new Array();
		if( ArrayOptFirstElem( arrRecrs ) != undefined && OptInt( request_type_id ) == 6462222737295559895 )
		try
		{
			xarrPodbs = XQuery( "sql: select req.id from requests req \
								inner join request re on re.id = req.id \
								where req.request_type_id = 6405549321361564798 and \
								(  re.data.value( '(request/workflow_fields/workflow_field[name=''hub_id''])[1]/value[1]', 'nvarchar(14)' ) = '" + ArrayMerge( arrRecrs, "StrReplace( This.code, 'recr_', '' )", "' or re.data.value( '(request/workflow_fields/workflow_field[name=''hub_id''])[1]/value[1]', 'nvarchar(max)' ) = '" ) + "' )" );
		} 
		catch( ex ){ alert( ex ) }
		xarrRequests = XQuery( "for $i in requests where  ( $i/person_id = " + curUserID + ( ArrayOptFirstElem( xarrPodbs ) != undefined ? " or MatchSome( $i/object_id, ( " + ArrayMerge( xarrPodbs, "This.id", "," ) + " ) )" : "" ) + " ) and  $i/request_type_id = " + request_type_id + cond + ( OptInt( request_type_id ) == 6462222737295559895 ? " and $i/object_id != null() " : "" ) +  " order by $i/create_date descending return $i" );
		
		xarrRequests = ArraySort( xarrRequests, "Date( This.create_date )", "-" );
		
		if( ArrayOptFirstElem( arrRecrs ) != undefined && OptInt( request_type_id ) == 6462222737295559895 && ArrayOptFirstElem( xarrRequests ) != undefined )
		{
			body = "<body>";
			body += "<code>" + curUser.code + "</code>";
			body += "<ids>" + ArrayMerge( xarrRequests, "This.object_id", "," ) + "</ids>";
			body += "</body>";
			_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
			resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_access_vacancys' ) , 'post',  body ).Body;
			arrAccessVacancy = String( resp ).split( ";" );
			xarrRequests = ArrayIntersect( xarrRequests, arrAccessVacancy, "OptInt( This.object_id )", "OptInt( This )" );
		}
		
		for( elem in xarrRequests )
		{
			dRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
			RESULT.push( write_request( dRequest, elem.id.Value ) );
		}
		if( OptInt( request_type_id ) == 6462222737295559895 && fullname != "" )
		{
			RESULT = ArraySelect( RESULT, "StrContains( This.candidate, '" + fullname + "', true )" )
		}
		if( OptInt( request_type_id ) == 6462222737295559895 && request_sogl_code != "" )
		{
			RESULT = ArraySelect( RESULT, "StrContains( This.vacancy, '" + request_sogl_code + "', true )" )
		}
		
		PAGING.TOTAL = ArrayCount( RESULT );
		if ( PAGING.INDEX != null && PAGING.SIZE != null )
			RESULT = ArrayRange( RESULT, iStartNum, PAGING.SIZE );
		break;
		
	case "sogl":
		xarrRequests = new Array();
		tmpArr = new Array();
		arrGroups = ArrayDirect( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " return $i" ) );
		xarrRequests =  XQuery( "for $i in requests where  $i/request_type_id = " + request_type_id + ( OptInt( request_type_id ) == 6462222737295559895 ? " and $i/object_id != null() " : ( request_sogl_code != "" ? " and contains( $i/code, '" + request_sogl_code + "' )" : "" ) ) + " order by $i/create_date descending return $i" );
		if( OptInt( request_type_id ) == 6462222737295559895 && request_sogl_code != "" )
		{
			xarrtmpRequests = XQuery( "for $i in requests where  $i/request_type_id = 6405549321361564798 and contains( $i/code, '" + request_sogl_code + "' ) return $i" );
			xarrRequests = ArrayIntersect( xarrRequests, xarrtmpRequests, "This.object_id", "This.id" );
		}
		function is_sogl( p_id )
		{
			return ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( p_id ) && ( This.finish_state == "sogl_manager" || This.finish_state == "hr_go" || This.finish_state == "hr" || This.finish_state == "cuchr" || This.finish_state == "dmto" || This.finish_state == "podbor" )' ) != undefined;
		}
		function is_sogl_sogl( pers_id )
		{
			if( OptInt( get_value( "sogl_person_id", dRequest ) ) == OptInt( pers_id ) && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( pers_id ) && ( This.begin_state == "sogl_manager" )' ) == undefined )
				return true;
			else if( OptInt( get_value( "sogl_person_id_2", dRequest ) ) == OptInt( pers_id ) && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( pers_id ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id", dRequest ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
				return true;
			else if( OptInt( get_value( "sogl_person_id_3", dRequest ) ) == OptInt( pers_id ) && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( pers_id ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id", dRequest ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined && ArrayOptFind( dRequest.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id_2", dRequest ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
				return true;
			return false;
		}
		if( OptInt( request_type_id ) == 6405549321361564798 )
		{
			isHR = ArrayOptFind( arrGroups, "This.code == 'hr_go'" ) != undefined
			isHRGO = ArrayOptFind( arrGroups, "This.code == 'hr_go_net'" ) != undefined
			isHRGONET_HUB = ArrayOptFind( arrGroups, "This.code == 'hr_east' || This.code == 'hr_west'" ) != undefined
			
			for( elem in xarrRequests )
			{
					dRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
					if( fullname != "" && !StrContains( dRequest.person_fullname, fullname, true ) ){
						continue;
					}					
					if( dRequest.workflow_state == "hr_go" && isHRGO )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( dRequest.workflow_state == "hr" && ( ( get_value( "podbor_for", dRequest ) == "go" && isHR ) || ( get_value( "podbor_for", dRequest ) == "net" && check_group( arrGroups, "hr" ) ) ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( ( ( dRequest.workflow_state == "im" ) && check_group( arrGroups, "international_mobility" ) ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( dRequest.workflow_state == 'sogl_manager' && is_sogl_sogl( curUserID )  )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( ( dRequest.workflow_state == 'cuchr' && check_group( arrGroups, "cuchr" ) ) || ( dRequest.workflow_state == 'cuchr_go' && ArrayOptFind( arr, "This.code == 'cuchr_go'" ) != undefined ) )
						tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
					else if( check_sogl( dRequest.workflow_log_entrys, ( dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "go" ? "go" : dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value ), dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value ) )
						tmpArr.push( { id: elem.id, status: "�����������", create_date: dRequest.create_date } );
					else if( ArrayOptFind( dRequest.workflow_log_entrys, "This.person_id == " + curUserID + "&& This.begin_state.HasValue && This.begin_state != 'draft' && This.finish_state != 'draft'" ) != undefined )
						tmpArr.push( { id: elem.id, status: get_state( dRequest ), create_date: dRequest.create_date } );
					else if( StrContains( elem.app_instance_id, String( curUserID ) ) )
						tmpArr.push( { id: elem.id, status: get_status_reject_cancel( dRequest ), create_date: dRequest.create_date } );
					
					else
					{
						try
						{
								log_states = new Array();
								nArr = dRequest.workflow_log_entrys.Clone();
								if( dRequest.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
									log_states = OpenDocFromStr( dRequest.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
								if( ArrayOptFirstElem( log_states ) != undefined )
									nArr.AssignElem( log_states );
						}
						catch( err ){ alert( err ); }
						if( check_sogl( nArr, ( dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "go" ? "go" : dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value ), dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value ) )
							tmpArr.push( { id: elem.id, status: get_status_reject_cancel( dRequest ), create_date: dRequest.create_date } );
					}
						
			}
			if( status_id != "all" )
				xarrRequests = ArraySelect( tmpArr, "This.status == '" + get_state_name( status_id ) + "'" );
			else
				xarrRequests = tmpArr;

			
		}
		else
		{
			
			for( elem in xarrRequests )
			{
				dRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;

				if( fullname != "" && !StrContains( dRequest.person_fullname, fullname, true ) )
					continue;
				if( candidate_fullname != "" && !StrContains( dRequest.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value.Value, candidate_fullname, true ) )
					continue;
				if( status_robot != "all" && status_robot != "" && tools_web.is_true( status_robot ) != tools_web.is_true( dRequest.workflow_fields.ObtainChildByKey( "robot" ).value.Value ) )
					continue;

				if( dRequest.workflow_state == "staff" && ArrayOptFind( arrGroups, "This.code == 'staff_go'" ) != undefined )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				else if( ( ( dRequest.workflow_state == "hr" ) && check_group( arrGroups, "hr" ) ) )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				else if( ( ( dRequest.workflow_state == "im" ) && check_group( arrGroups, "international_mobility" ) ) )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				else if( dRequest.workflow_state == 'sogl_manager' && is_sogl_sogl( curUserID )  )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				else if( check_group( arrGroups, "dmto" ) && dRequest.workflow_state == "dmto" )
				{
					//alert( "add request" )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				}
				else if( ( dRequest.workflow_state == 'cuchr' && check_group( arrGroups, "cuchr" ) ) || ( dRequest.workflow_state == 'cuchr_go' && ArrayOptFind( arrGroups, "This.code == 'cuchr_go'" ) != undefined ) )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				else if( !tools_web.is_true(  dRequest.workflow_fields.ObtainChildByKey( "robot" ).value.Value ) && ( ( dRequest.workflow_state == 'cuchr' && check_group( arrGroups, "robot" ) ) || ( dRequest.workflow_state == 'cuchr_go' && ArrayOptFind( arrGroups, "This.code == 'robot_go'" ) != undefined ) ) )
					tmpArr.push( { id: elem.id, status: "�����", create_date: dRequest.create_date } );
				else if( check_sogl( dRequest.workflow_log_entrys, ( dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value  ), dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value ) )
					tmpArr.push( { id: elem.id, status: "�����������", create_date: dRequest.create_date } );
				else if( ArrayOptFind( dRequest.workflow_log_entrys, "This.person_id == " + curUserID + "&& This.begin_state.HasValue && This.begin_state != 'draft' && This.finish_state != 'draft' && !( This.begin_state == 'cuchr' && This.finish_state == 'cuchr' )" ) != undefined )
					tmpArr.push( { id: elem.id, status: get_state( dRequest ), create_date: dRequest.create_date } );
				else if( StrContains( elem.app_instance_id, String( curUserID ) ) )
					tmpArr.push( { id: elem.id, status: get_status_reject_cancel( dRequest ), create_date: dRequest.create_date } );
				else
				{
					try
					{
						log_states = new Array();
						nArr = dRequest.workflow_log_entrys.Clone();
						if( dRequest.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
							log_states = OpenDocFromStr( dRequest.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
						if( ArrayOptFirstElem( log_states ) != undefined )
									nArr.AssignElem( log_states );
					}
					catch( err ){ alert( err ); }
					if( check_sogl( nArr, ( dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value ), dRequest.workflow_fields.ObtainChildByKey( "podbor_for" ).value ) )
						tmpArr.push( { id: elem.id, status: get_status_reject_cancel( dRequest ), create_date: dRequest.create_date } );
				}
			}
			if( status_id != "all" )
				xarrRequests = ArraySelect( tmpArr, "This.status == '" + get_state_name( status_id ) + "'" );
			else
				xarrRequests = tmpArr;
		}
		for( elem in xarrRequests )
		{

			dRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
			
			RESULT.push( write_request( dRequest, OptInt( elem.id ), elem.status ) );

		}
		
		RESULT = ArraySort( RESULT, "Date( This.create_date )", "-" );
		PAGING.TOTAL = ArrayCount( RESULT );
		if ( PAGING.INDEX != null && PAGING.SIZE != null )
			RESULT = ArrayRange( RESULT, iStartNum, PAGING.SIZE );
		
		break;
}