//Выборка вакансий
/*
param:
search: string
*/
_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : "http://" ) + global_settings.settings.recruitment.estaff_server_url;
resp = HttpRequest( UrlAppendPath( _url, '/rosbank_report_service.xml?method=get_vacancys&page_size=' + PAGING.SIZE + '&page_index=' + PAGING.INDEX + '&key_word=' + UrlEncode( search ) ) , 'post' );

resp = OpenDocFromStr( resp.Body ).TopElem;  
PAGING.MANUAL = true;
PAGING.TOTAL = resp.total;
RESULT = new Array();
for( elem in resp.vacancys )
	RESULT.push( { id: elem.id.Value, code: elem.code.Value, name: elem.name.Value } );