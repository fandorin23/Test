//������� ������� ���������

/*
<?xml version="1.0" encoding="utf-8"?>
<remote_collection SPXML-FORM="x-local://wtv/wtv_remote_collection.xmd">
	<code>rosbank_event_candidate</code>
	<name>������� ������� ���������</name>
	<url>webtutor\rbSrcCode\hire\remote_collections\rosbank_event_candidate.js</url>
	<wvars>
		<wvar>
			<name>status</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>request_code</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>CandidateId</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>StatusEventRequest</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>EventType</name>
			<type>string</type>
			<position>5</position>
		</wvar>
		<wvar>
			<name>CandFullname</name>
			<type>string</type>
			<position>6</position>
		</wvar>
		<wvar>
			<name>RequestCodeCandidate</name>
			<type>string</type>
			<position>7</position>
		</wvar>
	</wvars>
*/

/*RESULT = tools_web.get_user_data("rosbank_cache_candidate_" + curUserID);
				if (RESULT != null && RESULT.HasProperty("resp") )
				{
					res = RESULT.resp;
				}
				else
				{
					sb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, 'sb_' ) return $i" ) ) != undefined;
					go_sb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  $i/code = 'go_sb' return $i" ) ) != undefined;
					hr = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  $i/code = 'hr_go' return $i" ) ) != undefined;
					_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, "http://" ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, "https://" ) ? "" : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
					resp = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=get_events" ) + "&sb=" + sb + "&hr=" + hr + "&go_sb=" + go_sb , "post",  curUser.code );
					//alert("resp.Body "+resp.Body)
					tools_web.set_user_data("rosbank_cache_candidate_" + curUserID, ({"resp" : resp.Body}), 3600);
					res = resp.Body;
				}
				
				srrEvents = OpenDocFromStr( res ).TopElem;
				SsrrEvents = srrEvents;*/
				//alert( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, 'sb_' ) return $i" )
				sb = XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, 'sb_' ) return $i" ) ;
				hr = XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  contains( $i/code, 'hr_' ) return $i" ) ;
				//go_sb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  $i/code = 'go_sb' return $i" ) ) != undefined;
				//sb_go = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  $i/code = 'sb_go' return $i" ) ) != undefined;
				sb_ruk = XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, '_sb' ) return $i" );
				arbitrrazhsb = XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and $i/code = 'arbitrazhsb' return $i" );
				recr = XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, 'recr_' ) return $i" );
				sbkur = XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, 'sbkur_' ) return $i" );
				conds = new Array();
				is_sbkur = false;
				is_sb = false;
				is_sb_ruk = false;
				is_arbitrrazhsb = false;
				is_recr = false;
				if( ArrayOptFirstElem( sbkur ) != undefined )
				{
					is_sbkur = true;
					conds.push( " ( ( $i/event_type = 'event_type_6' or $i/event_type = 'rosbank_verification' or $i/event_type = 'rosbank_arbitrazh_sb' ) and MatchSome( $i/hub_id, ( '" + ArrayMerge( sbkur, "StrReplace( This.code, 'sbkur_', '' )", "','" ) + "' ) ) ) " );
				}
				if( ArrayOptFirstElem( sb ) != undefined )
				{
					is_sb = true;
					conds.push( " ( $i/event_type = 'event_type_6' and MatchSome( $i/hub_id, ( '" + ArrayMerge( sb, "StrReplace( This.code, 'sb_', '' )", "','" ) + "' ) ) )" );
				}
				if( ArrayOptFirstElem( recr ) != undefined )
				{
					is_recr = true;
					conds.push( " ( $i/event_type = 'event_type_6' and MatchSome( $i/hub_id, ( '" + ArrayMerge( recr, "StrReplace( This.code, 'recr_', '' )", "','" ) + "' ) ) )" );
				}

				if( ArrayOptFirstElem( sb_ruk ) != undefined )
				{
					is_sb_ruk = true;
					conds.push( " ( $i/event_type = 'event_type_6' and MatchSome( $i/hub_id, ( '" + ArrayMerge( sb_ruk, "StrReplace( This.code, '_sb', '' )", "','" ) + "' ) ) )" );
				}
				if( ArrayOptFirstElem( arbitrrazhsb ) != undefined )
				{
					is_arbitrrazhsb = true;
					conds.push( " ( $i/event_type = 'event_type_6' or $i/event_type = 'rosbank_verification' or $i/event_type = 'rosbank_arbitrazh_sb' ) " );
				}
				if( ArrayOptFirstElem( hr ) != undefined )
					conds.push( " ( $i/event_type = 'rb_event_type_7' and MatchSome( $i/hub_id, ( '" + ArrayMerge( hr, "StrReplace( This.code, 'hr_', '' )", "','" ) + "' ) )  )" );
				/*if( go_sb )
					conds.push( " $i/event_type = 'event_rosbank_go_sb' " );
				if( go_sb || sb_go )
					conds.push( " $i/event_type = 'rosbank_sb_go' " );*/
				if( curUser.code != "" )
					conds.push( " $i/collaborators != ';;' and contains( $i/collaborators, ';" + curUser.code + ";' ) " );
				
				//alert("for $i in cc_estaff_events where " + ArrayMerge( conds, "This", " or " ) + " return $i")
				srrEvents = new Array();
				if( ArrayOptFirstElem( conds ) != undefined )
					srrEvents = XQuery( "for $i in cc_estaff_events where $i/event_type != 'rb_hire_rosbank_not_feedback' and ( " + ArrayMerge( conds, "This", " or " ) + " ) return $i" );
				request_type = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank' return $i" ) );
				if( status != "all" )
				{
					cond = "";
					if( status == "in_job" )
						cond = " and $i/workflow_state != 'cancel' and $i/workflow_state != 'complete' and $i/workflow_state != 'hr' and $i/workflow_state != 'hr_go' and $i/workflow_state != 'draft' "
					else if( status == "hr" )
						cond = " and ( $i/workflow_state = 'hr_go' or $i/workflow_state = 'hr_go_net' or $i/workflow_state = 'hr' ) "
					else if( status == "complete" )
						cond = " and ( $i/workflow_state = 'complete' or $i/workflow_state = 'complete_ur' ) "
					else if( status != "null" && status != "" )
					{
						cond = " and $i/workflow_state = '" + status + "' "
					}
					else
						cond = " $i/workflow_state != 'hr' and $i/workflow_state != 'hr_go' and $i/workflow_state != 'draft' "
						
					xarrRequests = XQuery( "for $i in requests where  $i/request_type_id = " + request_type.id + cond + " return $i" );
					srrEvents = ArrayIntersect( srrEvents, xarrRequests, "OptInt( This.vacancy_id )", "OptInt( This.id )" );
				}
				else
				{
					//xarrRequests = XQuery( "for $i in requests where  $i/request_type_id = " + request_type.id + " and $i/workflow_state != 'hr' and $i/workflow_state != 'hr_go' and $i/workflow_state != 'draft'  return $i" );
					//srrEvents = ArrayIntersect( srrEvents, xarrRequests, "OptInt( This.vacancy_id )", "OptInt( This.id )" );
				}
				//alert( 'srrEvents '+ArrayCount(srrEvents) )
				if( RequestCodeCandidate != "" )
				{
					//xarrRequests = XQuery( "for $i in requests where  $i/code = " + request_code + " return $i" );
					//srrEvents = ArrayIntersect( srrEvents, xarrRequests, "OptInt( This.vacancy_id )", "OptInt( This.id )" );
					srrEvents = ArraySelect( srrEvents, "StrContains( This.vacancy_code, '" + RequestCodeCandidate + "' )" )
				}
				//alert( 'srrEvents '+ArrayCount(srrEvents) )
				if( CandFullname != "" )
					srrEvents = ArraySelect( srrEvents, "StrContains( This.candidate_name, '" + CandFullname + "', true )" )
				if( CandidateId != "all" )
					srrEvents = ArraySelect( srrEvents, "This.candidate_id == '" + CandidateId + "'" )
				//alert( 'srrEvents '+ArrayCount(srrEvents) )
				if( EventType != "all" )
					srrEvents = ArraySelect( srrEvents, "This.event_type == '" + EventType + "'" )
				RESULT = srrEvents
				//alert( 'srrEvents '+ArrayCount(srrEvents) )
				xarrSbRequests = null;

RESULT = ArraySort( RESULT, "Date(This.event_date)", "-")
nResults = new Array();
for( elem in RESULT )
{
	//elem.event_status = elem.event_status;
	obj = new Object();
	obj.event_status = elem.event_status.Value;
	if( elem.event_type == 'event_type_6' && !StrContains( elem.collaborators, ";" + curUser.code + ";" ) && !is_arbitrrazhsb && !is_sbkur  &&  elem.event_status != "failed" && elem.event_status != "succeeded" && elem.event_status != "cancelled" && !is_arbitrrazhsb && !is_recr )
	{
		if( xarrSbRequests == null )
		{
			request_type_id = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_sb_go' return $i" ) ).id;
			xarrSbRequests = ArrayDirect( XQuery( "for $i in requests where $i/request_type_id = " + request_type_id + " return $i" ) );	
		}
		request = ArrayOptFind( xarrSbRequests, "This.object_id == OptInt( '" + elem.code + "' )" );
		
		if( ArrayOptFind( sb, "This.code == 'sb_" + elem.hub_id + "'" ) == undefined && request == undefined )
			continue;
		if( request != undefined )
		{
			dRequest = OpenDoc( UrlFromDocID( request.id ) ).TopElem;
			if( ArrayOptFind( sb, "This.code == 'sb_" + elem.hub_id + "'" ) == undefined && dRequest.custom_elems.ObtainChildByKey( "sb_go" ).value == "false" )
				continue;
				
			if( ArrayOptFind( sb, "This.code == 'sb_" + elem.hub_id + "'" ) != undefined && dRequest.custom_elems.ObtainChildByKey( "sb_go" ).value == "true" && ArrayOptFind( sb_ruk, "This.code == '" + elem.hub_id + "_sb'" ) == undefined )
				obj.event_status = dRequest.workflow_fields.ObtainChildByKey( "status" ).value == "failed" ? "���������" : "�����������";
		}
	}
	
	obj.job_name = elem.job_name.Value;
	obj.candidate_name = elem.candidate_name.Value;
	obj.id = elem.code.Value;
	obj.vacancy_id = elem.vacancy_id.Value;
	obj.event_name = elem.event_name.Value;
	obj.subdivision_name = elem.subdivision_name.Value;
	req = elem.vacancy_id.OptForeignElem;
	obj.code = req != undefined ? req.code.Value : elem.vacancy_code.Value;
	
	obj.status = req != undefined ? req.workflow_state_name.Value : "";
	try
	{
		obj.creation_date = StrDate( Date( elem.creation_date ), false );
	}catch( ex ){}
	try
	{
		obj.event_date = StrDate( Date( elem.event_date ), false );
	}catch( ex ){}
	obj.is_final =  ( elem.is_final  ? "��������� ��������" : "" );
	nResults.push( obj );
}
if( StatusEventRequest != "all" )
	nResults = ArraySelect( nResults, "This.event_status == '" + Base64Decode( StatusEventRequest ) + "'" )

RESULT = nResults;