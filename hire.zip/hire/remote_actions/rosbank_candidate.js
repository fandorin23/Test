//������ ������� ����������

sb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and contains( $i/code, 'sb_' ) return $i" ) ) != undefined;
hr = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  $i/code = 'hr_go' return $i" ) ) != undefined;
go_sb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/collaborator_id = " + curUserID + " and  $i/code = 'go_sb' return $i" ) ) != undefined;
_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, "http://" ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, "https://" ) ? "" : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
resp = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=get_events" ) + "&sb=" + sb + "&hr=" + hr + "&go_sb=" + go_sb  , "post",  curUser.code );
//alert("resp.Body "+resp.Body)

tools_web.set_user_data("rosbank_cache_candidate_" + curUserID, ({"resp" : resp.Body}), 600);