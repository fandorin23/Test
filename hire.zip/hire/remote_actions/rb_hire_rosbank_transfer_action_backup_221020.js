/*�������� ��� ���������
params:
CONTEXT:string
action:string
tmp:string
object_id:string
*/
function send_notification_pers( type )
{
	if( type == "staff" )
		cond = " $i/code = 'staff_go' "
	else if( type == "im" )
		cond = " $i/code = 'international_mobility' "
	else if( ( type == "svhr" || type == "hr" || type == "hr_sogl_utv" ) && requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
		cond = " $i/code = 'hr_go_net' "
	else if( ( type == "svhr" || type == "hr" || type == "hr_sogl_utv" ) && ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
		cond = " $i/code = 'hr_go' "
	else if( type == "job_hr"  )
	{
		if( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
			cond = " $i/code = 'hr_go_net' "
		else if( ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
			cond = " $i/code = 'hr_go' "
		type = "job"
	}
	else if( type == "job_ukil"  )
	{
		cond = " $i/code = 'ukil_go' ";
		type = "job"
	}
	else if( type == "ukil"  )
	{
		cond = " $i/code = 'ukil_go' ";
	}
	else
		cond = " $i/code = '" + ( type == "svhr" || type == "hr_sogl_utv" ? "hr" : type ) + "_" + ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ";
	//alert("for $i in groups where " + cond + " return $i")
	arr = XQuery( "for $i in groups where " + cond + " return $i" );
	for( gr in ArraySelectDistinct( arr, "This.id" ) )
	{
		teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
		t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
		if( StrContains( t_send, "�� ����� �����" ) )
			tools.create_notification( "rb_hire_rosbank_transfer_" + type + "_group", gr.id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
		if( StrContains( t_send, "������� ���������� ������" ) )
			for( elem in teGroup.collaborators )
				tools.create_notification( "rb_hire_rosbank_transfer_" + type, elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
	}
	
}
function get_sub_staff( id )
{
	id = OptInt( id )
	if( id == undefined )
		return "";
	else
	{
		sub = OpenDoc( UrlFromDocID( id ) ).TopElem;

		dSub = sub;
		nArr = new Array();
		ind = 0
		do
		{
			nArr.push( { name: dSub.name, ind: ind } )
			ind++;
			if( !dSub.parent_object_id.HasValue )
			{
				nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
				break
			}
			else
				dSub = dSub.parent_object_id.OptForeignElem;
		}
		while( true )
		nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
		sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")
		return sub_staff_name;
	}
}

function check_access( type )
{
	if( type == "sogl_manager" )
	{
		if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ) == undefined && requestDoc.TopElem.person_id == curUserID )
			return true
		if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ) == curUserID && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == curUserID && This.begin_state == 'sogl_manager'" ) == undefined )
		{
			return true
		}
		else if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( 'sogl_collaborator_id' ).value ) && This.begin_state == 'sogl_manager'" ) != undefined )
		{

			if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_2" ).value ) == curUserID && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == curUserID && This.begin_state == 'sogl_manager'" ) == undefined )
			{
				return true
			}
			else if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( 'sogl_collaborator_id_2' ).value ) && This.begin_state == 'sogl_manager'" ) != undefined )
			{
				if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_3" ).value ) == curUserID && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == curUserID && This.begin_state == 'sogl_manager'" ) == undefined)
				{
					return true
				}
			}
		}
		return false;
	}
	else
	{
		if( type == "cuchr_go" )
			cond = " $i/code = 'cuchr_go' "
		else if( type == "im" )
			cond = " $i/code = 'international_mobility' "
		else if( type == "hr" )
			cond = " $i/code = 'hr_" + ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ? "go" : "go_net" ) + "' "
		else
			cond = " $i/code = '" + type + "_" + ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ";
		arr = XQuery( "for $i in group_collaborators where " + cond + " and $i/collaborator_id = " + curUserID + " return $i" );
		return ( ArrayOptFirstElem( arr ) != undefined );
	}
}

function add_workflow( obj, st, fin )
{
	fldLogEntryChild = obj.workflow_log_entrys.AddChild();
	fldLogEntryChild.create_date = Date();
	obj.workflow_fields.ObtainChildByKey( fldLogEntryChild.create_date ).value = obj.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value;
	fldLogEntryChild.person_id = curUserID;
	fldLogEntryChild.person_fullname = curUser.fullname;
	fldLogEntryChild.begin_state = st;
	fldLogEntryChild.finish_state = fin;
}
	
arr_need_fields = new Array( 		"collaborator_id", "podbor_for", 		"hub_id", 			"subdivision_after", 				"position_after", 		"position_instruction", 					"type_transfer", 		"gain", 					"forma_hire", 		"justification_acceptance", 		"place_id", 			"pomechenie_id", "is_digital" );

arr_need_field_names = new Array( 	"���", 		"��������� ���", 	"������� ����������� �", 		"������������� ����� ��������", 	"��������� ����� ��������", "������� ����������� ����������",	"��� ��������", 		"����� � ��������� �����", 			"����� �����",  "����������� ��������", 	"������� ����� (�����)", 	"���������, � �������� �����", "Digital" );
MESSAGE = "";

if( action == "sogl_hr" || action == "sogl_svhr" || action == "sogl_staff" )
{
	arr_need_fields.push( "transfer_date" )
	arr_need_field_names.push( "���� ��������" )

	arr_need_fields.push( "finish_date" )
	arr_need_field_names.push( "���� ���������" )
	
	arr_need_fields.push( "city" )
	arr_need_field_names.push( "�����" )

	arr_need_fields.push( "acr" )
	arr_need_field_names.push( "ACR" )

	arr_need_fields.push( "retention" )
	arr_need_field_names.push( "Retention" )
	arr_need_fields.push( "promotion" )
	arr_need_field_names.push( "Promotion" )
	arr_need_fields.push( "za_schet" )
	arr_need_field_names.push( "�� ���� ������" )

	arr_need_fields.push( "stafka_subdivision_id" )
	arr_need_field_names.push( "������������� ��� ������ ������" )
	arr_need_fields.push( "staff_unit_staf_id" )
	arr_need_field_names.push( "����� ������� � ������" )

	arr_need_fields.push( "date_out" )
	arr_need_field_names.push( "���� ������������� ��������" )

	//arr_need_fields.push( "mrot" )
	//arr_need_field_names.push( "��������� ����" )
	if( action == "sogl_hr" || action == "sogl_svhr" )
	{
		arr_need_fields.push( "verification" )
		arr_need_field_names.push( "�����������" )
		if( action == "sogl_svhr" )
		{
			arr_need_fields.push( "verification_result" )
			arr_need_field_names.push( "��������� �������� �����������" )
		}
		arr_need_fields.push( "sb" )
		arr_need_field_names.push( "������ ������������" )
	}
}
if( action == "sogl_dmto" )
{
	arr_need_fields = new Array( 		"pomechenie_id", 				"place_id" );

	arr_need_field_names = new Array( 	"���������, � �������� �����", 	"������� ����� (�����)" );

}
try
{
	arr_not_fields = new Array();
	CONTEXT = tools.read_object( CONTEXT );
	//alert( 'action '+action )
	switch( action )
	{
		case "send_hr":
		case "sogl_hr":
		case "sogl_svhr":
		case "sogl_staff":
		case "sogl_sogl":
		case "sogl_cuchr":
			//arr_not_fields = new Array();
			for( i = 0; i < ArrayCount( arr_need_fields ); i++ )
			{
				if( arr_need_fields[ i ] == "subdivision_after" )
				{
					if( ( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && !tools_web.is_true( CONTEXT.GetOptProperty( "pole_new_subdivision" ) ) ) || ( tools_web.is_true( CONTEXT.GetOptProperty( "pole_new_subdivision" ) ) && String( CONTEXT.GetOptProperty( "pole_subdivision_name" ) ) == "" ) )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "position_after" )
				{
					if( ( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && !tools_web.is_true( CONTEXT.GetOptProperty( "pole_new_position_after" ) ) ) || ( tools_web.is_true( CONTEXT.GetOptProperty( "pole_new_position_after" ) ) && String( CONTEXT.GetOptProperty( "pole_position_after_name" ) ) == "" ) )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "finish_date" )
				{
					if( ( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && ( CONTEXT.GetOptProperty( "pole_forma_hire" ) ) == "1004" || CONTEXT.GetOptProperty( "pole_forma_hire" ) ) == "1005" )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "pomechenie_id" )
				{
					if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && !tools_web.is_true( CONTEXT.GetOptProperty( "pole_place_not_need" ) ) )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "date_out" )
				{
					if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && OptInt( CONTEXT.GetOptProperty( "pole_staff_unit_staf_id" ) ) != undefined )
					{
						try
						{
							teJob = OpenDoc( UrlFromDocID( OptInt( CONTEXT.GetOptProperty( "pole_staff_unit_staf_id" ) ) ) ).TopElem;
							if( teJob.person_full_name != "==��������==" )
								arr_not_fields.push( arr_need_field_names[ i ] );
						}catch( ex ){ alert( ex ) }
					}
						
				}
				else if( arr_need_fields[ i ] == "mrot" )
				{
					if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) == "with" )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "acr" || arr_need_fields[ i ] == "retention" || arr_need_fields[ i ] == "promotion" )
				{
					if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && CONTEXT.GetOptProperty( "pole_za_schet" ) == "" && String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) == "with" )
						if( String( CONTEXT.GetOptProperty( "pole_acr" , "" ) ) == "" && String( CONTEXT.GetOptProperty( "pole_retention" , "" ) ) == "" && String( CONTEXT.GetOptProperty( "pole_promotion" , "" ) ) == "" )
							arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "stafka_subdivision_id" || arr_need_fields[ i ] == "staff_unit_staf_id" )
				{
					if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && CONTEXT.GetOptProperty( "pole_za_schet" ) != "" && String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) == "with" )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( arr_need_fields[ i ] == "za_schet" )
				{
					if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && CONTEXT.GetOptProperty( "pole_acr" ) == "" && CONTEXT.GetOptProperty( "pole_promotion" ) == "" && CONTEXT.GetOptProperty( "pole_retention" ) == "" && String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) == "with" )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
				else if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] , "" ) ) == "" )
					arr_not_fields.push( arr_need_field_names[ i ] );
			}
			//alert(String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) )
			if( CONTEXT.GetOptProperty( "pole_is_digital", "" ) == "yes" )
			{
				if( OptInt( CONTEXT.GetOptProperty( "pole_digital_role_id", "" ) ) == undefined )
					arr_not_fields.push( "���� digital" );
			}
			if( String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) == "with" && String( CONTEXT.GetOptProperty( "pole_gain_after" ) ) == "" )
				arr_not_fields.push( "����� ����� ��������" );
			if( String( CONTEXT.GetOptProperty( "pole_forma_hire" ) ) == "1004" && String( CONTEXT.GetOptProperty( "pole_subdivision_kurator" ) ) == "" )
				arr_not_fields.push( "�������������-�������" );
			if( ( String( CONTEXT.GetOptProperty( "pole_justification_acceptance" ) ) == "2" || String( CONTEXT.GetOptProperty( "pole_justification_acceptance" ) ) == "3" ) && String( CONTEXT.GetOptProperty( "pole_change_collaborator_id" ) ) == "" )
				arr_not_fields.push( "������ ����" );
			if( action == "sogl_hr" || action == "sogl_svhr" )
			{
				if( tools_web.is_true( CONTEXT.GetOptProperty( "pole_change_job" ) ) )
				{
					if( ( String( CONTEXT.GetOptProperty( "pole_new_job_id" ) ) == "" && !tools_web.is_true( CONTEXT.GetOptProperty( "pole_new_job" ) ) ) || ( tools_web.is_true( CONTEXT.GetOptProperty( "pole_new_job" ) ) && String( CONTEXT.GetOptProperty( "pole_new_job_name" ) ) == "" ) )
					{
						if( CONTEXT.GetOptProperty( "out_staff_unit_id" ) != "" )
						{
							if( CONTEXT.GetOptProperty( "pole_position_class_id" ) == "" )
							{
								arr_not_fields.push( "����������� ����� (��)" );
								arr_not_fields.push( "������� ������� �������" );
								arr_not_fields.push( "������ �������" );
							}
						}
					}
				}
				else
				{
					if( CONTEXT.GetOptProperty( "pole_job_id" ) == "" )
						 arr_not_fields.push( "�������" );
				}
			}
		case "send_from_person":
			if( action == "send_from_person" )
			{
				if(  OptInt( CONTEXT.GetOptProperty( "pole_anketa" ) ) == undefined )
					arr_not_fields.push( "������ ��� ��������" );
			}
			
		case "sogl_dmto":
			if( action == "sogl_dmto" )
			{
				arr_not_fields = new Array();
				for( i = 0; i < ArrayCount( arr_need_fields ); i++ )
				{
					if( arr_need_fields[ i ] == "pomechenie_id" )
					{
						if( OptInt( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == undefined && !tools_web.is_true( CONTEXT.GetOptProperty( "pole_place_not_need" ) ) )
							arr_not_fields.push( arr_need_field_names[ i ] );
					}
					else if( OptInt( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] , "" ) ) == undefined )
						arr_not_fields.push( arr_need_field_names[ i ] );
				}
			}
		case "sogl_sb":
		case "reject_sb":
			if( action == "sogl_sb" || action == "reject_sb" )
			{
				if(  OptInt( CONTEXT.GetOptProperty( "pole_utv_sb_id" ) ) == undefined )
					arr_not_fields.push( "������������ ���������� �������� ��" );
				if( CONTEXT.GetOptProperty( "pole_comment_ruk_sb" ) == "" )
					arr_not_fields.push( "����������� ��� ������������ ��" );
			}
			
		case "sogl_utv":
			if( action == "reject_utv" || action == "sogl_utv" )
			{
				if( CONTEXT.GetOptProperty( "pole_comment_sb" ) == "" )
					arr_not_fields.push( "����������� ������ ������������" );
			}
			
			if( ArrayOptFirstElem( arr_not_fields ) != undefined )
			{
				MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
				break;
			}
		case "resend_cuchr":
		case "change_sogl":
		case "save":
			
			object_id = OptInt( object_id )
			requestTypeID = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_transfer' return $i" ) ).id;
			requestTypeDoc = OpenDoc( UrlFromDocID( requestTypeID ) ).TopElem;
			if( object_id == undefined )
			{
				requestDoc = OpenNewDoc( 'x-local://wtv/wtv_request.xmd' );
				requestDoc.BindToDb( DefaultDb );
				
				requestDoc.TopElem.person_id = curUserID;
				tools.common_filling( 'collaborator', requestDoc.TopElem, curUserID, curUser );
				
				tools.common_filling( 'request_type', requestDoc.TopElem, requestTypeID, requestTypeDoc );
				requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
				
				if( OptInt( CONTEXT.GetOptProperty( "pole_collaborator_id" ) ) != undefined )
				{
					requestDoc.TopElem.object_id = OptInt( CONTEXT.GetOptProperty( "pole_collaborator_id" ) );
					tools.object_filling( requestDoc.TopElem.type, requestDoc.TopElem, requestDoc.TopElem.object_id );
				}
			}
			else
				requestDoc = OpenDoc( UrlFromDocID( object_id ) );
				
			if( action == "resend_cuchr" )
			{
				if(  ( CONTEXT.GetOptProperty( "pole_hub_id" ) ) == requestDoc.TopElem.workflow_fields.ObtainChildByKey( "hub_id" ).value && ( CONTEXT.GetOptProperty( "pole_podbor_for" ) ) == requestDoc.TopElem.workflow_fields.ObtainChildByKey( "podbor_for" ).value )
				{
					MESSAGE = "ALERT=" + ( "��� ��������������� ���������� �������� ���� ��������� ��� ��� ������� ����������� �" );
					break;
				}
			}

			if ( ! requestDoc.TopElem.workflow_id.HasValue )
				requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
			workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			function check_sogl_edit( sogl_collaborator_id )
			{
				sogl_collaborator_id = OptInt( sogl_collaborator_id );
				if( sogl_collaborator_id == undefined )
					return true;
				if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == sogl_collaborator_id && This.begin_state == 'sogl_manager'" ) == undefined )
					return true;
				return false;
			}
			if( action == "change_sogl" && requestDoc.TopElem.workflow_state == "sogl_manager" )
			{
					nSogl = true;
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_rosbank_transfer_sogl", OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_2" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_rosbank_transfer_sogl", OptInt(CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_3" ).value ) )
							nSogl = true;
						else if( OptInt( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) ) != undefined && requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_3" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_rosbank_transfer_sogl", OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) ) == undefined || OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) ) == undefined || OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) ) == undefined )
					{
						nSoglId = undefined;
						if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) ) != undefined && check_sogl_edit( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) ) ) )
							nSoglId = OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id", "" ) );
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) ) != undefined && check_sogl_edit( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) ) ) )
							nSoglId = OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2", "" ) );
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) ) != undefined && check_sogl_edit( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) ) ) )
							nSoglId = OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3", "" ) );
						if( nSoglId == undefined )
						{

							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "hr" );
							requestDoc.TopElem.workflow_state = "hr";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							send_notification_pers( "hr" );
						}
					}
					
					
			}

			for( elem in CONTEXT )
			{
				if( StrBegins( elem, "pole_" ) )
				{
					if( elem == "pole_premium" || elem == "pole_mrot" )
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = StrReplace( CONTEXT.GetOptProperty( elem, "" ), ",", "." );
					else
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
					
				}
			}

			requestDoc.Save();
			
			switch( action )
			{
				case "save":
					if( requestDoc.TopElem.workflow_state != "draft" )
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "draft" );
						requestDoc.TopElem.workflow_state = "draft";
					}
					break;
				case "change_sogl":
					MESSAGE = "ALERT=" + ( "��������� ���������" ) + ";OPENURL=view_doc.html?mode=rb_hire_rosbank_transfer&tab=0"
					//tools.create_notification( "rb_hire_rosbank_transfer_sogl" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ), "", requestDoc.DocID, null, requestDoc.TopElem );
					break;
				case "send_hr":
					if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ) != undefined )
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "sogl_manager" );
						requestDoc.TopElem.workflow_state = "sogl_manager";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						tools.create_notification( "rb_hire_rosbank_transfer_sogl" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ), "", requestDoc.DocID, null, requestDoc.TopElem );
					}
					else
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "hr" );
						requestDoc.TopElem.workflow_state = "hr";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "hr" );
					}
					break;
					
				case "sogl_sogl":
					if( !check_access( "sogl_manager" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� ��������;OPENURL=view_doc.html?mode=rb_hire_rosbank_transfer&tab=1";
							break;
						}
					nState = "";
						sogl_id = ""
						if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value ) != undefined )
						{
							nState = "sogl_manager";
							sogl_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value
						}
						else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_3" ).value ) != undefined )
						{
							nState = "sogl_manager";
							sogl_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_3" ).value
						}
						else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_3" ).value ) == curUserID || ( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value ) == undefined ) || ( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_3" ).value ) == undefined ) )
						{
							nState = "hr";
						}
						else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id" ).value ) == undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_3" ).value ) == undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_collaborator_id_2" ).value ) == undefined )
						{
							nState = "hr";
						}
						if( nState == "" )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� ��������;OPENURL=view_doc.html?mode=rb_hire_rosbank_transfer&tab=1";
							break;
						}

						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, nState );
						requestDoc.TopElem.workflow_state = nState;
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						
						if( nState == "hr" )
						{
							/*add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "hr" );
							requestDoc.TopElem.workflow_state = "hr";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );*/
							send_notification_pers( "hr" );
						}
						else
						{
							tools.create_notification( "rb_hire_rosbank_transfer_sogl", sogl_id, "", requestDoc.DocID, null, requestDoc.TopElem );
						}
						if( MESSAGE != "" )
							requestDoc.Save();
				
					
					tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					
					break;
					
				case "sogl_hr":
					if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "type_transfer" ).value == "with" )
					{
						requestDoc.TopElem.doc_info.creation.app_instance_id += ",ukil";
						send_notification_pers( "ukil" );
					}
					if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "verification" ).value == "yes" )
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "person" );
						requestDoc.TopElem.workflow_state = "person";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						tools.create_notification( "rb_hire_rosbank_transfer_person" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "collaborator_id" ).value ), "", requestDoc.DocID, null, requestDoc.TopElem );
					
					}
					else
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "dmto" );
						requestDoc.TopElem.workflow_state = "dmto";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "dmto" );
					}
					tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;
				case "send_from_person":

					add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "sv_hr" );
					requestDoc.TopElem.workflow_state = "sv_hr";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					send_notification_pers( "svhr" );
					send_notification_pers( "rosbank_verification" );
					tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;

				case "sogl_svhr":
					if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "verification_result" ).value == "yes" &&  requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sb" ).value == "no" )
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "dmto" );
						requestDoc.TopElem.workflow_state = "dmto";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "dmto" );
					}
					else
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "sb" );
						requestDoc.TopElem.workflow_state = "sb";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "sb" );
					}
					tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;
					
				case "sogl_sb":
				case "reject_sb":
					//requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_check_sb" ).value = action == "sogl_sb" ? "�����������" : "���������" 
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_in_sb" ).value = action == "sogl_sb" ? "yes" : "no" 
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_in_sb_fullname" ).value = curUser.fullname
					
					add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "sb_utv" );
					requestDoc.TopElem.workflow_state = "sb_utv";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					tools.create_notification( "rb_hire_rosbank_transfer_sb_utv" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "utv_sb_id" ).value ), "", requestDoc.DocID, null, requestDoc.TopElem );
					//tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;

				case "reject_utv":
				case "sogl_utv":
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_check_sb" ).value = action == "sogl_utv" ? "�����������" : "���������";
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_check_sb_fullname" ).value = curUser.fullname
					add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "dmto" );
					requestDoc.TopElem.workflow_state = "dmto";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					send_notification_pers( "dmto" );
					send_notification_pers( "hr_sogl_utv" );
					tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;
					
				case "sogl_dmto":
					if( tools_web.is_true( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "change_job" ).value ) )
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "staff" );
						requestDoc.TopElem.workflow_state = "staff";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "staff" );
						
					}
					else
					{
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "cuchr" );
						requestDoc.TopElem.workflow_state = "cuchr";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "cuchr" );
						

					}
					tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;
				case "sogl_staff":
				case "resend_cuchr":
					add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "cuchr" );
					requestDoc.TopElem.workflow_state = "cuchr";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					send_notification_pers( "cuchr" );
					if( action == "sogl_staff" )
						tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;
				case "sogl_cuchr":
					add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "in_job" );
					requestDoc.TopElem.workflow_state = "in_job";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					tools.create_notification( "rb_hire_rosbank_transfer_job" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
                    if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ) != undefined ){
                        tools.create_notification( "rb_hire_rosbank_transfer_job" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value ), curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
                    }
                    if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_2" ).value ) != undefined ){
                        tools.create_notification( "rb_hire_rosbank_transfer_job" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_2" ).value ), curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
                    }	
                    if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_3" ).value ) != undefined ){
                        tools.create_notification( "rb_hire_rosbank_transfer_job" , OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_3" ).value ), curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
                    }					
					//send_notification_pers( "job_hr" )
					if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "type_transfer" ).value == "with" )
						send_notification_pers( "job_ukil" );
					//tools.create_notification( "rb_hire_rosbank_transfer_person_sogl" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
					break;
			}

			if( CONTEXT.GetOptProperty( "comment_transfer", "" ) != "" )
			{

				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "comment_transfer" ).value += ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "comment_transfer" ).value != "" ? "<br>" : "" ) + curUser.fullname + ": " + StrReplace( CONTEXT.GetOptProperty( "comment_transfer", "" ), "\n", "<br>" )
			}


			if( MESSAGE == "" )
			{
				requestDoc.Save();
				if( action == "save" || action == "send_hr" || action == "change_sogl" )
					MESSAGE = "OPENURL=view_doc.html?mode=rb_hire_rosbank_transfer&tab=0"
				else
					MESSAGE = "OPENURL=view_doc.html?mode=rb_hire_rosbank_transfer&tab=1"
			}
			
			break;
			
		case "select_collaborator_id":
			coll_id = OptInt( CONTEXT.GetOptProperty( "pole_collaborator_id" ) );
			try{
				teColl = OpenDoc( UrlFromDocID( coll_id ) ).TopElem
				MESSAGE = "SET=pole_CollaboratorPositionName," + teColl.position_name + ";SET=pole_CollaboratorPositionParentName," + get_sub_staff(  teColl.position_parent_id ) + ";"
			}
			catch( ex )
			{
				MESSAGE = "SET=pole_CollaboratorPositionName,;SET=pole_CollaboratorPositionParentName,;"
			}
			break;

		case "check_za_schet":
			if(  OptInt( CONTEXT.GetOptProperty( "pole_za_schet" ) ) <10 && String( CONTEXT.GetOptProperty( "pole_type_transfer" ) ) == "with" )
				MESSAGE = "HIDE=StackPanelZaSchet;"
				
			break;

		case "pole_staff_unit_staf_id":
			job_id = OptInt( CONTEXT.GetOptProperty( "pole_staff_unit_staf_id" ) );
			try{
				teJob = OpenDoc( UrlFromDocID( job_id ) ).TopElem
				if( teJob.person_full_name != "==��������==" )
					MESSAGE = "SHOW=StackPanelDateOut;"
				else
					MESSAGE = "HIDE=StackPanelDateOut;"
			}
			catch( ex )
			{
				MESSAGE = "HIDE=StackPanelDateOut;"
			}

		case "pole_staff_unit":
		case "pole_out_staff_unit_id":
		
			res = "";
			position_name = "";
			if( OptInt( CONTEXT.GetOptProperty( (( action == "pole_staff_unit" ? "pole_job_id" : action) ), "" ) ) != undefined )
			{
				d = OpenDoc( UrlFromDocID( OptInt( CONTEXT.GetOptProperty( ( action == "pole_staff_unit" ? "pole_job_id" : action), "" ) ) ) ).TopElem;
				res = d.job_name + "(" + d.person_full_name + ", ���. � " + d.assignment_number + "), ����� " + d.grade + ", �� " + d.position_class;
				position_name = StrReplace( StrReplace( d.position_name, ",", UrlEncode( "," ) ), ";", UrlEncode( ";" ) );
			}
			MESSAGE += "SET=" + ( action == "pole_staff_unit" ? "pole_job_name," : action == "pole_staff_unit_staf_id" ? "pole_staff_unit_staf_name," : "pole_out_staff_unit_name," ) + StrReplace( StrReplace( res, ",", UrlEncode( "," ) ), ";", UrlEncode( ";" ) )  + ";SET=" + ( action == "pole_staff_unit" ? "pole_job_position_name," : action == "pole_staff_unit_staf_id" ? "pole_staff_unit_staf_position_name," : "pole_out_staff_unit_position_name," ) + position_name;
			
			break;

		case "check_position_class":
			class_id = OptInt( CONTEXT.GetOptProperty( "pole_position_class_id" ) );
			try{
				teClass = OpenDoc( UrlFromDocID( class_id ) ).TopElem
				if( teClass.grade_id.HasValue )
					MESSAGE = "SET=GradeName," + UrlEncode( teClass.grade_id.ForeignElem.name )
				else
					MESSAGE = "SET=GradeName,;"
			}
			catch( ex )
			{
				MESSAGE = "SET=GradeName,;"
			}
			break;

		case "check_grade":
			try
			{
				dPC = OpenDoc( UrlFromDocID( Int( CONTEXT.GetOptProperty( "pole_position_class_id", "" ) ) ) ).TopElem;
				if( dPC.grade.HasValue )
				{
					//dGrade = OpenDoc( UrlFromDocID( Int( dPC.grade_id ) ) ).TopElem;
					MESSAGE = "SET=GradeName," + dPC.grade + ";SET=PositionClassName," + dPC.pozi_klass;
				}
			}
			catch( ex ){ alert( ex ); MESSAGE = "SET=pole_grade_hire_id,;SET=GradeHire,;SET=PositionClass,;"; }
			break;
			
		case "reject":
		case "reject_utv":
			arr_not_fields = new Array();
			if( action == "reject_utv" || action == "sogl_utv" )
			{
				if( CONTEXT.GetOptProperty( "pole_comment_sb" ) == "" )
					arr_not_fields.push( "����������� ������ ������������" );
			}
			
			if( ArrayOptFirstElem( arr_not_fields ) != undefined )
			{
				MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
				break;
			}
			
			object_id = OptInt( object_id )
			requestDoc = OpenDoc( UrlFromDocID( object_id ) );
			workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			for( elem in CONTEXT )
			{
				if( StrBegins( elem, "pole_" ) )
				{
					if( elem == "pole_premium" || elem == "pole_mrot" )
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = StrReplace( CONTEXT.GetOptProperty( elem, "" ), ",", "." );
					else
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
					
				}
			}
			if( action == "reject_utv" )
			{
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_check_sb" ).value = action == "sogl_utv" ? "�����������" : "���������";
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "result_check_sb_fullname" ).value = curUser.fullname
			}
			if( requestDoc.TopElem.workflow_state == "sb_utv" )
			{
				type = "hr"
				if( ( type == "svhr" || type == "hr" ) && ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
					cond = " $i/code = 'hr_go' "
				else
                cond = " $i/code = '" + ( type == "svhr" ? "hr" : type ) + "_" + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value + "' ";
				arr = XQuery( "for $i in group_collaborators where " + cond + " return $i" );
				for( gr in ArraySelectDistinct( arr, "This.group_id" ) )
				{
					teGroup = OpenDoc( UrlFromDocID( gr.group_id ) ).TopElem;
					t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
					if( StrContains( t_send, "�� ����� �����" ) )
						tools.create_notification( "rb_hire_rosbank_transfer_hr_reject_utv_group", gr.group_id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
					if( StrContains( t_send, "������� ���������� ������" ) )
						for( elem in ArraySelect( arr, "This.group_id == gr.group_id" ) )
							tools.create_notification( "rb_hire_rosbank_transfer_hr_reject_utv", elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
				}
			}	
			add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "reject" );
			requestDoc.TopElem.workflow_state = "draft";
			requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
		
			
			requestDoc.TopElem.doc_info.creation.app_instance_id += "," + ArrayMerge( requestDoc.TopElem.workflow_log_entrys, "This.person_id", "," );
			if( !StrContains( requestDoc.TopElem.doc_info.creation.app_instance_id, String( curUserID ) ) )
				requestDoc.TopElem.doc_info.creation.app_instance_id += "," + curUserID;
			try
			{
				log_states = new Array();
				if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
					log_states = OpenDocFromStr( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
				if( ArrayOptFirstElem( log_states ) != undefined )
				{
					cnt = 0;
					for( e in log_states )
					{
						_ch = requestDoc.TopElem.workflow_log_entrys.AddChild();
						_ch.AssignElem( e );
						_ch.SetChildIndex( cnt );
						cnt++;
					}
				}
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value = requestDoc.TopElem.workflow_log_entrys.Xml;
			}
			catch( err ){ alert( err ); }
			requestDoc.TopElem.workflow_log_entrys.Clear();

			if( CONTEXT.GetOptProperty( "comment_transfer", "" ) != "" )
			{

				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "comment_transfer" ).value += ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "comment_transfer" ).value != "" ? "<br>" : "" ) + curUser.fullname + ": " + StrReplace( CONTEXT.GetOptProperty( "comment_transfer", "" ), "\n", "<br>" )
			}

			requestDoc.Save();

			tools.create_notification( "rb_hire_rosbank_transfer_reject" , requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );

			MESSAGE = "ALERT=������ �� ������� ���������;OPENURL=view_doc.html?mode=rb_hire_rosbank_transfer&tab=1;";

			break;

		case "check_digital":
			iDigitalID = OptInt( CONTEXT.GetOptProperty( "pole_digital_role_id" ) );
			if( iDigitalID != undefined )
			{
				teDigital = OpenDoc( UrlFromDocID( iDigitalID ) ).TopElem;

				MESSAGE = "SHOW=DigitalDesc;SET=pole_digital_desc," +  StrReplace( StrReplace( StrReplace( HtmlToPlainText(  StrReplace( StrReplace( teDigital.desc, "</p>", "$$$$" ), "<p>", "" ) ), ";", "%3B" ), ",", "%2C" ), "$$$$", "\n" )+ ";"
			}
			else
				MESSAGE = "HIDE=DigitalDesc;SET=pole_digital_desc,;"
			
			break;
			
		case "sogl_collaborator_id_2":
		case "sogl_collaborator_id_3":
		case "sogl_collaborator_id":
			MESSAGE = "";
			p_id = OptInt( CONTEXT.GetOptProperty( "Tmp" ) );
			if( p_id == undefined )
			{
				switch( action )
				{
					case "sogl_collaborator_id":
						MESSAGE = "SET=pole_sogl_collaborator_id,;SET=SoglCollaboratorName,;HIDE=StackPanelSoglCollab2;"
					case "sogl_collaborator_id_2":
						MESSAGE += "SET=pole_sogl_collaborator_id_2,;SET=SoglCollaboratorName2,;HIDE=StackPanelSoglCollab3;"
					case "sogl_collaborator_id_3":
						MESSAGE += "SET=pole_sogl_collaborator_id_3,;SET=SoglCollaboratorName3,;"
						break;
				}
				if( MESSAGE != "" )
					break;
			}
			switch( action )
			{
				case "sogl_collaborator_id_3":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2" ) ) == undefined )
					{
						MESSAGE = "ALERT=���������� ������� ������� ������������ �� ������������� 2;"
						break;
					}
				case "sogl_collaborator_id_2":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id" ) ) == undefined )
					{
						MESSAGE = "ALERT=���������� ������� ������� ������������ �� �������������;"
						break;
					}
					break;
			}
			if( MESSAGE != "" )
				break;
			
			switch( action )
			{
				case "sogl_collaborator_id_3":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
				case "sogl_collaborator_id_2":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
				case "sogl_collaborator_id":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_2" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_collaborator_id_3" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
			}
			if( MESSAGE != "" )
				break;
				
			teUser = OpenDoc( UrlFromDocID( p_id ) ).TopElem;
			switch( action )
			{
				case "sogl_collaborator_id_3":
					MESSAGE = "SET=pole_sogl_collaborator_id_3," + p_id + ";SET=SoglCollaboratorName3," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
				case "sogl_collaborator_id_2":
					MESSAGE = "SHOW=StackPanelSoglCollab3;SET=pole_sogl_collaborator_id_2," + p_id + ";SET=SoglCollaboratorName2," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
				case "sogl_collaborator_id":
					MESSAGE = "SHOW=StackPanelSoglCollab2;SET=pole_sogl_collaborator_id," + p_id + ";SET=SoglCollaboratorName," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
			}
				
			break;

	}
	//alert('MESSAGE '+MESSAGE)
}
catch( ex )
{
	alert( ex );
	MESSAGE = "ALERT=��������� ������ ��� ���������� ��������. ���������� � ��������������.;REFRESH;";
}