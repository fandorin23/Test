//��������� �������� ��� ������� ( ������������ ������ )
/*
	<wvars>
		<wvar>
			<name>vacancy</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>start_date</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>finish_date</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>group</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>action</name>
			<type>string</type>
			<position>5</position>
		</wvar>
		<wvar>
			<name>file_name</name>
			<type>string</type>
			<position>6</position>
		</wvar>
	</wvars>
*/
var curFile = "hire\remote_actions\rb_hire_rosbank_diver_report_action.js";

function get_value( name, top_elem )
{
	if( top_elem == null )
		return "";
	if( top_elem.workflow_fields.GetOptChildByKey( name ) != undefined )
		return top_elem.workflow_fields.GetOptChildByKey( name ).value;
	else if( top_elem.custom_elems.GetOptChildByKey( name ) != undefined )
		return top_elem.custom_elems.GetOptChildByKey( name ).value;
	else
		return "";
}

function get_podbor_date( top_elem )
{
	if( top_elem == null )
		return "";
	log_states = new Array();
	tmpWLEArr = top_elem.workflow_log_entrys.Clone();
	if( get_value( "workflow_log_entrys", top_elem ) != "" )
	{
		log_states = OpenDocFromStr( get_value( "workflow_log_entrys", top_elem ) ).TopElem;

		tmpWLEArr.AssignElem( log_states )
	}
	arr = ArraySelect( tmpWLEArr, "This.finish_state == 'podbor'" );
	if( ArrayOptFirstElem( arr ) != undefined )
		return ArrayMax( arr, "This.create_date" ).create_date;
		
	return "";
}

function get_start_date( top_elem )
{
	log_states = new Array();
	tmpWLEArr = top_elem.workflow_log_entrys.Clone();
	if( get_value( "workflow_log_entrys", top_elem ) != "" )
	{
		log_states = OpenDocFromStr( get_value( "workflow_log_entrys", top_elem ) ).TopElem;

		tmpWLEArr.AssignElem( log_states )
	}
	arr = ArraySelect( tmpWLEArr, "This.finish_state == 'sogl_manager'" );
	if( ArrayOptFirstElem( arr ) != undefined )
		return ArrayMax( arr, "This.create_date" ).create_date;
		
	arr = ArraySelect( tmpWLEArr, "This.finish_state == 'hr'" );
	if( ArrayOptFirstElem( arr ) != undefined )
		return ArrayMax( arr, "This.create_date" ).create_date;
	return "";
}
function get_finish_sogl( top_elem )
{
	wle = ArrayOptFind( top_elem.workflow_log_entrys, "This.finish_state == 'sogl_manager'" );
	if( wle != undefined )
	{
		wle = ArrayOptFind( top_elem.workflow_log_entrys, "This.finish_state == 'hr'" );
		if( wle != undefined )
			return wle.create_date
	}
	return "";
}

function get_start_podbor( top_elem )
{
	wle = ArrayOptFind( top_elem.workflow_log_entrys, "This.finish_state == 'podbor'" );
	if( wle != undefined )
		return wle.create_date;
	return "";
}

function get_hr_fullname( top_elem )
{
	wle = ArrayOptFind( top_elem.workflow_log_entrys, "This.finish_state == 'podbor'" );
	if( wle != undefined )
		return wle.person_fullname;
	return "";
}
function get_staff( top_elem )
{
	try
	{
		if( OptInt( top_elem.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) == 1 || top_elem.workflow_fields.ObtainChildByKey( "new_subdivision" ).value == "true" )
		{
			subname = top_elem.workflow_fields.ObtainChildByKey( "subdivision_name" ).value
			return subname;
		}
		else
		{
			sub = OpenDoc( UrlFromDocID( Int( top_elem.workflow_fields.ObtainChildByKey( "subdivision_id" ).value ) ) ).TopElem;

			dSub = sub;
			nArr = new Array();
			ind = 0
			do
			{
				nArr.push( { name: dSub.name, ind: ind } )
				ind++;
				if( !dSub.parent_object_id.HasValue )
				{
					nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
					break
				}
				else
					dSub = dSub.parent_object_id.OptForeignElem;
			}
			while( true )
			nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
			sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")

			return sub_staff_name;
		}
	}
	catch( ex ){alert("hire\remote_actions\rb_hire_rosbank_diver_report_action.js function get_staff error: " + ex) ; return ""; }
}
function get_oodo( name )
{
	arr = String( name ).split( " -> " );
	if( ArrayOptFind( arr, "StrContains( This, '�������������� ����', true ) || StrContains( This, '������������ ����', true )" ) != undefined && ArrayOptFind( arr, "StrContains( This, '��������������� ����', true )" ) == undefined )
		return ArrayOptFind( arr, "StrContains( This, '�������������� ����', true ) || StrContains( This, '������������ ����', true )" );
	return "";
}

function get_finish_period( d, cnt )
{
	if( d == "" )
		return "";
	buf = 0;
	fd = d;
	do
	{
		fd = DateOffset( fd, 86400 );
		if( WeekDay( fd ) != 6 && WeekDay( fd ) != 0 )
			buf++;
	}
	while( buf < cnt )
	return DateNewTime( fd, 23, 59, 59 );
}

function get_diff_days( d1, d2 )
{
	try{
		d1 = Date( d1 )
	}
	catch( ex ){
		return 0;
	}
	try{
		d2 = Date( d2 )
	}
	catch( ex ){
		return 0
	}
	buf = 0;
	while( d1 < d2 )
	{
		d1 = DateOffset( d1, 86400 );
		if( WeekDay( d1 ) != 6 && WeekDay( d1 ) != 0 )
			buf++;
	}
	return buf;
}
function get_avg_days( arr )
{
		var cnt = 0;
		var iDiff = 0;
		for( el in arr )
		{
			if( !el.finish_date.HasValue )
				continue;
			iDiff += get_diff_days( el.event_date, ( el.finish_date.HasValue ? el.finish_date : Date() ) );
			cnt++;
		}
		//alert( 'cnt ' + cnt )
		if( cnt == 0 )
			return 0;
		return Int( iDiff/cnt );
}

function get_normative( arr, stDate, iDay )
{
	if( stDate == "" )
		return ArrayCount( ArraySelectDistinct( arr, "This.candidate_id" ) ) >= 5 ? "��" : "���";
	finDate = get_finish_period( stDate, iDay )
	return ArrayCount( ArraySelectDistinct( ArraySelect( arr, "This.event_date >= stDate && This.event_date <= finDate" ), "This.candidate_id" ) ) >= 5 ? "��" : "���";
}

function get_hire_create_date( id )
{
	if( catHire == undefined )
		return "";
	//teHireRequest = OpenDoc( UrlFromDocID( catHire.id ) ).TopElem;
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'sogl_manager'" );
	if( crSt != undefined )
		return crSt.create_date;
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'hr'" );
	if( crSt != undefined )
		return crSt.create_date;
	return "";
}

function get_hire_sogl_date()
{
	if( catHire == undefined )
		return "";
	//teHireRequest = OpenDoc( UrlFromDocID( catHire.id ) ).TopElem;
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'sogl_manager'" );
	if( crSt != undefined )
	{
		crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'hr'" );
		if( crSt != undefined )
			return crSt.create_date;
	}
	return "";
}
function get_hire_diff_sogl_date()
{
	if( catHire == undefined )
		return "";
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'hr'" );
	if( crSt != undefined )
	{
		finSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.begin_state == 'hr'" );
		finSt = finSt == undefined ? Date() : finSt.create_date;
		return DateDiff( finSt, crSt.create_date ) > 86400*2 ? "��" : "";
	}
	return "";
}

function get_hire_hr_sogl_date()
{
	if( catHire == undefined )
		return "";
	//teHireRequest = OpenDoc( UrlFromDocID( catHire.id ) ).TopElem;
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'dmto'" );
	if( crSt != undefined )
		return crSt.create_date;
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'cuchr'" );
	if( crSt != undefined )
		return crSt.create_date;
	return "";
}
function get_hire_hr_sogl_fullname()
{
	if( catHire == undefined )
		return "";
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.begin_state == 'hr'" );
	if( crSt != undefined )
		return crSt.person_fullname;
	return "";
}
function get_obj_sogl( name_state )
{
	obj = new Object();
	obj.create_date = "";
	obj.person_fullname = "";
	obj.is_two_day = "";
	if( catHire == undefined )
		return obj;
	//teHireRequest = OpenDoc( UrlFromDocID( catHire.id ) ).TopElem;
	crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.begin_state == name_state" );
	if( crSt == undefined )
		return obj;
	obj.create_date = crSt.create_date;
	obj.person_fullname = crSt.person_fullname;
	crStFin = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == name_state" );
	obj.is_two_day = ( DateDiff( crSt.create_date, ( crStFin != undefined ?  crStFin.create_date : Date() ) ) > 86400*2 ? "��" : "" );
	return obj;
}

function get_long( arr )
{
	try
	{
		return ArrayCount( ArraySelect( arr, "This.event_date.HasValue ? ( DateDiff( ( This.finish_date.HasValue ? This.finish_date : Date() ), This.event_date ) > ( 86400*2 ) ) : false" ) );
	}
	catch( ex )
	{
		alert( curFile  + ex );
		return 0;
	}
	
}

function create_report(Param_vacancy_id, Param_person_id,Param_start_date, Param_finish_date,Param_group, Param_vacancy,Param_file_name){
	try{
	alert(curFile + " ������������ ������ start" );
	user_id = OptInt( Param_person_id );
	//_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : "http://" ) + global_settings.settings.recruitment.estaff_server_url;
	//_url = "http://62.152.60.4:9000"
	_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
	
	resp = HttpRequest( UrlAppendPath( _url, '/rosbank_report_service.xml?method=get_vacancys_data&start_date=' + Param_start_date + '&finish_date=' + Param_finish_date + '&vacancy_id=' + Param_vacancy +'&group=' + Param_group) , 'post' );
	
	var oExcelDoc = new ActiveXObject("Websoft.Office.Excel.Document");
	oExcelDoc.Open( AppDirectoryPath() + "\\wt\\web\\webtutor\\rbReportsTemplates\\report_rosbank.xlsx" );
	new_name = AppDirectoryPath() + "\\wt\\web\\reports\\" + Param_file_name;
	
	var oWorksheet = oExcelDoc.GetWorksheet( 0 );
	arr_fields = new Array( "code", "start_date" );
	arr_exlel_fields = new Array( "A", "B" );
	
	num = 2;
	catHireType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_hire' return $i" ) );
	//alert(resp.Body)
	var teHireRequest = null;
	arrColumns = new Array( "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AU", "AV", "AW", "AX", "AY", "AZ", "BA", "BB", "BC", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BK", "BL", "BM", "BN", "BO", "BP", "BQ", "BR", "BS", "BT", "BU", "BV", "BW", "BX", "BY", "BZ", "CA", "CB", "CC", "CD", "CE", "CF", "CG", "CH", "CI", "CJ", "CK", "CL", "CM", "CN", "CO", "CP", "CQ", "CR", "CS", "CT", "CU", "CV", "CW", "CX", "CY", "CZ" )
	for( elem in OpenDocFromStr( resp.Body ).TopElem )
	{
		column_num = 0;
		catHire = undefined;
		teRequest = null;
		try
		{
			teRequest = OpenDoc( UrlFromDocID( Int( elem.id ) ) ).TopElem;
		}
		catch( ex ){}
		
		xarrEvents = new Array();
		if( teRequest != null )
			xarrEvents = XQuery( "for $i in cc_estaff_events where $i/vacancy_id = " + elem.id + " return $i" );	
		
		dStartDate = "";
		if( teRequest != null )
		{ 
			//alert(teRequest.code + '  ' + elem.id)
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest.code;
			column_num++;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
			
			dStartDate = get_start_date( teRequest );
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = dStartDate;
			column_num++;

			// ������ � ��� ���������� ������
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest.person_fullname;
			column_num++;

			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_value( "justification", teRequest ) == "new" ? "����� ��������" : get_value( "justification", teRequest ) == "replace" ? "������" :  get_value( "justification", teRequest ) == "parental_leave" ? "������" : "";
			column_num++;
			if( get_value( "justification", teRequest ) == "replace" || get_value( "justification", teRequest ) == "parental_leave" )
				try
				{
					oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = OpenDoc( UrlFromDocID( Int( get_value( "change_collaborator_id", teRequest ) ) ) ).TopElem.fullname;
				}
				catch( ex ){}
			column_num++;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_finish_sogl( teRequest );
			column_num++;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_start_podbor( teRequest );
			column_num++;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_hr_fullname( teRequest );
			column_num++;
			try
			{
				oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = DateDiff(  get_finish_sogl( teRequest ), get_start_podbor( teRequest ) ) > ( 86400*2 ) ? "��" : "���";
			}
			catch( ex )
			{}
			column_num++;
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest.workflow_state_name;
			column_num++;
		}
		else
			column_num+=9;
			
		teHireRequest = null;
		//alert("for $i in requests where $i/object_id = " + elem.id + " and $i/request_type_id = " + catHireType.id + " return $i" )
		catHire = ArrayOptFirstElem(
      XQuery(
        "for $i in requests where $i/object_id = " +
          elem.id +
          " and $i/request_type_id = " +
          catHireType.id +
          " and $i/workflow_state != 'cancel' return $i"
      )
    );
		if( catHire != undefined ){
			try {
				teHireRequest = OpenDoc( UrlFromDocID( catHire.id ) ).TopElem;
			} catch (error) {
				alert("hire/remote_actions/rb_hire_rosbank_diver_report_action.js error: \n " + catHire.id + error);
			}			
		}
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.start_date;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.group;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.start_job_date;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.recr;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.state;
		column_num++;

		// ���� "Digital" ("��" : "���")
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ( tools_web.is_true( elem.is_digital ) ? "��" : "���" );
		column_num++;

		// ���� "�������� �������" (Value)
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_value( "new_command", teRequest ) == '1' ? get_value( "command_name", teRequest ) : get_value( "command_id", teRequest ) != "" ? OpenDoc( UrlFromDocID( Int( get_value( "command_id", teRequest )))).TopElem.name : "";
		column_num++;

		// ���� "���� Digital" (Value)
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.digital_role;
		column_num++;

		// ���� "������ ������" ("� �����", "���������������", "�������������")
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_value( "format_of_work", teRequest ) == "office" ? "� �����" : get_value( "format_of_work", teRequest ) == "combo" ? "���������������: ����/home" :  get_value( "format_of_work", teRequest ) == "dist" ? "�������������: ��� �����" : "";
		column_num++;

		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.job_name;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.recruit_type_id;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.region;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ( tools_web.is_true( teRequest.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) ? "��" : "���" ) : "���";
		column_num++;
		
		sub_staff_name = teRequest != null ? get_staff( teRequest ) : elem.sub_staff_name;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = sub_staff_name;
		column_num++;
		
		if(  teRequest != null )
		{
			if( tools_web.is_true( teRequest.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) )
				column_num+=10;
			else
			{
				arrSubs = String( sub_staff_name ).split( " -> " );
				for( i = 0; i < 10; i++ )
				{
					if( ArrayCount( arrSubs ) > i )
						oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = arrSubs[ i ];
					column_num++;
				}
			}
		}
		else
			column_num+=10;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_value( "terr_office_name", teRequest ) != "" ? get_value( "terr_office_name", teRequest ) : elem.terr_office;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_oodo( sub_staff_name );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.tel_cnt;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.tel_suc_cnt;
		column_num++;
		//oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.tel_avg_days;
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'event_type_2'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_avg_days( tmpArr );
		
		column_num++;
		
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'event_type_1'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ArrayCount( tmpArr ) : elem.resume_cnt;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		dFirstResume = teRequest != null ? ( ArrayOptFirstElem( tmpArr ) != undefined ? ArrayMin( tmpArr, "This.event_date" ).event_date : "" ) : elem.first_resume;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = dFirstResume;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_diff_days( elem.start_job_date, dFirstResume );
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_normative( tmpArr, get_podbor_date( teRequest ), 10 );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_long( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ArrayCount( ArraySelect( tmpArr, "This.event_status == '�����������'" ) ) : elem.resume_suc_cnt;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_avg_days( tmpArr )
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.interv_cnt;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.interv_suc_cnt;
		column_num++;
		
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'event_type_4'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ArrayCount( tmpArr ) : elem.rukinterv_cnt;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ( ArrayCount(  ArraySelect( tmpArr, "This.event_status == '�����������' || This.event_status == '���������'" ) ) ) : elem.rukinterv_fin_cnt;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_long( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ArrayCount( ArraySelect( tmpArr, "This.event_status == '�����������'" ) ) : elem.rukinterv_suc_cnt;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_avg_days( tmpArr );
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.nsb_cnt;
		column_num++;
		
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'rosbank_verification'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_long( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount(  ArraySelect( tmpArr, "This.event_status == '�����������'" ) );
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_avg_days( tmpArr );
		column_num++;
		
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'rosbank_arbitrazh_sb'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount(  ArraySelect( tmpArr, "This.event_status == '�����������'" ) );
		column_num++;
	
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'event_type_6'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount( tmpArr );
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_long( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount(  ArraySelect( tmpArr, "This.event_status == '�����������'" ) );
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_avg_days( tmpArr );
		column_num++;
		
	
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'rb_event_type_7'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount( tmpArr );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = ArrayCount(  ArraySelect( tmpArr, "This.event_status == '�����������'" ) );
		column_num++;
		
		// ���������� ����������
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'event_type_7'" )
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? ArrayCount( tmpArr ) : elem.fin_cnt;
		column_num++;

		// ��� ���������� ��������� 
		tmpArr = ArraySelect( xarrEvents, "This.event_type == 'event_type_7'")
		tmpArr_2 = ArrayOptMax(tmpArr, 'event_date')
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? (tmpArr_2 != undefined ? tmpArr_2.candidate_name : "") : "";
		column_num++;
		
		// ���� �������� ������� "��������"
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		iCandidateID = teHireRequest != null ? OptInt( teHireRequest.workflow_fields.ObtainChildByKey( "final_candidate" ).value ) : undefined;
		finalist_date = iCandidateID != undefined ? ( ArrayOptFind( elem.finalists, "This.id == '" + iCandidateID + "'" ) != undefined ? ArrayOptFind( elem.finalists, "This.id == '" + iCandidateID + "'" ).date : "" ) : "";
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = finalist_date;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value =teHireRequest != null && finalist_date != "" ? get_diff_days( finalist_date, teHireRequest.create_date ) : "";
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.samo_cnt;
		column_num++;
		
		dHireCreateDate = teRequest != null ? get_hire_create_date( elem.id ) : ""
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = dHireCreateDate;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? get_hire_sogl_date() : "";
		column_num++;
	
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teRequest != null ? get_hire_diff_sogl_date() : "";
		column_num++;
		
		oSogl = get_obj_sogl( "hr" );
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.create_date;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.person_fullname;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.is_two_day;
		column_num++;
		
		oSogl = get_obj_sogl( "dmto" );
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.create_date;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.person_fullname;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.is_two_day;
		column_num++;
		
		oSogl = get_obj_sogl( "staff" );
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.create_date;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.person_fullname;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.is_two_day;
		column_num++;
		
		oSogl = new Object();
		oSogl.create_date = "";
		oSogl.person_fullname = "";
		oSogl.is_two_day = "";
		if( catHire != undefined )
		{
			//teHireRequest = OpenDoc( UrlFromDocID( catHire.id ) ).TopElem;
			crSt = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'candidate'" );
			if( crSt != undefined )
			{
				oSogl.create_date = crSt.create_date;
				oSogl.person_fullname = crSt.person_fullname;
				crStFin = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == crSt.begin_state" );
				oSogl.is_two_day = crStFin != undefined ? ( DateDiff( crSt.create_date, crStFin.create_date ) > 86400*2 ? "��" : "" ) : "";
			}
		}
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.create_date;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.person_fullname;
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = oSogl.is_two_day;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Style.Number = 22;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.est_empl_start_date;
		column_num++;
		
		catResponse = ArrayOptFirstElem( XQuery( "for $i in responses where $i/response_type_id = 6468483627597960302 and $i/object_id = " + elem.id + " return $i" ) )
		if( catResponse !=undefined )
			try
			{
				teResponse = OpenDoc( UrlFromDocID( catResponse.id ) ).TopElem;
				oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = teResponse.custom_elems.ObtainChildByKey( "rosbank_recr" ).value;
			}
			catch( ex ){}
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.cs_manager_response;
		column_num++;
		
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = elem.finish_date;
		column_num++;
	
			oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_diff_days( elem.start_date, dHireCreateDate );
		column_num++;
		oWorksheet.Cells.GetCell( arrColumns[ column_num ] + num ).Value = get_diff_days( dHireCreateDate, elem.est_empl_start_date );
		column_num++;
	
		/*
		for( i = 0; i < ArrayCount( arr_fields ); i++ )
		{
			if( elem.OptChild( arr_fields[ i ] ) != undefined )
				oWorksheet.Cells.GetCell( arr_exlel_fields[ i ] + num ).Value = elem.Child( arr_fields[ i ] );
		}*/
		num++;
	}
	//alert(new_name )
	oExcelDoc.SaveAs( new_name );
	
	tools.create_notification( "rb_hire_rosbank_diver_report", user_id, FilePathToUrl( new_name ) )
	
	alert( "������������ ������ finish" );
	return true;}
	catch(err){
		alert(curFile + err);
		return false;
	}
}

switch( action )
{
	case "create_report":
		// _agent_id = ArrayOptFirstElem( XQuery( "for $i in server_agents where $i/code = 'rb_hire_rosbank_diver_report' return $i" ) ).id;

		// docAgent = OpenDoc( UrlFromDocID( _agent_id ) );
		// teAgent = docAgent.TopElem;
		// teAgent.wvars.ObtainChildByKey( "vacancy" ).value = vacancy;
		// teAgent.wvars.ObtainChildByKey( "start_date" ).value = start_date;
		// teAgent.wvars.ObtainChildByKey( "finish_date" ).value = finish_date;
		// teAgent.wvars.ObtainChildByKey( "group" ).value = group;
		// teAgent.wvars.ObtainChildByKey( "person_id" ).value = curUserID;
		file_name = "report_rosbank_" + curUserID + "_" + StrReplace( StrReplace( StrReplace( StrDate( Date(), true, false ), ".", "-" ), ":", "-" ), " ", "_" ) + ".xlsx"
		//teAgent.wvars.ObtainChildByKey( "file_name" ).value = file_name;

        //if ( teAgent.run_agent( null, null, null, Date() ) )
		//if(tools.start_agent( _agent_id))
		MESSAGE = "SET=FileName," + UrlEncode( file_name ) + ";ALERT=������������ ������ ��������. �� ���������� �������� �������.;ACTION=CheckFile;"
		if(create_report(null, curUserID,start_date,finish_date,group,vacancy,file_name) == false)
		{
			//docAgent.Save();
			MESSAGE = "ALERT=��� ������������ ������ ��������� ������."
		}
		break;
		
	case "create_report2":
        vacancy = OptInt( vacancy );
        //alert(vacancy);
		if( vacancy == undefined )
		{
			MESSAGE = "ALERT=���������� ������� ��������;"
			break;
		}
		try
		{
			teRequest = OpenDoc( UrlFromDocID( vacancy ) ).TopElem;
		}
		catch( ex )
		{
			MESSAGE = "ALERT=�� ������ �������� ��� ������;"
			break;
		}
		_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );

		resp = HttpRequest( UrlAppendPath( _url, '/rosbank_report_service.xml?method=get_report_data&vacancy_id=' + vacancy ) , 'post' );
		var oExcelDoc = new ActiveXObject("Websoft.Office.Excel.Document");
        var exD = oExcelDoc.Open( AppDirectoryPath() + "\\wt\\web\\webtutor\\rbReportsTemplates\\report_rosbank_vacancy.xlsx" );
        
        //alert(AppDirectoryPath() + "\\wt\\web\\webtutor\rbReportsTemplates\\report_rosbank_vacancy.xlsx" + exD);
		file_name = "report_rosbank_vacancy_" + curUserID + "_" + StrReplace( StrReplace( StrReplace( StrDate( Date(), true, false ), ".", "-" ), ":", "-" ), " ", "_" ) + ".xlsx";
		new_name = AppDirectoryPath() + "\\wt\\web\\reports\\" + file_name;

        var oWorksheet = oExcelDoc.GetWorksheet( 0 );
        //alert(oWorksheet);
		teVacancyEstaff = OpenDocFromStr( resp.Body ).TopElem;
		bInEstaff = teVacancyEstaff.ChildExists( "vacancy" );
		teVacData = null;
		if( bInEstaff )
			teVacData = teVacancyEstaff.vacancy;
		function set_style( cell_id, bBold )
		{
			oWorksheet.Cells.GetCell( cell_id ).Style.IsBold = bBold;
			oWorksheet.Cells.GetCell( cell_id ).Style.Borders.SetStyle( "Thin" );
			oWorksheet.Cells.GetCell( cell_id ).Style.Borders.SetColor( "#00000" );
			oWorksheet.Cells.GetCell( cell_id ).Style.IsTextWrapped = true;
			oWorksheet.Cells.GetCell( cell_id ).Style.HorizontalAlignment = "Left";
			oWorksheet.Cells.GetCell( cell_id ).Style.FontColor = "#000000";
			oWorksheet.Cells.GetCell( cell_id ).Style.VerticalAlignment = "Top";
		}
		
		oWorksheet.Cells.GetCell( "B1" ).Value = teRequest.code;
		oWorksheet.Cells.GetCell( "B2" ).Style.Number = 22;
		oWorksheet.Cells.GetCell( "B2" ).Value = bInEstaff ? teVacData.start_date : "";
		oWorksheet.Cells.GetCell( "B3" ).Style.Number = 22;
		oWorksheet.Cells.GetCell( "B3" ).Value = bInEstaff ? teVacData.close_date : "";
		oWorksheet.Cells.GetCell( "B4" ).Value = bInEstaff ? teVacData.state : "";
		oWorksheet.Cells.GetCell( "B5" ).Value = bInEstaff ? teVacData.suspended_days_num : "";
		oWorksheet.Cells.GetCell( "B6" ).Value = bInEstaff ? teVacData.job_name : "";
		function get_sub_staff( TE )
		{
			if( OptInt( TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) == 1 || TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value == "true" )
			{
				subname = TE.workflow_fields.ObtainChildByKey( "subdivision_name" ).value
				return subname;
			}
			else
			{
				sub = OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "subdivision_id" ).value ) ) ).TopElem;

				dSub = sub;
				nArr = new Array();
				ind = 0
				do
				{
					nArr.push( { name: dSub.name, ind: ind } )
					ind++;
					if( !dSub.parent_object_id.HasValue )
					{
						nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
						break
					}
					else
						dSub = dSub.parent_object_id.OptForeignElem;
				}
				while( true )
				nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
				sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")
				return sub_staff_name;
			}
		}
		sub_staff = get_sub_staff( teRequest );
		sub_staff = sub_staff == "" ? ( bInEstaff ? teVacData.sub_staff_name : "" ) : sub_staff
		oWorksheet.Cells.GetCell( "B7" ).Value = sub_staff;
		oWorksheet.Cells.GetCell( "B8" ).Value = bInEstaff ? teVacData.region : "";
		oWorksheet.Cells.GetCell( "B9" ).Value = teRequest.workflow_fields.ObtainChildByKey( "terr_office_name" ).value != "" ? teRequest.workflow_fields.ObtainChildByKey( "terr_office_name" ).value : bInEstaff ? teVacData.terr_office : "";
		for( elem in String( sub_staff ).split( " -> " ) )
		{
			if( ( StrContains( elem, "�������������� ����", false ) || StrContains( elem, "������������ ����", false ) ) && !StrContains( elem, "��������������� ����", false ) )
			{
				oWorksheet.Cells.GetCell( "B10" ).Value = elem;
				break;
			}
		}
		
		//////////////////////////////����� ������
		num = 15;
		set_style( "A" + num, false );
		set_style( "B" + num, false );
		set_style( "D" + num, false );
		set_style( "G" + num, false );
		set_style( "E" + num, false );
		set_style( "C" + num, false );
		set_style( "F" + num, false );
		set_style( "H" + num, false );
		set_style( "I" + num, false );
		set_style( "J" + num, false );
		oWorksheet.Cells.GetCell( "D15" ).Style.Number = 22;
		oWorksheet.Cells.GetCell( "D15" ).Value = StrDate( teRequest.create_date, true, false );
		fSogl = ArrayOptFind( teRequest.workflow_log_entrys, "This.finish_state == 'sogl_manager'" );
		if( fSogl == undefined )
			fSogl = ArrayOptFind( teRequest.workflow_log_entrys, "This.finish_state == 'hr'" );
		if( fSogl != undefined )  
		{
			oWorksheet.Cells.GetCell( "E15" ).Style.Number = 22;
			oWorksheet.Cells.GetCell( "E15" ).Value = StrDate( fSogl.create_date, true, false );
		}
		oWorksheet.Cells.GetCell( "G15" ).Value = teRequest.person_fullname;
		nArr = new Array();
		for( elem in teRequest.workflow_log_entrys )
			if( elem.finish_state != "draft" )
				nArr.push( {begin_state: elem.begin_state, finish_state: elem.finish_state, create_date: elem.create_date, person_fullname: elem.person_fullname } );
		num = 16;
		for( i = 0; i < ArrayCount( nArr ); i++ )
		{
			_ch = nArr[ i ]
			if( _ch.finish_state != "sogl_manager" && _ch.finish_state != "hr_go_net" && _ch.finish_state != "hr_go" && _ch.finish_state != "hr"  )
				continue;
			
			oWorksheet.Cells.GetCell( "B" + num ).Value = _ch.finish_state == "sogl_manager" ? "������������ ������" : "������������ HR-���������";
			oWorksheet.Cells.GetCell( "D" + num ).Style.Number = 22;
			oWorksheet.Cells.GetCell( "D" + num ).Value = StrDate( _ch.create_date, true, false );
			oWorksheet.Cells.GetCell( "G" + num ).Value = i < ( ArrayCount( nArr ) - 1 ) ? nArr[ i + 1 ].person_fullname : "";
			oWorksheet.Cells.GetCell( "E" + num ).Style.Number = 22;
			oWorksheet.Cells.GetCell( "E" + num ).Value = i < ( ArrayCount( nArr ) - 1 ) ? StrDate( nArr[ i + 1 ].create_date, true, false ) : "";
			set_style( "A" + num, false );
			set_style( "B" + num, false );
			set_style( "D" + num, false );
			set_style( "G" + num, false );
			set_style( "E" + num, false );
			set_style( "C" + num, false );
			set_style( "F" + num, false );
			set_style( "H" + num, false );
			set_style( "I" + num, false );
			set_style( "J" + num, false );
			
			
			num++;
		}
		
		if( bInEstaff )
		{
			set_style( "B" + num, false );
			oWorksheet.Cells.GetCell( "B" + num ).Value = "������� ��������";
			//alert('teVacData.vac_start_date '+teVacData.vac_start_date)
			set_style( "D" + num, false );
			oWorksheet.Cells.GetCell( "D" + num ).Style.Number = 22;
			oWorksheet.Cells.GetCell( "D" + num ).Value = bInEstaff && teVacData.vac_start_date.HasValue ? StrDate( Date( teVacData.vac_start_date ), true, false ) : "";
			set_style( "G" + num, false );
			oWorksheet.Cells.GetCell( "G" + num ).Value = bInEstaff ? teVacData.recr : "";
			set_style( "C" + num, false );
			set_style( "E" + num, false );
			set_style( "F" + num, false );
			set_style( "G" + num, false );
			set_style( "H" + num, false );
			set_style( "I" + num, false );
			set_style( "J" + num, false );
			num++;
			num++;
			/////////////////////////////
			function write_estaff_events( type_id, bWriteContact )
			{
				arrEvents = ArraySelect( teVacancyEstaff.events, "This.type_id == type_id" );
				for( elem in ArraySort( arrEvents, "This.creation_date", "+" ) )
				{
					
					oWorksheet.Cells.GetCell( "A" + num ).Value = elem.candidate;
					oWorksheet.Cells.GetCell( "B" + num ).Value = elem.type_name;
					oWorksheet.Cells.GetCell( "C" + num ).Value = elem.show_in_wt ? "��" : "";
					oWorksheet.Cells.GetCell( "D" + num ).Style.Number = 22;
					oWorksheet.Cells.GetCell( "D" + num ).Value = elem.creation_date;
					oWorksheet.Cells.GetCell( "F" + num ).Value = elem.status;
					oWorksheet.Cells.GetCell( "E" + num ).Style.Number = 22;
					oWorksheet.Cells.GetCell( "E" + num ).Value = elem.finish_date;
					if( type_id == "event_type_2" || type_id == "event_type_3" )
					{
						wtEvent = ArrayOptFind( xarrEstaffEvents, "OptInt( This.code ) == OptInt( elem.id )" )
						if( wtEvent != undefined )
						{
							if( wtEvent.status == "�����������" || wtEvent.status == "���������" || wtEvent.status == "��������" )
								oWorksheet.Cells.GetCell( "G" + num ).Value = wtEvent.contact_fullname;
							else
								oWorksheet.Cells.GetCell( "G" + num ).Value = elem.recr;
								
							oWorksheet.Cells.GetCell( "J" + num ).Value = StrReplace( elem.comment, wtEvent.comment_sogl, "" );
						}
					}
					oWorksheet.Cells.GetCell( "I" + num ).Value = elem.recr;
					set_style( "A" + num, false );
					set_style( "B" + num, false );
					set_style( "C" + num, false );
					set_style( "D" + num, false );
					set_style( "E" + num, false );
					set_style( "F" + num, false );
					set_style( "G" + num, false );
					set_style( "H" + num, false );
					set_style( "I" + num, false );
					set_style( "J" + num, false );
					num++;
				}
			}
			
			function write_wt_events( type_id )
			{
				arrEvents = ArraySelect( xarrEstaffEvents, "This.event_type == type_id" );
				arrEstEvents = ArraySelect( teVacancyEstaff.events, "This.type_id == type_id" );
				for( elem in ArraySort( arrEvents, "This.event_date.HasValue ? Date( This.event_date ) : ''", "+" ) )
				{
					
					oWorksheet.Cells.GetCell( "A" + num ).Value = elem.candidate_name;
					oWorksheet.Cells.GetCell( "B" + num ).Value = elem.event_name;
					oWorksheet.Cells.GetCell( "C" + num ).Value = "��";
					oWorksheet.Cells.GetCell( "D" + num ).Style.Number = 22;
					oWorksheet.Cells.GetCell( "D" + num ).Value = elem.event_date;
					oWorksheet.Cells.GetCell( "F" + num ).Value = elem.event_status;
					estEvent = ArrayOptFind( arrEstEvents, "OptInt( This.id ) == OptInt( elem.code )" )
					if( estEvent != undefined )
					{
						oWorksheet.Cells.GetCell( "E" + num ).Style.Number = 22;
						oWorksheet.Cells.GetCell( "E" + num ).Value = estEvent.finish_date;
						if( type_id == "event_type_1" || type_id == "event_type_4" || type_id == "event_type_5" || type_id == "rb_event_type_7" || type_id == "rosbank_arbitrazh_sb" || type_id == "event_type_6" )
						{
							if( elem.status == "�����������" || elem.status == "���������" || elem.status == "��������" )
								oWorksheet.Cells.GetCell( "G" + num ).Value = elem.contact_fullname;
							else
								oWorksheet.Cells.GetCell( "G" + num ).Value = estEvent.recr;
						}
						oWorksheet.Cells.GetCell( "I" + num ).Value = estEvent.recr;
						oWorksheet.Cells.GetCell( "H" + num ).Value = elem.comment_sogl;
						oWorksheet.Cells.GetCell( "J" + num ).Value = StrReplace( estEvent.comment, elem.comment_sogl, "" );
					}
					set_style( "A" + num, false );
					set_style( "B" + num, false );
					set_style( "C" + num, false );
					set_style( "D" + num, false );
					set_style( "E" + num, false );
					set_style( "F" + num, false );
					set_style( "G" + num, false );
					set_style( "H" + num, false );
					set_style( "I" + num, false );
					set_style( "J" + num, false );
					num++;
				}
			}
			xarrEstaffEvents = XQuery( "for $i in cc_estaff_events where $i/vacancy_id = " + vacancy + " return $i" );
			if( ArrayOptFind( xarrEstaffEvents, "This.event_type == 'rb_event_type_7'" ) != undefined ||  ArrayOptFind( teVacancyEstaff.events, "This.type_id == 'event_type_8'" ) != undefined || ArrayOptFind( teVacancyEstaff.events, "This.type_id == 'event_type_2'" ) != undefined || ArrayOptFind( teVacancyEstaff.events, "This.type_id == 'event_type_3'" ) != undefined || ArrayOptFind( xarrEstaffEvents, "This.event_type == 'event_type_1'" ) != undefined || ArrayOptFind( xarrEstaffEvents, "This.event_type == 'event_type_4'" ) != undefined || ArrayOptFind( xarrEstaffEvents, "This.event_type == 'event_type_5'" ) != undefined )
			{
				set_style( "A" + num, true );
				oWorksheet.Cells.GetCell( "A" + num ).Value = "2. ������";
				num++;
				write_estaff_events( 'event_type_2', true );
				write_wt_events( 'event_type_1' );
				write_estaff_events( 'event_type_3', true );
				write_wt_events( 'event_type_4' );
				write_wt_events( 'event_type_5' );
				write_wt_events( 'rb_event_type_7' );
				write_estaff_events( 'event_type_8', true );
			}
			
			if( ArrayOptFind( teVacancyEstaff.events, "This.type_id == 'rosbank_verification'" ) != undefined || ArrayOptFind( xarrEstaffEvents, "This.event_type == 'rosbank_arbitrazh_sb'" ) != undefined || ArrayOptFind( xarrEstaffEvents, "This.event_type == 'event_type_6'" ) != undefined )
			{
				set_style( "A" + num, true );
				oWorksheet.Cells.GetCell( "A" + num ).Value = "3. ��������";
				num++;
				
				write_estaff_events( 'rosbank_verification', false );
				write_wt_events( 'rosbank_arbitrazh_sb' );
				write_wt_events( 'event_type_6' );
			}
			if( ArrayOptFind( xarrEstaffEvents, "This.event_type == 'event_type_7'" ) != undefined )
			{
				set_style( "A" + num, true );
				oWorksheet.Cells.GetCell( "A" + num ).Value = "4. �����";
				num++;
				
				write_wt_events( 'event_type_7' );
			}
			
			rType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_hire' return $i" ) );
			xarrHireRequests = XQuery( "for $i in requests where $i/object_id = " + vacancy + " and $i/request_type_id = " + rType.id + " order by $i/create_date descending return $i" );
			if( ArrayOptFirstElem( xarrHireRequests ) != undefined )
			{
				set_style( "A" + num, true );
				oWorksheet.Cells.GetCell( "A" + num ).Value = "5. ������������� �� �����";
				num++;
				function get_state_name( name )
				{
					switch( name )
					{
						case "sogl_manager":
							return "������������ �������������";
						case "hr":
							return "������������ HR-���������";
						case "dmto":
							return "������������ ���";
						case "cuchr":
						case "cuchr_go":
							return "������������ HR-�������";
						case "candidate":
							return "���������� ����������";
						case "staff":
							return "������������ ������������� �� ��";
					}
					return "";
				}
				
				for( cat in xarrHireRequests )
				{
					teHireRequest = OpenDoc( UrlFromDocID( cat.id ) ).TopElem;
					candidate_fullname = teHireRequest.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value;
					
					oWorksheet.Cells.GetCell( "A" + num ).Value = candidate_fullname;
					oWorksheet.Cells.GetCell( "B" + num ).Value = "�������� �������������";
					oWorksheet.Cells.GetCell( "D" + num ).Style.Number = 22;
					oWorksheet.Cells.GetCell( "D" + num ).Value = StrDate( teHireRequest.create_date, true, false );
					oWorksheet.Cells.GetCell( "G" + num ).Value = teHireRequest.person_fullname;
					fSogl = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'sogl_manager'" );
					if( fSogl == undefined )
						fSogl = ArrayOptFind( teHireRequest.workflow_log_entrys, "This.finish_state == 'hr'" );
					if( fSogl != undefined )
					{
						oWorksheet.Cells.GetCell( "E" + num ).Style.Number = 22;
						oWorksheet.Cells.GetCell( "E" + num ).Value = fSogl.create_date;
					}
					set_style( "A" + num, false );
					set_style( "B" + num, false );
					set_style( "D" + num, false );
					set_style( "C" + num, false );
					set_style( "G" + num, false );
					set_style( "E" + num, false );
					set_style( "F" + num, false );
					set_style( "H" + num, false );
					set_style( "I" + num, false );
					set_style( "J" + num, false );
					num++;
					nArr = new Array();
					for( elem in teHireRequest.workflow_log_entrys )
						if( elem.finish_state != "draft" )
							nArr.push( {begin_state: elem.begin_state, finish_state: elem.finish_state, create_date: elem.create_date, person_fullname: elem.person_fullname } );
					for( i = 0; i < ArrayCount( nArr ); i++ )
					{
						_ch = nArr[ i ]
						if( _ch.finish_state != "sogl_manager" && _ch.finish_state != "hr_go_net" && _ch.finish_state != "hr_go" && _ch.finish_state != "hr" && _ch.finish_state != "cuchr" && _ch.finish_state != "cuchr_go" && _ch.finish_state != "dmto" && _ch.finish_state != "staff" && _ch.finish_state != "candidate"  )
							continue;
						
						oWorksheet.Cells.GetCell( "A" + num ).Value = candidate_fullname;
						oWorksheet.Cells.GetCell( "B" + num ).Value = get_state_name( _ch.finish_state );
						oWorksheet.Cells.GetCell( "D" + num ).Style.Number = 22;
						oWorksheet.Cells.GetCell( "D" + num ).Value = StrDate( _ch.create_date, true, false );
						oWorksheet.Cells.GetCell( "G" + num ).Value = i < ( ArrayCount( nArr ) - 1 ) ? nArr[ i + 1 ].person_fullname : "";
						oWorksheet.Cells.GetCell( "E" + num ).Style.Number = 22;
						oWorksheet.Cells.GetCell( "E" + num ).Value = i < ( ArrayCount( nArr ) - 1 ) ? StrDate( nArr[ i + 1 ].create_date, true, false ) : "";
						set_style( "A" + num, false );
						set_style( "B" + num, false );
						set_style( "D" + num, false );
						set_style( "G" + num, false );
						set_style( "C" + num, false );
						set_style( "F" + num, false );
						set_style( "H" + num, false );
						set_style( "I" + num, false );
						set_style( "J" + num, false );
						num++;
					}
				}
				
			}
			if( ArrayOptFind( teVacancyEstaff.events, "This.type_id == 'rosbank_hire_candidate'" ) != undefined )
			{
				set_style( "A" + num, true );
				oWorksheet.Cells.GetCell( "A" + num ).Value = "6. �����";
				num++;
				write_estaff_events( 'rosbank_hire_candidate', false );
			}
			for( i = num; i >= 15; i-- )
				oWorksheet.Cells.SetRowHeight( i, 12.75 );
		}
		
		oExcelDoc.SaveAs( new_name );
		MESSAGE = "ALERT=����� �����������;SET=FileName," + UrlEncode( file_name ) + ";SHOW=ExportButton,ExportLabel;"
		break;

	case "check_file":
		//alert(AppDirectoryPath() + "\\wt\\web\\reports\\" + file_name)
		if( FilePathExists(AppDirectoryPath() + "\\wt\\web\\reports\\" + UrlDecode( file_name ) ) )
			MESSAGE = "SHOW=ExportButton,ExportLabel;";
		else
			MESSAGE = "ACTION=CheckFile";
		//alert( MESSAGE )
		break;
}