//�������� ��� ��������

/*
	<wvars>
		<wvar>
			<name>CONTEXT</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>action</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>request_type_id</name>
			<type>string</type>
			<position>3</position>
		</wvar>
	</wvars>
*/

function fnCancelError( sMesParam )
{
	if ( ISACTION )
	{
		ERROR = 1;
		MESSAGE = sMesParam;
	}
	else
	{
		curErrorText = sMesParam;
		Server.Execute( "view_access_panel.html" );
	}
	Cancel();
}

function send_request_estaff( TE )
{
	//alert("send_request_estaff start");
	vacancy_desc = "<b>�������� ����������� ������������: </b>" + ( TE.workflow_fields.ObtainChildByKey( "function" ).value ) + "<br/><br/>";
	vacancy_desc += "<b>����������:</b><br/>";
	body = '<vacancy>';
	body += '<id>0x' + StrHexInt( requestDoc.DocID, 14 ) + '</id>';
	body += '<code>' + TE.code + '</code>';
	body += '<start_date>' + Date() + '</start_date>';
	sub = null;
	subname = "";
	sub_staff_name = "";
	try
	{
		if( OptInt( TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) == 1 || TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value == "true" )
		{
			subname = TE.workflow_fields.ObtainChildByKey( "subdivision_name" ).value
			sub_staff_name = subname;
		}
		else
		{
			sub = OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "subdivision_id" ).value ) ) ).TopElem;
			manager = ArrayOptFirstElem( XQuery( "for $i in positions where $i/parent_object_id = " + TE.workflow_fields.ObtainChildByKey( "subdivision_id" ).value + " and $i/is_boss = true() return $i" ) );
			if( manager != undefined )
				body += '<cs_sub_manager>' + manager.basic_collaborator_fullname + '</cs_sub_manager>';
			dSub = sub;
			nArr = new Array();
			ind = 0
			do
			{
				nArr.push( { name: dSub.name, ind: ind } )
				ind++;
				if( !dSub.parent_object_id.HasValue )
				{
					nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
					break
				}
				else
					dSub = dSub.parent_object_id.OptForeignElem;
			}
			while( true )
			nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
			sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")
		}
	}
	catch(ex){}
	jobname = "";
	job = null;
	try
	{
		if( OptInt( TE.workflow_fields.ObtainChildByKey( "new_job" ).value ) == 1 || TE.workflow_fields.ObtainChildByKey( "new_job" ).value == "true" )
			jobname = TE.workflow_fields.ObtainChildByKey( "job_name" ).value
		else
		{
			job = OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "job_id" ).value ) ) ).TopElem;
			body += '<job_code>' + job.code + '</job_code>';
			jobname = job.name;
		}
	}
	catch(ex){ alert( "hire\remote_actions\action_rosbank.js error: " + ex ) }
	body += '<cs_job_name>' + jobname + '</cs_job_name>';
	body += '<cs_sub_staff_name>' + sub_staff_name + '</cs_sub_staff_name>';

	body += '<name>' + StrTitleCase( jobname ) + " " + StrTitleCase( sub != null ? StrReplace( sub.name, "��� �������", "" ) : StrReplace( subname, "��� �������", "" )  ) + '</name>';

	try
	{
		body += '<division>' + ( sub != null ? sub.code : "not_code" ) + '</division>';
	}
	catch(ex){}

	body += '<persons>';
	
	body += '<person>' + TE.person_id.ForeignElem.code + '</person>';
	if( OptInt( TE.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ) != undefined && false ){
		try
		{
			body += '<person>' + OpenDoc( UrlFromDocID( OptInt( TE.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ) ) ).TopElem.code + '</person>';
		}
		catch( ex )
		{}
	}
	body += '</persons>';

	body += '<cs_podbor_for>' + ( TE.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "net" ? "����. ����" : TE.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "cf" ? "CF" : TE.workflow_fields.ObtainChildByKey( "podbor_for" ).value == "go" ? "��" : "" ) + '</cs_podbor_for>';
	
	body += '<is_confidential>' + ( TE.workflow_fields.ObtainChildByKey( "vid_request" ).value == "close" ? 1 : 0 ) + '</is_confidential>'
	body += '<cs_open_without_notif>' + ( TE.workflow_fields.ObtainChildByKey( "vid_request" ).value == "open_without_notification" ? 1 : 0 ) + '</cs_open_without_notif>';
	body += '<cs_terr_office>' + TE.workflow_fields.ObtainChildByKey( "terr_office_name" ).value + '</cs_terr_office>';
	body += '<cs_hub_id>' + ( TE.workflow_fields.ObtainChildByKey( "hub_id" ).value == "west" ? "�������� ���" : TE.workflow_fields.ObtainChildByKey( "hub_id" ).value == "east" ? "��" : TE.workflow_fields.ObtainChildByKey( "hub_id" ).value == "go" ? "��" : "" ) + '</cs_hub_id>';
	body += '<cs_is_grade>' + ( TE.workflow_fields.ObtainChildByKey( "is_grade" ).value == "yes" ? "��" : TE.workflow_fields.ObtainChildByKey( "is_grade" ).value == "no" ? "���" : "" ) + '</cs_is_grade>';
	body += '<cs_position_instruction>' + ( TE.workflow_fields.ObtainChildByKey( "position_instruction" ).value == "true" ? "��" : TE.workflow_fields.ObtainChildByKey( "position_instruction" ).value == "false" ? "���" : "" ) + '</cs_position_instruction>';
	body += '<reason_id>' + ( TE.workflow_fields.ObtainChildByKey( "justification" ).value ) + '</reason_id>';
	if( TE.workflow_fields.ObtainChildByKey( "justification" ).value == "replace" || TE.workflow_fields.ObtainChildByKey( "justification" ).value == "parental_leave" )
	{
		try
		{
			body += '<cs_change_collaborator_id>' + OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "change_collaborator_id" ).value ) ) ).TopElem.name + '</cs_change_collaborator_id>';
		}
		catch( ex ) {}
		body += '<cs_dismiss_date>' + ( TE.workflow_fields.ObtainChildByKey( "date_dismiss" ).value ) + '</cs_dismiss_date>';
	}
	forma = "";
	switch( TE.workflow_fields.ObtainChildByKey( "forma" ).value )
	{
		case "1001":
			forma = "���������� �������";
			break;
		case "1002":
			forma = "���";
			break;
		case "1003":
			forma = "����������";
			break;
		case "1004":
			forma = "������";
			break;
		case "1005":
			forma = "������� �������";
			break;
		case "1006":
			forma = "������� �� ������ ���������� ��������� ����������";
			break;
		case "1007":
			forma = "������������� ������";
			break;
	}
	body += '<cs_forma>' + forma + '</cs_forma>';
	
	body += '<cs_is_digital>' + ( TE.workflow_fields.ObtainChildByKey( "is_digital" ).value == "yes" ) + '</cs_is_digital>'
	if( TE.workflow_fields.ObtainChildByKey( "is_digital" ).value == "yes" )
	{
		if( OptInt( TE.workflow_fields.ObtainChildByKey( "digital_role_id" ).value ) != undefined )
		{
			try {
				teDigital = OpenDoc( UrlFromDocID( OptInt( TE.workflow_fields.ObtainChildByKey( "digital_role_id" ).value ) ) ).TopElem; 
				body += '<cs_digital_role>' + teDigital.name + '</cs_digital_role>' ;
				body += '<cs_digital_role_desc>' + XmlAttrEncode( StrReplace( HtmlToPlainText(  StrReplace( StrReplace( teDigital.desc, "</p>", "$$$$" ), "<p>", "" ) ), "$$$$", "\n" ) ) + '</cs_digital_role_desc>'
			} catch (error) {
				alert("hire/remote_actions/action_rosbank.js error: \n " + error);
			}
		}
	}
	
	schedule_type = "";
	switch( TE.workflow_fields.ObtainChildByKey( "schedule" ).value )
	{
		case "1":
			schedule_type = "�����������";
			break;
		case "3":
			schedule_type = "�������";
			break;
	}
	body += '<cs_schedule_type>' + schedule_type + '</cs_schedule_type>';
	
	try
	{
		body += '<cs_place_id>' + OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "place_id" ).value ) ) ).TopElem.zdanie_naimenovanie + '</cs_place_id>';
	}
	catch(ex){}

	body += '<salary>' + ( TE.workflow_fields.ObtainChildByKey( "salary" ).value ) + '</salary>';

	body += '<work_type_id>' + ( TE.workflow_fields.ObtainChildByKey( "forma" ).value ) + '</work_type_id>';
	if( !( TE.workflow_fields.ObtainChildByKey( "forma" ).value == "1001" || TE.workflow_fields.ObtainChildByKey( "forma" ).value == "" || ( TE.workflow_fields.ObtainChildByKey( "forma" ).value == "1004" &&  TE.workflow_fields.ObtainChildByKey( "hub_id" ).value != "" ) ) )
	{
			body += '<cs_start_period>' +  TE.workflow_fields.ObtainChildByKey( "start_period" ).value + '</cs_start_period>';
			body += '<cs_finish_period>' + TE.workflow_fields.ObtainChildByKey( "finish_period" ).value + '</cs_finish_period>';
	}
	body += '<work_schedule_type_id>' + ( TE.workflow_fields.ObtainChildByKey( "schedule" ).value ) + '</work_schedule_type_id>';
	if(  TE.workflow_fields.ObtainChildByKey( "schedule" ).value == "3"  )
	{
			body += '<cs_replacement_name>' +  TE.workflow_fields.ObtainChildByKey( "replacement_name" ).value + '</cs_replacement_name>';
	}
	body += '<cs_is_travel>' +  TE.workflow_fields.ObtainChildByKey( "travel" ).value + '</cs_is_travel>';
	if(  TE.workflow_fields.ObtainChildByKey( "travel" ).value == "true"  )
	{
			body += '<cs_travel_name>' +  TE.workflow_fields.ObtainChildByKey( "travel_name" ).value + '</cs_travel_name>';
	}
	
	body += '<cs_profile>' +  ( OptInt( TE.workflow_fields.ObtainChildByKey( "profile" ).value ) != undefined ? workflowDoc.workflow_fields.ObtainChildByKey( "profile" ).entries.Child( Int( TE.workflow_fields.ObtainChildByKey( "profile" ).value ) ).value : "" ) + '</cs_profile>';
	body += '<cs_certificate>' +  TE.workflow_fields.ObtainChildByKey( "certificate" ).value + '</cs_certificate>';
	
	
	body += '<cs_project>' +  TE.workflow_fields.ObtainChildByKey( "project" ).value + '</cs_project>';
	
	body += '<cs_cnt_sub>' +  OptInt( TE.workflow_fields.ObtainChildByKey( "cnt_sub" ).value ) + '</cs_cnt_sub>';
	language_verbal = "<b>������� �������� ������ (������): </b>"
	try
	{
		bVerb = OpenDocFromStr( TE.workflow_fields.ObtainChildByKey( "language_level_verbal" ).value ).TopElem;
		body += '<cs_language_verbal>' +  ArrayMerge( bVerb, "Base64Decode( This.language ) + '( ' + Base64Decode( This.level ) + ' )'" ) + '</cs_language_verbal>';
		language_verbal += ArrayMerge( bVerb, "Base64Decode( This.language ) + '( ' + Base64Decode( This.level ) + ' )'" ) + "<br/>";
	}
	catch( err ){ alert( "hire\remote_actions\action_rosbank.js" + err ) }
	
	language_write = "<b>������� �������� ������ (����������): </b>";
	try
	{
		bVerb = OpenDocFromStr( TE.workflow_fields.ObtainChildByKey( "language_level_written" ).value ).TopElem;
		body += '<cs_language_written>' +  ArrayMerge( bVerb, "Base64Decode( This.language ) + '( ' + Base64Decode( This.level ) + ' )'" ) + '</cs_language_written>';
		language_write += ArrayMerge( bVerb, "Base64Decode( This.language ) + '( ' + Base64Decode( This.level ) + ' )'" ) + "<br/>";
	}
	catch( err ){ alert( "hire\remote_actions\action_rosbank.js" + err ) }
	body += '<cs_pc>' +  TE.workflow_fields.ObtainChildByKey( "pc" ).value + '</cs_pc>';
	
	body += '<cs_professional_skills>' +  TE.workflow_fields.ObtainChildByKey( "professional_skills" ).value + '</cs_professional_skills>';
	
	try
	{
		body += '<cs_grade>' + OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "grade" ).value ) ) ).TopElem.grade + '</cs_grade>';
	}
	catch(ex){}
	body += '<min_salary>' +  TE.workflow_fields.ObtainChildByKey( "start_range_of_salary" ).value + '</min_salary>';
	body += '<max_salary>' +  TE.workflow_fields.ObtainChildByKey( "finish_range_of_salary" ).value + '</max_salary>';
	body += '<cs_date_registration>' +  TE.workflow_fields.ObtainChildByKey( "date_registration" ).value + '</cs_date_registration>';
	//body += '<cs_fire_coaching>' +  ( TE.workflow_fields.ObtainChildByKey( "fire_coaching" ).value == "first" ) + '</cs_fire_coaching>';
	body += '<cs_personal_qualities>' +  ( TE.workflow_fields.ObtainChildByKey( "personal_qualities" ).value ) + '</cs_personal_qualities>';
	
	body += '<comment>' +  ( TE.workflow_fields.ObtainChildByKey( "additional_conditions" ).value ) + '</comment>';
	

	body += '<req_info>';
	
	body += '<min_exp_years>' + TE.workflow_fields.ObtainChildByKey( "experience" ).value + '</min_exp_years>';
	vacancy_education = "<b>�����������: </b>";
	if( TE.workflow_fields.ObtainChildByKey( "education" ).value != "other" )
	{
		body += '<educ_type_id>' + TE.workflow_fields.ObtainChildByKey( "education" ).value + '</educ_type_id>';
		vacancy_education += ( TE.workflow_fields.ObtainChildByKey( "education" ).value == "2" ? "������� �����������" : TE.workflow_fields.ObtainChildByKey( "education" ).value == "3" ? "�������� ������" : "������" ) + "<br/>";
	}
	body += '</req_info>';
	if( TE.workflow_fields.ObtainChildByKey( "education" ).value == "other" )
	{
		vacancy_education += ( TE.workflow_fields.ObtainChildByKey( "education_name" ).value ) + "<br/>";
		body += '<cs_other_education>' +  ( TE.workflow_fields.ObtainChildByKey( "education_name" ).value ) + '</cs_other_education>';
	}
	expr = OptInt( TE.workflow_fields.ObtainChildByKey( "experience" ).value, "" );
	if( expr == 0 )
		expr = "��� �����";
	else if( expr == 1 )
		expr = "1 ���";
	else if( expr > 4 )
		expr = expr + " ���";
	else if( expr != "" )
		expr = expr + " ����";
	
	vacancy_desc += vacancy_education;
	vacancy_desc += "<b>�������: </b>" + ( OptInt( TE.workflow_fields.ObtainChildByKey( "profile" ).value ) != undefined ? workflowDoc.workflow_fields.ObtainChildByKey( "profile" ).entries.Child( Int( TE.workflow_fields.ObtainChildByKey( "profile" ).value ) ).value : "" ) + "<br/>";
	vacancy_desc += "<b>�����������: </b>" + TE.workflow_fields.ObtainChildByKey( "certificate" ).value + "<br/>";
	vacancy_desc += "<b>�������: </b>" + TE.workflow_fields.ObtainChildByKey( "project" ).value + "<br/>";
	vacancy_desc += "<b>���� ������: </b>" + expr + "<br/>";
	vacancy_desc += language_write;
	vacancy_desc += language_verbal;
	vacancy_desc += "<b>�������� ��. ������ ����������� ��������: </b>" + TE.workflow_fields.ObtainChildByKey( "pc" ).value + "<br/>";
	vacancy_desc += "<b>���� � ���������������� ������: </b>" + TE.workflow_fields.ObtainChildByKey( "professional_skills" ).value + "<br/>";
	vacancy_desc += "<b>������ ��������: </b>" + TE.workflow_fields.ObtainChildByKey( "personal_qualities" ).value + "<br/>";
	
	vacancy_desc += "<b>�������������� ����������: </b>" + TE.workflow_fields.ObtainChildByKey( "additional_conditions" ).value;
	vacancy_desc = StrReplace( vacancy_desc, "\n", "<br/>" )
	body += '<attachments><attachment><type_id>vacancy_desc</type_id><text>' + Base64Encode( vacancy_desc ) + '</text></attachment></attachments>';
	body += '</vacancy>';
	//alert("body "+body)
	_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
	resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=put_vacancy' ) , 'post',  Base64Encode( EncodeCharset( body, 'utf-8' ) ) );
	if( resp.Body != "" )
	{
		if( resp.Body == "reopened" )
		{
			hub_id = "go";
			if( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
				hub_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value
			send_notification_group( "podbor_" + hub_id, "rb_hire_rosbank_reopened" )
		}
		else
		{
			recr = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + resp.Body + "' return $i" ) );
			if( recr != undefined )
				tools.create_notification( "rb_hire_rosbank_reopened", recr.id, "", requestDoc.DocID, null, requestDoc.TopElem );
		}
	}
	MESSAGE = "ALERT=�������� ���������;OPENURL=view_doc.html?mode=rosbank_requests;"
	//alert("send_request_estaff end");
}

function send_notification_pers( type )
{
	hub_id = "go";
	if( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
		hub_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value
	for( elem in XQuery( "for $i in groups where  $i/code = '" + ( type + "_" + hub_id ) + "' return $i" ) )
		send_notification_group( elem.code, "rb_hire_sogl_request" )
}

function send_notification_podbor( type )
{

	hub_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value
	for( elem in XQuery( "for $i in groups where $i/code = '" + ( type + "_" + hub_id ) + "' return $i" ) )
		send_notification_group( elem.code, "rb_hire_rosbank_recruiter" )
}

function send_notification_group( type, notif )
{
	gr = ArrayOptFirstElem( XQuery( "for $i in groups where $i/code = '" + type + "' return $i" ) );
	try {
		teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
		t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
		if( StrContains( t_send, "�� ����� �����" ) )
			tools.create_notification( notif + "_group", gr.id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
		if( StrContains( t_send, "������� ���������� ������" ) )
			for( elem in XQuery( "for $i in group_collaborators where $i/group_id = " + gr.id + " return $i" ) )
				tools.create_notification( notif, elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
	
	} catch (error) {
		alert("hire/remote_actions/action_rosbank.js send_notification_group error: \n " + error);
	}
}

function add_workflow( obj, st, fin )
{
	fldLogEntryChild = obj.workflow_log_entrys.AddChild();
	fldLogEntryChild.create_date = Date();
	fldLogEntryChild.person_id = curUserID;
	fldLogEntryChild.person_fullname = curUser.fullname;
	fldLogEntryChild.begin_state = st;
	fldLogEntryChild.finish_state = fin;
}

function save_language( type )
{
	xml = CONTEXT.GetOptProperty( "pole_" + type );
	if( xml == "" )
		xml = "<languages/>";
	try
	{
		docLang = OpenDocFromStr( UrlDecode( xml ) ).TopElem;
	}
	catch( er )
	{
		docLang = OpenDocFromStr( "<languages/>" ).TopElem;
	}
	for( l in docLang )
	{
		l.level = CONTEXT.GetOptProperty( type + "_level_" + l.ChildIndex );
		l.language = CONTEXT.GetOptProperty( type + "_language_" + l.ChildIndex );
	}
}

var arr_need_new_fields = new Array( "subdivision_id", "job_id", "podbor_for", "hub_id", "position_instruction", "justification", "place_id", "forma", "function", "experience", "language_level_verbal", "language_level_written", "professional_skills", "pc", "education", "profile", "vid_request", "is_digital","COI" );
var arr_need_new_fields_name = new Array( "�������������", "���������", "��������� ���", "������ ����������� �", "������� ����������� ����������", "����������� �������� ��������", "����� �������� �����", "����� �����", "�������� ����������� ������������", "���� ������", "������� �������� ������� (������)", "������� �������� ������� (����������)", "���� � ���������������� ������", "�������� ��. ������ ����������� ��������", "�����������", "�������", "��� ������", "Digital","������������� ���������� ���������� ��������� ���������" );
var arr_need_sogl_fields = new Array(  "grade", "start_range_of_salary", "finish_range_of_salary" );
var arr_need_sogl_fields_name = new Array( "�����", "�������� ������", "�������� ������" );

docLang = null;
var start_state = curObject != null ? curObject.workflow_state : "";
//alert( "CONTEXT " + CONTEXT )
MESSAGE = "";
try
{
	CONTEXT = tools.read_object( CONTEXT );

	switch( action )
	{
		case "check_forma":
			forma = CONTEXT.GetOptProperty( "pole_forma" );
			switch( forma )
			{	
				case "1002":
				case "1003":
				case "1005":
					MESSAGE = "SHOW=PeriodDate;";
					break;
				case "1004":
					if(  CONTEXT.GetOptProperty( "pole_hub_id", "" ) == "" )
					{
						MESSAGE = "SHOW=PeriodDate;";
						break;
					}
				default:
					MESSAGE = "HIDE=PeriodDate;";
			}
			break;
		case "check_forma2":
			hub_id = CONTEXT.GetOptProperty( "pole_hub_id" );
			podbor_for = CONTEXT.GetOptProperty( "pole_podbor_for" );
			if( podbor_for == "net" && hub_id == "go" )
				MESSAGE = "SET=pole_hub_id,east;ALERT=��� ����. ����� ����� ���� ������ ������ ��������� ��� �������� ���;"

			break;
		case "check_forma3":
			hub_id = CONTEXT.GetOptProperty( "pole_hub_id" );
			podbor_for = CONTEXT.GetOptProperty( "pole_podbor_for" );
			if( podbor_for == "net" && hub_id == "go" )
				MESSAGE = "SET=pole_hub_id,east;"

			break;
		case "create_request":
		case "draft":
		case "return":
		case "save":
			requestTypeID = OptInt( request_type_id );
			if ( requestTypeID == undefined )
				fnCancelError( tools_web.get_web_const( 'e7mgqux02y', curLngWeb ) );
				
			//for( elem in arr_need_new_fields )
			arr_not_fields = new Array();
			if( action == "create_request" )
				for( i = 0; i < ArrayCount( arr_need_new_fields ); i++ )
					if( CONTEXT.GetOptProperty( "pole_" + arr_need_new_fields[ i ], "" ) == "" || CONTEXT.GetOptProperty( "pole_" + arr_need_new_fields[ i ], "" ) == null )
					{
						if( arr_need_new_fields[ i ] == "subdivision_id" && OptInt( CONTEXT.GetOptProperty( "pole_new_subdivision", "" ) ) == 1 && CONTEXT.GetOptProperty( "pole_subdivision_name", "" ) != "" )
							continue;
						if( arr_need_new_fields[ i ] == "job_id" && OptInt( CONTEXT.GetOptProperty( "pole_new_job", "" ) ) == 1 && CONTEXT.GetOptProperty( "pole_job_name", "" ) != "" )
							continue;
						arr_not_fields.push( arr_need_new_fields_name[ i ] );
					}
			if( CONTEXT.GetOptProperty( "pole_podbor_for", "" ) == "net" && CONTEXT.GetOptProperty( "pole_terr_office_name", "" ) == "" )
				arr_not_fields.push( "��������������� ����" );

			if( CONTEXT.GetOptProperty( "pole_justification", "" ) == "parental_leave" || CONTEXT.GetOptProperty( "pole_justification", "" ) == "replace" )
			{
				if( OptInt( CONTEXT.GetOptProperty( "pole_change_collaborator_id", "" ) ) == undefined )
					arr_not_fields.push( "������ ����" );
			}
			
			if( CONTEXT.GetOptProperty( "pole_is_digital", "" ) == "yes" )
			{
				if( OptInt( CONTEXT.GetOptProperty( "pole_digital_role_id", "" ) ) == undefined )
					arr_not_fields.push( "���� digital" );
			}

			if( CONTEXT.GetOptProperty( "pole_COI", "" ) == "" && CONTEXT.GetOptProperty( "pole_COI", "" ) == null && CONTEXT.GetOptProperty( "pole_COI", "" ) == undefined && CONTEXT.GetOptProperty( "pole_COI", "" ) != "true" && OptInt(CONTEXT.GetOptProperty( "pole_COI", "" )) != 1)
			{
					arr_not_fields.push( "������������� ���������� ���������� ��������� ���������" );
			}
				

			if( ArrayOptFirstElem( arr_not_fields ) != undefined )
			{
				MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
				break;
			}
			/*if( ( CONTEXT.GetOptProperty( "pole_podbor_for", "" ) == "cf" || CONTEXT.GetOptProperty( "pole_podbor_for", "" ) == "net" ) && CONTEXT.GetOptProperty( "pole_hub_id", "" ) == "" )
			{
				MESSAGE = "ALERT=�� ��������� ���� ������ ����������� �";
				break;
			}*/
			
			try {
				var requestTypeDoc = OpenDoc( UrlFromDocID( requestTypeID ) ).TopElem;
			} catch (error) {
				alert("hire\remote_actions\action_rosbank.js case save error: \n " + error);
			}
			
			if( curObjectID == null )
			{
				requestDoc = OpenNewDoc( 'x-local://wtv/wtv_request.xmd' );
				requestDoc.BindToDb( DefaultDb );
				//add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "draft" );
				requestDoc.TopElem.workflow_state = "draft";
				start_state = "draft";
			}
			else
				requestDoc = OpenDoc( UrlFromDocID( curObjectID ) );

			tools.common_filling( 'request_type', requestDoc.TopElem, requestTypeID, requestTypeDoc );

			requestDoc.TopElem.person_id = curUserID;
			tools.common_filling( 'collaborator', requestDoc.TopElem, curUserID, curUser );

			if ( ! requestDoc.TopElem.workflow_id.HasValue )
				requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
			workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			function check_sogl_edit( sogl_person_id )
			{
				sogl_person_id = OptInt( sogl_person_id );
				if( sogl_person_id == undefined )
					return true;
				if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == sogl_person_id && This.begin_state == 'sogl_manager'" ) == undefined )
					return true;
				return false;
			}
			if( action == "save" && requestDoc.TopElem.workflow_state == "sogl_manager" )
			{
					//alert('sogl check')
					nSogl = true;
					//alert( check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) )
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_sogl_request", OptInt(  CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id_2" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id_2" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_sogl_request", OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( nSogl )
					{
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id_3" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id_3" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_sogl_request", OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) == undefined && OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) == undefined && OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) == undefined )
					{
						if( ArrayOptFirstElem( XQuery( "for $i in group_collaborators where ( $i/code = 'hr_go' or $i/code = '" + ( "hr_" + CONTEXT.GetOptProperty( "hub_id", "" ) ) + "' ) and $i/collaborator_id = " + curUserID + " return $i" ) ) == undefined )
						{
							
							requestDoc.TopElem.workflow_state = "hr";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							send_notification_pers( "hr" );
						}
						else
						{
							requestDoc.TopElem.workflow_state = "podbor";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							//alert("test send_request_estaff 1");
							send_notification_podbor( "podbor" );
							send_request_estaff( requestDoc.TopElem );
							//alert("test send_request_estaff 2");
							_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
							recr = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_hr_name&vacancy_id=" + curObjectID ) , 'post', Base64Encode( curUser.fullname ) ).Body
							
						}
					}
			}
			for( elem in CONTEXT )
			{
				if( StrBegins( elem, "pole_language_" ) )
				{
					save_language( StrReplace( elem, "pole_", "" ) );
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = docLang.Xml;
				}
				else if( elem == "pole_comment" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value += ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value != "" ? "<br>" : "" ) + curUser.fullname + " : " + StrReplace( CONTEXT.GetOptProperty( elem, "" ), "\n", "<br>" );
				else if( StrBegins( elem, "pole_" ) )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
			}
			if( action != "save" )
			{
				if( action == "draft" )
				{
					requestDoc.TopElem.workflow_state = "draft";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
				}
				else if( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ) != undefined && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.finish_state == 'hr' && This.person_id == " + OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ) ) == undefined )
				{
					requestDoc.TopElem.workflow_state = "sogl_manager";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					
					tools.create_notification( "rb_hire_sogl_request", OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ), "", requestDoc.DocID, null, requestDoc.TopElem );
				}
				else if( ArrayOptFirstElem( XQuery( "for $i in group_collaborators where ( $i/code = 'hr_go' or $i/code = '" + ( "hr_" + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ) and $i/collaborator_id = " + curUserID + " return $i" ) ) == undefined )
				{
					
					requestDoc.TopElem.workflow_state = "hr";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					send_notification_pers( "hr" );
				}
				else
				{
					requestDoc.TopElem.workflow_state = "podbor";
					//alert("test send_request_estaff 11");
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					send_notification_podbor( "podbor" );
					send_request_estaff( requestDoc.TopElem );
					//alert("test send_request_estaff 22");
					_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
					recr = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_hr_name&vacancy_id=" + curObjectID ) , 'post', Base64Encode( curUser.fullname ) ).Body
					
				}
			}
			
			try
			{
				if( start_state != requestDoc.TopElem.workflow_state )
					add_workflow( requestDoc.TopElem, start_state, requestDoc.TopElem.workflow_state )
				requestDoc.Save();
			}
			catch ( err )
			{
				throw err;
			}
			if( action == "save" )
				MESSAGE = "ALERT=��������� ���������;OPENURL=view_doc.html?mode=rosbank_requests;";
			else if( action == "draft" )
				MESSAGE = "ALERT=������ ���������;OPENURL=view_doc.html?mode=rosbank_requests;";
			else if( action == "return" )
				MESSAGE = "ALERT=������ ���������� � ������;OPENURL=view_doc.html?mode=rosbank_requests;";
			else
				MESSAGE = "ALERT=������ ���������� �� ������������;OPENURL=view_doc.html?mode=rosbank_requests;";
			
			break;
			
		case "hr":
		case "podbor":
		case "hr_go":
		case "hr_go_net":
		case "candidate":
		case "sogl_manager":
			//alert( "action " + action )
			requestDoc = OpenDoc( UrlFromDocID( curObjectID ) );
			arr_not_fields = new Array();
			if( requestDoc.TopElem.workflow_state != "sogl_manager" )
				for( i = 0; i < ArrayCount( arr_need_sogl_fields ); i++ )
					if( CONTEXT.GetOptProperty( "pole_" + arr_need_sogl_fields[ i ], "" ) == "" )
					{
						if( arr_need_sogl_fields[ i ] != "grade" || ( CONTEXT.GetOptProperty( "pole_podbor_for", "" ) == "go" && ( CONTEXT.GetOptProperty( "pole_forma", "" ) == "1001" || CONTEXT.GetOptProperty( "pole_forma", "" ) == "1005" || CONTEXT.GetOptProperty( "pole_forma", "" ) == "" ) ) )
							arr_not_fields.push( arr_need_sogl_fields_name[ i ] );
					}
			if( ArrayOptFirstElem( arr_not_fields ) != undefined )
			{
				MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( ArraySelectDistinct( arr_not_fields, "This" ), "This", ", " );
				break;
			}
			
			for( elem in CONTEXT )
			{
				if( StrBegins( elem, "pole_language_" ) )
				{
					save_language( StrReplace( elem, "pole_", "" ) );
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = docLang.Xml;
				}
				else if( elem == "pole_comment" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value += ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value != "" ? "<br>" : "" ) + curUser.fullname + " : " + StrReplace( CONTEXT.GetOptProperty( elem, "" ), "\n", "<br>" );
				else if( StrBegins( elem, "pole_" ) )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
			}
			if( requestDoc.TopElem.workflow_state == "sogl_manager" && action != "sogl_manager" )
			{
				if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) != undefined )
				{
					action = "sogl_manager"
				}
				else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) != undefined )
				{
					action = "sogl_manager"
				}

			}
			//alert( "action " + action )
			//if( action == "podbor" )
			//	send_notification_podbor( "podbor" );
			if( action == "hr_go" )
				send_notification_group( "hr_go_net", "rb_hire_sogl_request" )
			else if( action == "hr_go_net" )
				send_notification_group( "hr_" + ( type + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ), "rb_hire_sogl_go_net" )
			else if( action == "hr" )
			{
				send_notification_pers( "hr" );
				tools.create_notification( "rb_hire_rosbank_request_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
			}
			else if( action == "sogl_manager" )
			{
				tools.create_notification( "rb_hire_rosbank_request_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
				sogl_id = "";
				if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) != undefined )
				{
					sogl_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value
				}
				else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) != undefined )
				{
					sogl_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value
				}
				tools.create_notification( "rb_hire_sogl_request", sogl_id, "", requestDoc.DocID, null, requestDoc.TopElem );
				add_workflow( requestDoc.TopElem, start_state, requestDoc.TopElem.workflow_state );
			}
			hr_send = false
			if( requestDoc.TopElem.workflow_state == "hr" || requestDoc.TopElem.workflow_state == "hr_go" )
			{
				hr_send = true
			}
			workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			requestDoc.TopElem.workflow_state = action;
			requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
			if( action == "podbor" )
				tools.create_notification( "rb_hire_request_for_manager", requestDoc.TopElem.person_id, "", requestDoc.DocID, null, requestDoc.TopElem );
				
			if( action == "candidate" )
			{
				req_hire = ArrayOptFirstElem( XQuery( "for $i in requests where $i/object_id = " + curObjectID + " and $i/status_id = 'active' return $i" ) );
				dReqHire = OpenDoc( UrlFromDocID( req_hire.id ) );
				workflowDocPred = OpenDoc( UrlFromDocID( dReqHire.TopElem.workflow_id ) ).TopElem;
				add_workflow( dReqHire.TopElem, dReqHire.TopElem.workflow_state, "candidate" );
				dReqHire.TopElem.workflow_state = "candidate";
				dReqHire.TopElem.workflow_state_name = dReqHire.TopElem.get_workflow_state_name( workflowDocPred );
				dReqHire.TopElem.workflow_fields.ObtainChildByKey( "hire_date" ).value = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "date_registration" ).value;
				dReqHire.TopElem.workflow_fields.ObtainChildByKey( "fire_hire_coaching" ).value = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "fire_coaching" ).value;
				
				dReqHire.Save();

				_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
				recr = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_hire_date&vacancy_id=" + curObjectID + "&fire=" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "fire_coaching" ).value ) , 'post', Base64Encode( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "date_registration" ).value ) ).Body
				if( recr != "" )
				{
					recr = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + recr + "' return $i" ) );
					if( recr != undefined )
						tools.create_notification( "rb_hire_rosbank_hire_recr", recr.id, "", dReqHire.DocID, null, dReqHire.TopElem );
				}
						
				tools.create_notification( "rb_hire_rosbank_hire_manager", requestDoc.TopElem.person_id, "", dReqHire.DocID, null, dReqHire.TopElem );
			}

			MESSAGE = "ALERT=������ �����������;OPENURL=view_doc.html?mode=rosbank_requests;";

			if( action == "podbor" )
			{
				//alert("test send_request_estaff 111");
				send_request_estaff( requestDoc.TopElem );
				//alert("test send_request_estaff 222");
				if( hr_send )
				{
					_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
					recr = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_hr_name&vacancy_id=" + curObjectID ) , 'post', Base64Encode( curUser.fullname ) ).Body
				
				}
			}
				
			if( start_state != requestDoc.TopElem.workflow_state )
				add_workflow( requestDoc.TopElem, start_state, requestDoc.TopElem.workflow_state )
				
			requestDoc.Save();
			break;

		case "reject":
			dRequest = OpenDoc( UrlFromDocID( curObjectID ) );
			workflowDoc = OpenDoc( UrlFromDocID( dRequest.TopElem.workflow_id ) ).TopElem;
			for( elem in CONTEXT )
			{
				if( StrBegins( elem, "pole_language_" ) )
				{
					save_language( StrReplace( elem, "pole_", "" ) );
					dRequest.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = docLang.Xml;
				}
				else if( elem == "pole_comment" )
					dRequest.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value += ( dRequest.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value != "" ? "<br>" : "" ) + curUser.fullname + " : " + StrReplace( CONTEXT.GetOptProperty( elem, "" ), "\n", "<br>" );
				else if( StrBegins( elem, "pole_" ) )
					dRequest.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
			}
			add_workflow( dRequest.TopElem, dRequest.TopElem.workflow_state, "reject" )
			dRequest.TopElem.workflow_state = "draft";
			dRequest.TopElem.workflow_state_name = dRequest.TopElem.get_workflow_state_name( workflowDoc );
			if( dRequest.TopElem.person_id != curUserID )
				tools.create_notification( "rb_hire_reject_request", dRequest.TopElem.person_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );
			//for( elem in ArraySelectDistinct( dRequest.TopElem.workflow_log_entrys, "This.person_id" ) )
			//	if( dRequest.TopElem.person_id != elem.person_id )
			//		tools.create_notification( "reject_request", elem.person_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );
			//if( start_state != dRequest.TopElem.workflow_state )
			//	add_workflow( dRequest.TopElem, start_state, dRequest.TopElem.workflow_state );
			dRequest.TopElem.doc_info.creation.app_instance_id += "," + ArrayMerge( dRequest.TopElem.workflow_log_entrys, "This.person_id", "," );
			if( !StrContains( dRequest.TopElem.doc_info.creation.app_instance_id, String( curUserID ) ) )
				dRequest.TopElem.doc_info.creation.app_instance_id += "," + curUserID;
			try
			{
				log_states = new Array();
				if( dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
					log_states = OpenDocFromStr( dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
				if( ArrayOptFirstElem( log_states ) != undefined )
					dRequest.TopElem.workflow_log_entrys.AssignElem( log_states );
				dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value = dRequest.TopElem.workflow_log_entrys.Xml;
			}
			catch( err ){ alert( "hire\remote_actions\action_rosbank.js" + err ); }
			dRequest.TopElem.workflow_log_entrys.Clear();
			dRequest.Save();

			MESSAGE = "ALERT=������ ���������;OPENURL=view_doc.html?mode=rosbank_requests;";

			break;
			
		/*case "return":
			dRequest = OpenDoc( UrlFromDocID( curObjectID ) );
			workflowDoc = OpenDoc( UrlFromDocID( dRequest.TopElem.workflow_id ) ).TopElem;
			for( elem in CONTEXT )
			{
				if( StrBegins( elem, "pole_language_" ) )
				{
					save_language( StrReplace( elem, "pole_", "" ) );
					dRequest.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = docLang.Xml;
				}
				else if( StrBegins( elem, "pole_" ) )
					dRequest.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
			}
			sogl_state = null
			//if( ArrayOptFirstElem( dRequest.TopElem.workflow_log_entrys ) != undefined )
			//	sogl_state = ArrayMax( dRequest.TopElem.workflow_log_entrys, "This.create_date" );
			
			dRequest.TopElem.workflow_state = "draft";
			dRequest.TopElem.workflow_state_name = dRequest.TopElem.get_workflow_state_name( workflowDoc );
			
			if( start_state != dRequest.TopElem.workflow_state )
				add_workflow( dRequest.TopElem, start_state, dRequest.TopElem.workflow_state )
			dRequest.Save();
			if( sogl_state != null && sogl_state.begin_state == "hr_go_net" )
				tools.create_notification( "sogl_go_net", sogl_state.person_id, "", dRequest.DocID, null, dRequest.TopElem );
			else if( sogl_state != null )
				tools.create_notification( "sogl_request" , sogl_state.person_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );


			MESSAGE = "ALERT=������ ���������� � ������;OPENURL=view_doc.html?mode=rosbank_requests;";

			break;*/

		case "add_language":
			if( CONTEXT.GetOptProperty( 'QazxswSelectE' ) != "" )
				languages = String( UrlDecode( CONTEXT.GetOptProperty( 'QazxswSelectE' ) ) ).split( "," );
			else
				languages = new Array();
			select_languages = ArrayExtract( tools.read_object( CONTEXT.GetOptProperty( 'SelectedData' ) ), "This.value" );
			MESSAGE = "SET=QazxswSelectE," + UrlEncode( UrlEncode( ArrayMerge( ArraySelectDistinct( ArrayUnion( languages, select_languages ), "This" ), "This", "," ) ) ) + ";UPDATE=QazxswSelectN";
			break;

		case "delete_language":
			if( CONTEXT.GetOptProperty( 'QazxswSelectE' ) != "" )
			{
				languages = String( UrlDecode( CONTEXT.GetOptProperty( 'QazxswSelectE' ) ) ).split( "," );
				select_languages = ArrayExtract( tools.read_object( CONTEXT.GetOptProperty( 'SelectedData' ) ), "This.value" );
				res = new Array()
				for( el in languages )
				{
					if( ArrayOptFind( select_languages, "This == el" ) == undefined )
						res.push( el );
				}
				MESSAGE = "SET=QazxswSelectE," + UrlEncode( UrlEncode( ArrayMerge( res, "This", "," ) ) ) + ";UPDATE=QazxswSelectN";
			}
			
			break;

		case "check_comp":
			comp_id = Int( CONTEXT.GetOptProperty( 'CompID' ) );
			ind = CONTEXT.GetOptProperty( 'Tmp' );
			MESSAGE = "SET=pole_" + comp_id + "," + ind + ";SET=Show" + comp_id + ",{compvalue" + comp_id + ind + "}";
			break;

		case "check_instruction":
			if( ( OptInt( CONTEXT.GetOptProperty( "pole_new_job", "" ) ) != 1 && CONTEXT.GetOptProperty( "pole_new_job", "" ) != "true" ) && ( OptInt( CONTEXT.GetOptProperty( "pole_new_subdivision", "" )  ) != 1 || CONTEXT.GetOptProperty( "pole_new_subdivision", "" )  != "true" ) && OptInt( CONTEXT.GetOptProperty( "pole_job_id", "" ) ) != undefined && OptInt( CONTEXT.GetOptProperty( "pole_subdivision_id", "" ) ) != undefined )
			{
				req = XQuery( "sql: select req.id, req.create_date from requests req inner join request r on r.id = req.id where r.data.value( '(request/workflow_fields/workflow_field[name=''subdivision_id''])[1]/value[1]', 'nvarchar(max)' ) = '" + CONTEXT.GetOptProperty( "pole_subdivision_id", "" )  + "' and r.data.value( '(request/workflow_fields/workflow_field[name=''job_id''])[1]/value[1]', 'nvarchar(max)' ) = '" + CONTEXT.GetOptProperty( "pole_job_id", "" )  + "'" );
				if( ArrayOptFirstElem( req ) != undefined )
					MESSAGE = "SET=pole_function," + OpenDoc( UrlFromDocID( Int( ArrayMax( req, "Date( This.create_date )" ).id ) ) ).TopElem.workflow_fields.ObtainChildByKey( 'function' ).value;
			}

			break;
			
		case "del_language_level_verbal":
		case "del_language_level_written":
			
			save_language( StrReplace( action, "del_", "" ) );
			ind = Int( CONTEXT.GetOptProperty( "Tmp", "" ) )
			for( el in docLang )
				if( el.ChildIndex == ind )
				{
					el.Delete();
					break;
				}
			MESSAGE = "SET=" + StrReplace( action, "del_", "pole_" ) + "," + UrlEncode( docLang.Xml ) + ";UPDATE=" + StrReplace( action, "del_", "panel_" );
			break;
			
		case "add_language_level_verbal":
		case "add_language_level_written":
			
			save_language( StrReplace( action, "add_", "" ) );

			ch = docLang.AddChild( "language" );
			ch.AddChild( "language", "" );
			ch.AddChild( "level", "" );
			MESSAGE = "SET=" + StrReplace( action, "add_", "pole_" ) + "," + UrlEncode( docLang.Xml ) + ";UPDATE=" + StrReplace( action, "add_", "panel_" );
			break;

		
		case "sogl_person_id_2":
		case "sogl_person_id_3":
		case "sogl_person_id":
			MESSAGE = "";
			p_id = OptInt( CONTEXT.GetOptProperty( "Tmp" ) );
//alert('p_id '+p_id)
			if( p_id == undefined )
			{
				switch( action )
				{
					case "sogl_person_id":
						MESSAGE = "SET=pole_sogl_person_id,;SET=SoglCollaboratorName,;HIDE=StackPanelSoglCollab2;"
					case "sogl_person_id_2":
						MESSAGE += "SET=pole_sogl_person_id_2,;SET=SoglCollaboratorName2,;HIDE=StackPanelSoglCollab3;"
					case "sogl_person_id_3":
						MESSAGE += "SET=pole_sogl_person_id_3,;SET=SoglCollaboratorName3,;"
						break;
				}
				if( MESSAGE != "" )
					break;
			}
			switch( action )
			{
				case "sogl_person_id_3":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2" ) ) == undefined )
					{
						MESSAGE = "ALERT=���������� ������� ������� ������������ �� ������������� 2;"
						break;
					}
				case "sogl_person_id_2":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id" ) ) == undefined )
					{
						MESSAGE = "ALERT=���������� ������� ������� ������������ �� �������������;"
						break;
					}
					break;
			}
			if( MESSAGE != "" )
				break;
			
			switch( action )
			{
				case "sogl_person_id_3":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
				case "sogl_person_id_2":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
				case "sogl_person_id":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
			}
			if( MESSAGE != "" )
				break;
				
			teUser = OpenDoc( UrlFromDocID( p_id ) ).TopElem;
			switch( action )
			{
				case "sogl_person_id_3":
					MESSAGE = "SET=pole_sogl_person_id_3," + p_id + ";SET=SoglCollaboratorName3," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
				case "sogl_person_id_2":
					MESSAGE = "SHOW=StackPanelSoglCollab3;SET=pole_sogl_person_id_2," + p_id + ";SET=SoglCollaboratorName2," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
				case "sogl_person_id":
					MESSAGE = "SHOW=StackPanelSoglCollab2;SET=pole_sogl_person_id," + p_id + ";SET=SoglCollaboratorName," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
			}
				
			break;

		case "check_digital":
			iDigitalID = OptInt( CONTEXT.GetOptProperty( "pole_digital_role_id" ) );
			if( iDigitalID != undefined )
			{
				teDigital = OpenDoc( UrlFromDocID( iDigitalID ) ).TopElem;
				
				MESSAGE = "SHOW=DigitalDesc;SET=pole_digital_desc," +  StrReplace( StrReplace( StrReplace( HtmlToPlainText(  StrReplace( StrReplace( teDigital.desc, "</p>", "$$$$" ), "<p>", "" ) ), ";", "%3B" ), ",", "%2C" ), "$$$$", "\n" )+ ";"
			}
			else
				MESSAGE = "HIDE=DigitalDesc;SET=pole_digital_desc,;"
			
			break;
		
	}
}
catch( ex )
{
	alert( "hire\remote_actions\action_rosbank.js" + ex );
	MESSAGE = "ALERT=" + ex;
}