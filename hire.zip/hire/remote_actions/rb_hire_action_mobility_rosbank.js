/*�������� ��� ������
action:string
CONTEX:string
object_id:string
*/
function send_notification_pers( type )
{
	cond = " $i/code = '" + type + "_" + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value + "' ";
	arr = XQuery( "for $i in groups where " + cond + " return $i" );
	for( gr in ArraySelectDistinct( arr, "This.id" ) )
	{
		teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
		t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
		if( StrContains( t_send, "�� ����� �����" ) )
			tools.create_notification( "rb_hire_rosbank_mobility_resume_" + type + "_group", gr.id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
		if( StrContains( t_send, "������� ���������� ������" ) )
			for( elem in teGroup.collaborators )
				tools.create_notification( "rb_hire_rosbank_mobility_resume_" + type, elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
	}
}

function add_workflow( obj, st, fin )
{
	fldLogEntryChild = obj.workflow_log_entrys.AddChild();
	fldLogEntryChild.create_date = Date();
	fldLogEntryChild.person_id = curUserID;
	fldLogEntryChild.person_fullname = curUser.fullname;
	fldLogEntryChild.begin_state = st;
	fldLogEntryChild.finish_state = fin;
}
function read_experience()
{
	doc_xml = UrlDecode( CONTEXT.GetOptProperty( "ExperienceDocXml", "" ) );
	if( doc_xml != "" )
	{
		arr_deleted = new Array();
		doc_xml = OpenDocFromStr( doc_xml ).TopElem
		for( elem in doc_xml )
		{
			if( OptInt( CONTEXT.GetOptProperty( "hideexperience" + elem.id, "" ) ) == 1 )
			{
				arr_deleted.push( elem.id );
				continue;
			}
			elem.start_date_month = CONTEXT.GetOptProperty( "start_date_month_" + elem.id, "" );
			elem.finish_date_month = CONTEXT.GetOptProperty( "finish_date_month_" + elem.id, "" );
			elem.start_date_year = CONTEXT.GetOptProperty( "start_date_year_" + elem.id, "" );
			elem.finish_date_year = CONTEXT.GetOptProperty( "finish_date_year_" + elem.id, "" );
			elem.org_name = CONTEXT.GetOptProperty( "org_name_" + elem.id, "" );
			elem.job = CONTEXT.GetOptProperty( "job_" + elem.id, "" );
			elem.functions = CONTEXT.GetOptProperty( "functions_" + elem.id, "" );
			elem.for_this_time = CONTEXT.GetOptProperty( "for_this_time" + elem.id, "" );
			elem.region = CONTEXT.GetOptProperty( "region_" + elem.id, "" );
			elem.site = CONTEXT.GetOptProperty( "site_" + elem.id, "" );
			elem.sfera = CONTEXT.GetOptProperty( "sfera_" + elem.id, "" );
		}
		for( elem in arr_deleted )
			for( el in doc_xml )
				if( el.id == elem )
					el.Delete();
	}
	else
	{
		doc_xml = OpenDocFromStr( "<experiences></experiences>" ).TopElem
	}
	return doc_xml;
}

function read_education()
{
	doc_xml = UrlDecode( CONTEXT.GetOptProperty( "EducationDocXml", "" ) );
	if( doc_xml != "" )
	{
		arr_deleted = new Array();
		doc_xml = OpenDocFromStr( doc_xml ).TopElem
		for( elem in doc_xml )
		{
			if( OptInt( CONTEXT.GetOptProperty( "hideeducation" + elem.id, "" ) ) == 1 )
			{
				arr_deleted.push( elem.id );
				continue;
			}
			elem.type_education = CONTEXT.GetOptProperty( "type_education_" + elem.id, "" );
			elem.education_org_name = CONTEXT.GetOptProperty( "education_org_name_" + elem.id, "" );
			elem.faculty = CONTEXT.GetOptProperty( "faculty_" + elem.id, "" );
			elem.specialization = CONTEXT.GetOptProperty( "specialization_" + elem.id, "" );
			elem.speciality = CONTEXT.GetOptProperty( "speciality_" + elem.id, "" );
			elem.finish_year = CONTEXT.GetOptProperty( "finish_year_" + elem.id, "" );
		}
		for( elem in arr_deleted )
			for( el in doc_xml )
				if( el.id == elem )
					el.Delete();
	}
	else
	{
		doc_xml = OpenDocFromStr( "<educations></educations>" ).TopElem
	}
	return doc_xml;
}
function read_qualification()
{
	doc_xml = UrlDecode( CONTEXT.GetOptProperty( "QualificationDocXml", "" ) );
	if( doc_xml != "" )
	{
		arr_deleted = new Array();
		doc_xml = OpenDocFromStr( doc_xml ).TopElem
		for( elem in doc_xml )
		{
			if( OptInt( CONTEXT.GetOptProperty( "hidequalification" + elem.id, "" ) ) == 1 )
			{
				arr_deleted.push( elem.id );
				continue;
			}
			elem.qualification_faculty = CONTEXT.GetOptProperty( "qualification_faculty_" + elem.id, "" );
			elem.qualification_org_name = CONTEXT.GetOptProperty( "qualification_org_name_" + elem.id, "" );
			elem.qualification_specialization = CONTEXT.GetOptProperty( "qualification_specialization_" + elem.id, "" );
			elem.qualification_finish_year = CONTEXT.GetOptProperty( "qualification_finish_year_" + elem.id, "" );
		}
		for( elem in arr_deleted )
			for( el in doc_xml )
				if( el.id == elem )
					el.Delete();
	}
	else
	{
		doc_xml = OpenDocFromStr( "<qualifications></qualifications>" ).TopElem
	}
	return doc_xml;
}

function read_test()
{
	doc_xml = UrlDecode( CONTEXT.GetOptProperty( "TestDocXml", "" ) );
	if( doc_xml != "" )
	{
		arr_deleted = new Array();
		doc_xml = OpenDocFromStr( doc_xml ).TopElem
		for( elem in doc_xml )
		{
			if( OptInt( CONTEXT.GetOptProperty( "hidetest" + elem.id, "" ) ) == 1 )
			{
				arr_deleted.push( elem.id );
				continue;
			}
			elem.test_faculty = CONTEXT.GetOptProperty( "test_faculty_" + elem.id, "" );
			elem.test_org_name = CONTEXT.GetOptProperty( "test_org_name_" + elem.id, "" );
			elem.test_specialization = CONTEXT.GetOptProperty( "test_specialization_" + elem.id, "" );
			elem.test_finish_year = CONTEXT.GetOptProperty( "test_finish_year_" + elem.id, "" );
		}
		for( elem in arr_deleted )
			for( el in doc_xml )
				if( el.id == elem )
					el.Delete();
	}
	else
	{
		doc_xml = OpenDocFromStr( "<tests></tests>" ).TopElem
	}
	return doc_xml;
}

function save_language( type )
{
	xml = CONTEXT.GetOptProperty( "pole_" + type );
	if( xml == "" )
		xml = "<languages/>";
	try
	{
		docLang = OpenDocFromStr( UrlDecode( xml ) ).TopElem;
	}
	catch( er )
	{
		docLang = OpenDocFromStr( "<languages/>" ).TopElem;
	}
	for( l in docLang )
	{
		l.level = CONTEXT.GetOptProperty( type + "_level_" + l.ChildIndex );
		l.language = CONTEXT.GetOptProperty( type + "_language_" + l.ChildIndex );
	}
}

docLang = null;

CONTEXT = tools.read_object( CONTEXT );
//alert(action)
switch( action )
{
	case "add_experience":
		teExperience = read_experience();
		ch = teExperience.AddChild( "experience" );
		ch.AddChild( "start_date_month", "" );
		ch.AddChild( "finish_date_month", "" );
		ch.AddChild( "start_date_year", "" );
		ch.AddChild( "finish_date_year", "" );
		ch.AddChild( "org_name", "" );
		ch.AddChild( "job", "" );
		ch.AddChild( "functions", "" );
		ch.AddChild( "for_this_time", "" )
		ch.AddChild( "site", "" )
		ch.AddChild( "sfera", "" )
		ch.AddChild( "region", "" )
		ch.AddChild( "id", "string" ).Value = tools.random_string( 10 );
		//alert(teExperience.Xml)
		MESSAGE = "SET=ExperienceDocXml," + UrlEncode( teExperience.Xml ) + ";UPDATE=rb_hire_rosbank_panel_experience_mobility";
		break;
		
	case "add_education":
		teEducation = read_education();
		ch = teEducation.AddChild( "education" );
		ch.AddChild( "type_education", "" );
		ch.AddChild( "education_org_name", "" );
		ch.AddChild( "faculty", "" );
		ch.AddChild( "specialization", "" );
		ch.AddChild( "speciality", "" );
		ch.AddChild( "finish_year", "" );
		ch.AddChild( "id", "string" ).Value = tools.random_string( 10 );
		//alert(teEducation.Xml)
		MESSAGE = "SET=EducationDocXml," + UrlEncode( teEducation.Xml ) + ";UPDATE=rb_hire_rosbank_panel_education_mobility";
		break;

	case "add_qualification":
		teEducation = read_qualification();
		ch = teEducation.AddChild( "qualification" );
		ch.AddChild( "qualification_faculty", "" );
		ch.AddChild( "qualification_org_name", "" );
		ch.AddChild( "qualification_specialization", "" );
		ch.AddChild( "qualification_finish_year", "" );
		ch.AddChild( "id", "string" ).Value = tools.random_string( 10 );
		//alert(teEducation.Xml)
		MESSAGE = "SET=QualificationDocXml," + UrlEncode( teEducation.Xml ) + ";UPDATE=rb_hire_rosbank_panel_qualification_mobility";
		break;

	case "add_test":
		teEducation = read_test();
		ch = teEducation.AddChild( "test" );
		ch.AddChild( "test_faculty", "" );
		ch.AddChild( "test_org_name", "" );
		ch.AddChild( "test_specialization", "" );
		ch.AddChild( "test_finish_year", "" );
		ch.AddChild( "id", "string" ).Value = tools.random_string( 10 );
		//alert(teEducation.Xml)
		MESSAGE = "SET=TestDocXml," + UrlEncode( teEducation.Xml ) + ";UPDATE=rb_hire_rosbank_panel_test_mobility";
		break;

	case "add_language":
		if( CONTEXT.GetOptProperty( 'QazxswSelectE' ) != "" )
			languages = String( UrlDecode( CONTEXT.GetOptProperty( 'QazxswSelectE' ) ) ).split( "," );
		else
			languages = new Array();
		select_languages = ArrayExtract( tools.read_object( CONTEXT.GetOptProperty( 'SelectedData' ) ), "This.value" );
		MESSAGE = "SET=QazxswSelectE," + UrlEncode( UrlEncode( ArrayMerge( ArraySelectDistinct( ArrayUnion( languages, select_languages ), "This" ), "This", "," ) ) ) + ";UPDATE=QazxswSelectN";
		break;

	case "delete_language":
		if( CONTEXT.GetOptProperty( 'QazxswSelectE' ) != "" )
		{
			languages = String( UrlDecode( CONTEXT.GetOptProperty( 'QazxswSelectE' ) ) ).split( "," );
			select_languages = ArrayExtract( tools.read_object( CONTEXT.GetOptProperty( 'SelectedData' ) ), "This.value" );
			res = new Array()
			for( el in languages )
			{
				if( ArrayOptFind( select_languages, "This == el" ) == undefined )
					res.push( el );
			}
			MESSAGE = "SET=QazxswSelectE," + UrlEncode( UrlEncode( ArrayMerge( res, "This", "," ) ) ) + ";UPDATE=QazxswSelectN";
		}
			
		break;

	case "check_comp":
		comp_id = Int( CONTEXT.GetOptProperty( 'CompID' ) );
		ind = CONTEXT.GetOptProperty( 'Tmp' );
		MESSAGE = "SET=pole_" + comp_id + "," + ind + ";SET=Show" + comp_id + ",{compvalue" + comp_id + ind + "}";
		break;

	case "check_instruction":
		if( ( OptInt( CONTEXT.GetOptProperty( "pole_new_job", "" ) ) != 1 && CONTEXT.GetOptProperty( "pole_new_job", "" ) != "true" ) && ( OptInt( CONTEXT.GetOptProperty( "pole_new_subdivision", "" )  ) != 1 || CONTEXT.GetOptProperty( "pole_new_subdivision", "" )  != "true" ) && OptInt( CONTEXT.GetOptProperty( "pole_job_id", "" ) ) != undefined && OptInt( CONTEXT.GetOptProperty( "pole_subdivision_id", "" ) ) != undefined )
		{
			req = XQuery( "sql: select req.id, req.create_date from requests req inner join request r on r.id = req.id where r.data.value( '(request/workflow_fields/workflow_field[name=''subdivision_id''])[1]/value[1]', 'nvarchar(max)' ) = '" + CONTEXT.GetOptProperty( "pole_subdivision_id", "" )  + "' and r.data.value( '(request/workflow_fields/workflow_field[name=''job_id''])[1]/value[1]', 'nvarchar(max)' ) = '" + CONTEXT.GetOptProperty( "pole_job_id", "" )  + "'" );
			if( ArrayOptFirstElem( req ) != undefined )
				MESSAGE = "SET=pole_function," + OpenDoc( UrlFromDocID( Int( ArrayMax( req, "Date( This.create_date )" ).id ) ) ).TopElem.workflow_fields.ObtainChildByKey( 'function' ).value;
		}

		break;
			
	case "del_language_level_verbal":
	case "del_language_level_written":
			
		save_language( StrReplace( action, "del_", "" ) );
		ind = Int( CONTEXT.GetOptProperty( "Tmp", "" ) )
		for( el in docLang )
			if( el.ChildIndex == ind )
			{
				el.Delete();
				break;
			}
		MESSAGE = "SET=" + StrReplace( action, "del_", "pole_" ) + "," + UrlEncode( docLang.Xml ) + ";UPDATE=" + StrReplace( action, "del_", "panel_" );
		break;
			
	case "add_language_level_verbal":
	case "add_language_level_written":
			
		save_language( StrReplace( action, "add_", "" ) );

		ch = docLang.AddChild( "language" );
		ch.AddChild( "language", "" );
		ch.AddChild( "level", "" );
		MESSAGE = "SET=" + StrReplace( action, "add_", "pole_" ) + "," + UrlEncode( docLang.Xml ) + ";UPDATE=" + StrReplace( action, "add_", "panel_" );
		break;
		
	case "send_resume":
		arr_need_fields = new Array( "subdivision_id", "job_id", "region_id", "phone", "mobile_phone", "skills" );
		arr_need_field_names = new Array( "�������������", "���������", "�����", "���������� ������� (����������)", "���������� ������� (���.)", "�������� ������" );
		arr_not_fields = new Array();
		for( i = 0; i < ArrayCount( arr_need_fields ); i++ )
		{
			if( arr_need_fields[ i ] == "subdivision_id" || arr_need_fields[ i ] == "job_id" )
			{
				if( OptInt( CONTEXT.GetOptProperty( "pole_vacancy_id", "" ) ) == undefined )
				{
					if( OptInt( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ], "" ) ) == undefined )
					{
						arr_not_fields.push( arr_need_field_names[ i ] );
					}
				}
				else
				{
					if( CONTEXT.GetOptProperty( "pole_" + StrReplace( arr_need_fields[ i ], "_id", "_name" ), "" ) == "" )
					{
						arr_not_fields.push( arr_need_field_names[ i ] );
                    }
				}
				
			}
			else if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ], "" ) ) == "" )
			{
				arr_not_fields.push( arr_need_field_names[ i ] );
            }

        }
        if( Trim(CONTEXT.GetOptProperty( "pole_mobile_phone", "" )) ==  "+7(___) ___-__-__" )
        {
            arr_not_fields.push( arr_need_field_names[ 4 ] );
        }        
		if( ArrayOptFirstElem( arr_not_fields ) != undefined )
		{
			MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
			break;
		}
		if( !tools_web.is_true( CONTEXT.GetOptProperty( "pole_is_sogl" ) ) )
		{
			MESSAGE = "ALERT=" +  "�� ������������ ������������ � ��������� ���������� �����������";
			break;
		}
	case "reject":
		if( action == "reject" )
		{
			if( CONTEXT.GetOptProperty( "pole_reason", "" ) == "" )
			{
				MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� ������� ������";
				break;
			}
			else if( CONTEXT.GetOptProperty( "pole_reason", "" ) == "4" && CONTEXT.GetOptProperty( "pole_hr_comment", "" ) == "" )
			{
				MESSAGE = "ALERT=" +  "��� �������� ������� ������ ������ - ���������� ����������� ��������� ���� ����������� HR-��������";
				break;
			}
		}
	case "send_podbor":
	case "save_resume":
		object_id = OptInt( object_id )
		requestTypeID = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_resume_mobility' return $i" ) ).id;
		requestTypeDoc = OpenDoc( UrlFromDocID( requestTypeID ) ).TopElem;
		if( object_id == undefined )
		{
			requestDoc = OpenNewDoc( 'x-local://wtv/wtv_request.xmd' );
			requestDoc.BindToDb( DefaultDb );
			requestDoc.TopElem.person_id = curUserID;
			tools.common_filling( 'collaborator', requestDoc.TopElem, curUserID, curUser );
			requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
				//add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "" );
		}
		else
			requestDoc = OpenDoc( UrlFromDocID( object_id ) );
				
		tools.common_filling( 'request_type', requestDoc.TopElem, requestTypeID, requestTypeDoc );
		
		
		if ( ! requestDoc.TopElem.workflow_id.HasValue )
			requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
		workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			
		for( elem in CONTEXT )
			if( StrBegins( elem, "pole_" ) )
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
		hub_id = "go_net";
		//subdivision_id = OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "subdivision_id" ).value );
		subdivision_id = OptInt( requestDoc.TopElem.person_id.ForeignElem.position_parent_id );
		if( subdivision_id != undefined )
		{
			teSub = OpenDoc( UrlFromDocID( subdivision_id ) ).TopElem;
			while( teSub != undefined )
			{
				if( StrContains( teSub.name, "�������� ����" ) )
				{
					hub_id = "go";
					break;
				}
				teSub = teSub.parent_object_id.OptForeignElem;
			}
		}
		else if( StrContains( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "subdivision_name" ).value, "�������� ����" ) )
			hub_id = "go";
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "hub_id" ).value = hub_id;
		
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "experience_doc_xml" ).value = read_experience().Xml;
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "education_doc_xml" ).value = read_education().Xml;
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "qualification_doc_xml" ).value = read_qualification().Xml;
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "test_doc_xml" ).value = read_test().Xml;

		save_language( "language_level_verbal" );
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "language_level_verbal" ).value = UrlEncode( docLang.Xml );
		save_language( "language_level_written" );
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "language_level_written" ).value = UrlEncode( docLang.Xml );
		
		last_state = requestDoc.TopElem.workflow_state.Value;
		if( action == "send_resume" )
		{
			requestDoc.TopElem.workflow_state = "hr";
			send_notification_pers( "hr" );
			tools.create_notification( "rb_hire_mobilite_create_resume", curUserID );
			
		}
		else if( action == "send_podbor" )
		{
			requestDoc.TopElem.workflow_state = "podbor";
			vacancy_id = OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "vacancy_id" ).value );
			resume_name = "";
			resume = "";
			teVacancy = null;
			requestDoc.Save();
			if( vacancy_id != undefined )
				try
				{
					teVacancy = OpenDoc( UrlFromDocID( vacancy_id ) ).TopElem;
					resume_name = ArrayOptFirstElem( XQuery( "for $i in requests where $i/id = " + teVacancy.source_id + " return $i" ) ).code;
				}
				catch( err )
				{
					alert( err )
				}
			
			try
			{
				resume = Base64Encode( HttpRequest( UrlAppendPath( global_settings.settings.portal_base_url, "/view_print_resume.html?ext=html&resume_id=" + requestDoc.DocID ), "post" ).Body );
			}
			catch( err ){ alert( err ); }
			
			_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
			teCand = OpenDoc( UrlFromDocID( requestDoc.TopElem.person_id ) ).TopElem;
			
			if( resume_name == "" )
			{
				if( subdivision_id != undefined )
					resume_name = OpenDoc( UrlFromDocID( subdivision_id ) ).TopElem.name;
				else
					resume_name = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "subdivision_name" ).value;
				resume_name += "_";
				job_id = OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "job_id" ).value )
				if( job_id != undefined )
					resume_name += OpenDoc( UrlFromDocID( job_id ) ).TopElem.name;
				else
					resume_name += requestDoc.TopElem.workflow_fields.ObtainChildByKey( "job_name" ).value;
			}
			resume_name += "_" + StrReplace( StrDate( Date(), false ), ".", "-" )
			body = "<candidate><id>" + requestDoc.TopElem.person_id + "</id><lastname>" + teCand.lastname + "</lastname><code>" + teCand.code + "</code><email>" + teCand.email + "</email><firstname>" + teCand.firstname + "</firstname><middlename>" + teCand.middlename + "</middlename>
						<resume>" + resume + "</resume><resume_name>" + resume_name + ".docx</resume_name>
						<desired_position_name>" + ( vacancy_id != undefined ? requestDoc.TopElem.workflow_fields.ObtainChildByKey( "job_name" ).value : ( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "job_id" ).value ) != undefined ? OpenDoc( UrlFromDocID( Int( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "job_id" ).value ) ) ).TopElem.name : "" ) ) + "</desired_position_name>
						<salary>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "salary" ).value + "</salary>
						<region_name>" + ( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "region_id" ).value ) != undefined ? OpenDoc( UrlFromDocID( Int( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "region_id" ).value ) ) ).TopElem.name : "" ) + "</region_name>
						<mobile_phone>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "mobile_phone" ).value + "</mobile_phone>
						<home_phone>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "phone" ).value + "</home_phone>
						<birth_date>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "date_birthday" ).value + "</birth_date>
						<gender_id>" + ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sex" ).value == "w" ? 1 : 0 ) + "</gender_id>
						<email>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "email" ).value + "</email>
						<address>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "address" ).value + "</address>";
						
			body += "<prev_tmp_jobs>";
			for( elem in read_experience() )
			{
				start_date = "";
				try{
					start_date = Date( Int( elem.start_date_year ), Int( elem.start_date_month ), 1 )
				}
				catch( ex ){}
				finish_date = "";
				try{
					if( !tools_web.is_true( elem.for_this_time ) )
						finish_date = Date( Int( elem.finish_date_year ), Int( elem.finish_date_month ), 1 )
				}
				catch( ex ){}
				body += "<prev_job>
							<start_date>" + start_date + "</start_date>
							<end_date>" + finish_date + "</end_date>
							<org_name>" + elem.org_name + "</org_name>
							<position_name>" + elem.job + "</position_name>
							<salary></salary>
							<comment>" + elem.functions + "</comment>
						</prev_job>"; 
			}
		
			body += "</prev_tmp_jobs>";
			
			body += "<prev_tmp_educations>";
			body += "<prev_education>
						<end_year>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_finish_year" ).value + "</end_year>
						<org_name>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_education_org_name" ).value + "</org_name>
						<speciality_name>" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_speciality" ).value + "</speciality_name>
						<is_secondary>0</is_secondary>
						<comment>" + ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_faculty" ).value == "" && requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_specialization" ).value == "" ? "" : "���������: " + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_faculty" ).value + "
�������������: " + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_specialization" ).value ) + "</comment>
					</prev_education>"; 
			for( elem in read_education() )
			{
				body += "<prev_education>\
						<end_year>" + elem.finish_year + "</end_year>\
						<org_name>" + elem.education_org_name + "</org_name>\
						<speciality_name>" + elem.speciality + "</speciality_name>\
						<is_secondary>0</is_secondary>\
						<comment>���������: " + elem.faculty + "\
�������������: " + elem.specialization + "</comment>\
					</prev_education>"; 
			}
		
			body += "</prev_tmp_educations>";
			educ_type = "";
			switch( Base64Decode( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "osnovn_type_education" ).value )  )
			{
				case "������":
					educ_type = 4;
					break;
				case "�������":
					educ_type = 1;
					break;
				case "������������ ������":
					educ_type = 3;
					break;
				case "������� �����������":
					educ_type = 2;
					break;
			}
			if( educ_type != "" )
				body += "<educ_type_id>" + educ_type + "</educ_type_id>";
			
			body += "</candidate>"
					
            HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_candidate&vacancy_id=" + ( teVacancy != null ? teVacancy.source_id : "" ) ) , 'post', Base64Encode( body ) );
/*
            var eventBody = "<body>\
                                 <date>"+ StrDate( Date(), false ) +"</date>\
                             </body>";
            HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=create_update_event"+
            "&vacancy_id=" + ( teVacancy != null ? teVacancy.source_id : "" ) +
            "&candidate_id="  + ( requestDoc.TopElem.person_id ) +
            "&type_id=candidate_select" 
            ) , 'post',  eventBody );
*/
			if( teVacancy != null )
			{
				recr = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=get_recruter&vacancy_id=" + teVacancy.source_id ) , 'post', Base64Encode( curUser.fullname ) ).Body
				if( recr != "" )
				{
					recr = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + recr + "' return $i" ) );
					if( recr != undefined )
						tools.create_notification( "rb_hire_mobilite_resume_for_recr", recr.id, "", requestDoc.DocID, null, requestDoc.TopElem  )
				}
			}
			tools.create_notification( "rb_hire_mobility_candidate", requestDoc.TopElem.person_id )
				
		}
		else if( action == "reject" )
		{
			requestDoc.TopElem.workflow_state = "reject";
			tools.create_notification( "rb_hire_mobility_reject", requestDoc.TopElem.person_id, "", requestDoc.DocID, null, requestDoc.TopElem )
		}
		else
		{
			requestDoc.TopElem.workflow_state = "draft";
		}
		requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );

		if( last_state != requestDoc.TopElem.workflow_state.Value )
			add_workflow( requestDoc.TopElem, last_state, requestDoc.TopElem.workflow_state.Value )
		
		requestDoc.Save();
		if( action == "send_resume" )
			MESSAGE = "ALERT=������ ����������;"
		else if( action == "send_podbor" )
			MESSAGE = "ALERT=������ �����������;"
		else if( action == "reject" )
			MESSAGE = "ALERT=������ ���������;"
		else
			MESSAGE = "ALERT=������ ���������;"
		MESSAGE += "OPENURL=view_doc.html?mode=rb_hire_rosbank_mobility&tab=" + ( action == "send_podbor" || action == "reject" ? 3 : 2 )
		
		break;
		
	case "select_proff":
		selected_objects = CONTEXT.GetOptProperty( "Tmp", "" )
		//alert( selected_objects )
		arr_selected = new Array();
		for( elem in cc_proff_areas )
			if( tools_web.is_true( CONTEXT.GetOptProperty( "ProffAreas"  + elem.id ) ) )
				arr_selected.push( elem.id )
		selected_objects = ArrayMerge( arr_selected, "This", ";" );

		MESSAGE = "SET=TmpProff," + UrlEncode( selected_objects ) + ";CLOSEDIALOG;";
		break;
	case "delete_proff":
		del_id = CONTEXT.GetOptProperty( "TmpProffPanel", "" )
		arrProffAreas = UrlDecode( CONTEXT.GetOptProperty( "pole_proff_areas", "" ) ).split( ";" );
		arrProffAreas = ArraySelect( arrProffAreas, "OptInt( This ) != undefined && OptInt( This ) != " + del_id )

		MESSAGE = "SET=pole_proff_areas," + UrlEncode( ArrayMerge( arrProffAreas, "This", ";" ) ) + ";UPDATE=ProffAreasPanel";
		//alert( MESSAGE )
		break;
}