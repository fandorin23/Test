//��������� ������� ( �������� )

/*
	<wvars>
		<wvar>
			<name>object_id</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>status_id</name>
			<type>string</type>
			<position>2</position>
		</wvar>
	</wvars>
*/

function set_status_vacancy( status, v_id )
{
	_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
	resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=set_status_vacancy&vacancy_id=' + v_id + '&status=' + status ) , 'post' );
	return resp.Body;
}

function send_notification_pers( type, notif )
{
	cond = ""
	if( type == "staff" )
		cond = " $i/code = 'staff_go' "
	else if( type == "im" )
		cond = " $i/code = 'international_mobility' "
	else if( ( type == "svhr" || type == "hr" || type == "hr_sogl_utv" ) && dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
		cond = " $i/code = 'hr_go_net' "
	else if( ( type == "svhr" || type == "hr" || type == "hr_sogl_utv" ) && ( dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
		cond = " $i/code = 'hr_go' "
	else if( type == "job_hr"  )
	{
		if( dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
			cond = " $i/code = 'hr_go_net' "
		else if( ( dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || dRequest.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
			cond = " $i/code = 'hr_go' "
		type = "job"
	}
	else if( type == "job_ukil"  )
	{
		cond = " $i/code = 'ukil_go' ";
		type = "job"
	}
	else if( type == "ukil"  )
	{
		cond = " $i/code = 'ukil_go' ";
	}
	else
		cond = " $i/code = '" + ( type == "svhr" || type == "hr_sogl_utv" ? "hr" : type ) + "_" + ( dRequest.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ";
	for( elem in XQuery( "for $i in groups where " + cond + " return $i" ) )
		send_notification_group( elem.code, notif )
		//tools.create_notification( notif, elem.collaborator_id, "", dRequest.DocID, null, dRequest.TopElem );
}

function send_notification_podbor( type )
{
	if( dRequest.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value == "" )
		cond = " $i/code = '" + type + "_go' "
	else
		cond = " $i/code = '" + type + "_" + dRequest.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value + "' "
	for( elem in XQuery( "for $i in groups where " + cond + " return $i" ) )
		send_notification_group( elem.code, "rosbank_recruiter" )
		//tools.create_notification( "rosbank_recruiter", elem.collaborator_id, "", dRequest.DocID, null, dRequest.TopElem );
}
function send_notification_group( type, notif )
{
	gr = ArrayOptFirstElem( XQuery( "for $i in groups where $i/code = '" + type + "' return $i" ) );
	teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
	t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
	if( StrContains( t_send, "�� ����� �����" ) )
		tools.create_notification( notif + "_group", gr.id, curUser.fullname, dRequest.DocID, teGroup, dRequest.TopElem );
	if( StrContains( t_send, "������� ���������� ������" ) )
		for( elem in XQuery( "for $i in group_collaborators where $i/group_id = " + gr.id + " return $i" ) )
			tools.create_notification( notif, elem.collaborator_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );
}

function add_workflow( obj, st, fin )
{
	fldLogEntryChild = obj.workflow_log_entrys.AddChild();
	fldLogEntryChild.create_date = Date();
	fldLogEntryChild.person_id = curUserID;
	fldLogEntryChild.person_fullname = curUser.fullname;
	fldLogEntryChild.begin_state = st;
	fldLogEntryChild.finish_state = fin;
}

//alert( 'status_id '+status_id )
dRequest = OpenDoc( UrlFromDocID( Int( object_id ) ) );
workflowDoc = OpenDoc( UrlFromDocID( dRequest.TopElem.workflow_id ) ).TopElem;
l_state = dRequest.TopElem.workflow_state.Value;
//alert( 'l_state ' + l_state )
dRequest.TopElem.workflow_state = status_id;
if( status_id == "cancel" )
{
	//tools.create_notification( "cancel_request", dRequest.TopElem.person_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );
	add_workflow( dRequest.TopElem, l_state, dRequest.TopElem.workflow_state )
	code_notif = "rb_hire_rosbank_transfer_cancel_request";
	for( elem in ArraySelectDistinct( dRequest.TopElem.workflow_log_entrys, "This.person_id" ) )
		if( elem.person_id.HasValue && dRequest.TopElem.person_id != elem.person_id )
			tools.create_notification( code_notif, elem.person_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );

	function sogl_manager( dDoc )
	{
		sogl = OptInt( dDoc.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value )
		if( sogl != undefined )
		{
			if( ArrayOptFind( dDoc.workflow_log_entrys, "This.person_id == sogl && This.begin_state == 'sogl_manager'" ) == undefined )
				return sogl;
			else
			{
				sogl = OptInt( dDoc.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_2" ).value )
				if( sogl != undefined )
				{
					if( ArrayOptFind( dDoc.workflow_log_entrys, "This.person_id == sogl && This.begin_state == 'sogl_manager'" ) == undefined )
						return sogl;
					else
					{
						sogl = OptInt( dDoc.workflow_fields.ObtainChildByKey( "sogl_collaborator_id_3" ).value )
						if( sogl != undefined )
						{
							if( ArrayOptFind( dDoc.workflow_log_entrys, "This.person_id == sogl && This.begin_state == 'sogl_manager'" ) == undefined )
								return sogl;
							else
								return undefined;
						}
						else
							return sogl
					}
				}
				else
					return sogl
			}
		}
		else
			return sogl
	}
	sogl_id = sogl_manager( dRequest.TopElem )
	//sogl_id = dRequest.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value

	dRequest.TopElem.doc_info.creation.app_instance_id += "," + ArrayMerge( dRequest.TopElem.workflow_log_entrys, "This.person_id", "," );
	if( !StrContains( dRequest.TopElem.doc_info.creation.app_instance_id, String( curUserID ) ) )
		dRequest.TopElem.doc_info.creation.app_instance_id += "," + curUserID;

	try
	{
			log_states = new Array();
			if( dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
				log_states = OpenDocFromStr( dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
			if( ArrayOptFirstElem( log_states ) != undefined )
				dRequest.TopElem.workflow_log_entrys.AssignElem( log_states );
			dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value = dRequest.TopElem.workflow_log_entrys.Xml;
	}
	catch( err ){ alert( err ); }

	
	dRequest.TopElem.workflow_log_entrys.Clear();
	//alert( 'l_state ' + l_state )
	//alert( 'sogl_id ' + sogl_id )
	if( l_state == "hr_go" )
		send_notification_group( "hr_go", code_notif )
		//for( elem in XQuery( "for $i in group_collaborators where $i/code = 'hr_go_net' return $i" ) )
		//	tools.create_notification( code_notif, elem.collaborator_id, "", dRequest.DocID, null, dRequest.TopElem );
	else if( l_state == "hr_go_net" )
		send_notification_group( "hr_go_net", code_notif )
	else if( l_state == "hr" )
		send_notification_pers( "hr", code_notif );
	else if( l_state == "sogl_manager" && sogl_id != undefined )
		tools.create_notification( code_notif, sogl_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );
	else if( l_state == "dmto" )
		send_notification_pers( "dmto", code_notif );
	else if( l_state == "cuchr" )
		send_notification_pers( "cuchr", code_notif );
	else if( l_state == "staff" )
		send_notification_pers( "staff", code_notif );
	else if( l_state == "cuchr_go" )
	{
		send_notification_pers( "cuchr", code_notif );
		//send_notification_group( "cuchr_go", code_notif )
		//for( elem in XQuery( "for $i in group_collaborators where $i/code = 'cuchr_go' return $i" ) )
		//	tools.create_notification( code_notif, elem.collaborator_id, curUser.fullname, dRequest.DocID, null, dRequest.TopElem );
	}
}
if( status_id == "reject" ||  status_id == "draft" ||  status_id == "new" )
{
	if( status_id == "new" )
	{
		if( ArrayOptFirstElem( XQuery( "for $i in requests where $i/object_id = " + dRequest.DocID + " and $i/workflow_state != 'cancel' return $i" ) ) != undefined )
		{
			MESSAGE = "ALERT=�� ������ ���� ������������ �������������;"
			ERROR = 1;
			Cancel();
		}
	}
	if(status_id == "reject")
		add_workflow( dRequest.TopElem, status_id , l_state)
	dRequest.TopElem.workflow_state = status_id;
	
	dRequest.TopElem.status_id = "active";
	dRequest.TopElem.doc_info.creation.app_instance_id += "," + ArrayMerge( dRequest.TopElem.workflow_log_entrys, "This.person_id", "," );
	if( !StrContains( dRequest.TopElem.doc_info.creation.app_instance_id, String( curUserID ) ) )
		dRequest.TopElem.doc_info.creation.app_instance_id += "," + curUserID;
	if( status_id == "reject" )
	{
		try
		{
			log_states = new Array();
			if( dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
				log_states = OpenDocFromStr( dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
			if( ArrayOptFirstElem( log_states ) != undefined )
				{
					cnt = 0;
					for( e in log_states )
					{
						_ch = dRequest.TopElem.workflow_log_entrys.AddChild();
						_ch.AssignElem( e );
						_ch.SetChildIndex( cnt );
						cnt++;
					}
				}
			dRequest.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value = dRequest.TopElem.workflow_log_entrys.Xml;
		}
		catch( err ){ alert( err ); }

		dRequest.TopElem.workflow_log_entrys.Clear();
	}
	if( status_id == "new" )
	{
		if( dRequest.TopElem.request_type_id == 6405549321361564798 )
			set_status_vacancy( "vacancy_submitted", object_id );
		dRequest.TopElem.custom_elems.ObtainChildByKey( "notif_recruter" ).value = false;
		if( OptInt( dRequest.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ) != undefined && ArrayOptFind( dRequest.TopElem.workflow_log_entrys, "This.finish_state == 'hr' && This.person_id == " + OptInt( dRequest.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ) ) == undefined )
		{
			dRequest.TopElem.workflow_state = "sogl_manager";
			dRequest.TopElem.workflow_state_name = dRequest.TopElem.get_workflow_state_name( workflowDoc );
			tools.create_notification( "rb_hire_sogl_request", OptInt( dRequest.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value ), "", dRequest.DocID, null, dRequest.TopElem );
		}
		else if( ArrayOptFirstElem( XQuery( "for $i in group_collaborators where ( $i/code = 'hr_go' or $i/code = '" + ( "hr_" + dRequest.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ) and $i/collaborator_id = " + curUserID + " return $i" ) ) == undefined )
		{
				
			dRequest.TopElem.workflow_state = "hr";
			dRequest.TopElem.workflow_state_name = dRequest.TopElem.get_workflow_state_name( workflowDoc );
			send_notification_pers( "hr" );
		}
		else
		{
			dRequest.TopElem.workflow_state = "podbor";
			dRequest.TopElem.workflow_state_name = dRequest.TopElem.get_workflow_state_name( workflowDoc );
			send_notification_podbor( "podbor" );
			send_request_estaff( dRequest.TopElem );
		}
	}
}

dRequest.TopElem.workflow_state_name = dRequest.TopElem.get_workflow_state_name( workflowDoc );
MESSAGE = "������ ������� �� " + dRequest.TopElem.workflow_state_name;
dRequest.Save();