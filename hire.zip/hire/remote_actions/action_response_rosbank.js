//�������� ������ �� ��������
/*
	<wvars>
		<wvar>
			<name>CONTEXT</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>action</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>request_id</name>
			<type>string</type>
			<position>3</position>
		</wvar>
	</wvars>
*/

function send_notification_podbor( type )
{
	if( dRequest.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value == "" )
		cond = " $i/code = '" + type + "_go' "
	else
		cond = " $i/code = '" + type + "_" + dRequest.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value + "' "
	for( elem in XQuery( "for $i in groups where " + cond + " return $i" ) )
		send_notification_group( elem.code, "rb_hire_rosbank_manager_comment" );
}

function send_notification_group( type, notif )
{
	gr = ArrayOptFirstElem( XQuery( "for $i in groups where $i/code = '" + type + "' return $i" ) );
	teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
	t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
	if( StrContains( t_send, "�� ����� �����" ) )
		tools.create_notification( notif + "_group", gr.id, sub_staff_name, dRequest.DocID, teGroup, dRequest.TopElem );
	if( StrContains( t_send, "������� ���������� ������" ) )
		for( elem in XQuery( "for $i in group_collaborators where $i/group_id = " + gr.id + " return $i" ) )
			tools.create_notification( notif, elem.collaborator_id, sub_staff_name, dRequest.DocID, null, dRequest.TopElem );
}

CONTEXT = tools.read_object( CONTEXT );
switch( action )
{
	case "create_response":
		request_id = OptInt( request_id );
		dRequest = OpenDoc( UrlFromDocID( request_id ) );
		iResponseTypeID = ArrayOptFirstElem( XQuery( "for $i in response_types where $i/code = 'rosbank_vacancy' return $i" ) ).id;
		teResponseType = OpenDoc( UrlFromDocID( iResponseTypeID ) ).TopElem
		docResponse = OpenNewDoc( 'x-local://wtv/wtv_response.xmd' );
		teResponse = docResponse.TopElem;
		tools.common_filling( 'response_type', teResponse, iResponseTypeID, teResponseType );

		teResponse.person_id = curUserID;
		tools.common_filling( 'collaborator', teResponse, curUserID, curUser );
		/*oRes = tools_web.custom_elems_filling( teResponse, CONTEXT, null, ({ 'sCatalogName': 'response_type', 'iObjectID': iResponseTypeID, 'bCheckMandatory': true, 'bCheckCondition': true }) );
		if ( oRes.error != 0 )
		{
			ERROR = 1;
			MESSAGE = '';
			if ( ArrayCount( oRes.mandatory_fields ) != 0 )
				MESSAGE += StrReplace( tools_web.get_web_const( 'neobhodimozapo_1', curLngWeb ), '{PARAM1}', ArrayMerge( oRes.mandatory_fields, 'tools_web.get_cur_lng_name(This.title,curLng.short_id)', '", "' ) );
			if ( ArrayCount( oRes.condition_fields ) != 0 )
				MESSAGE += ' ' + StrReplace( tools_web.get_web_const( 'nevernyeznachen', curLngWeb ), '{PARAM1}', ArrayMerge( oRes.condition_fields, 'tools_web.get_cur_lng_name(This.title,curLng.short_id)', '", "' ) );
			break;
		}*/
		res = false;
		try
		{
			res = tools_web.web_custom_elems_filling( 'response', null, teResponse, CONTEXT, true );
		}
		catch ( e )
		{
			alert( e );
		}
		if ( res != true && res != false )
		{
			ERROR = 1;
			MESSAGE = StrReplace( tools_web.get_web_const( 'neobhodimozapo_1', curLngWeb ), '{PARAM1}', res.title );
			break;
		}

		teResponse.comment = tools_web.convert_xss( CONTEXT.GetOptProperty( "ResponseComment" ) );

		dRequest.TopElem.workflow_fields.ObtainChildByKey( "manager_response" ).value = teResponse.comment;
		dRequest.Save();
		teResponse.object_id = request_id;
		tools.object_filling( teResponse.type, teResponse, request_id, dRequest.TopElem );
		_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
		resp = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_response_vacancy&vacancy_id=" + request_id ) , 'post', Base64Encode( teResponse.comment ) ).Body
		docResponse.BindToDb( DefaultDb );
		docResponse.Save();
		sub_staff_name = ""
		try
		{
			sub = OpenDoc( UrlFromDocID( Int( dRequest.TopElem.workflow_fields.ObtainChildByKey( "subdivision_id" ).value ) ) ).TopElem;

			dSub = sub;
			nArr = new Array();
			ind = 0
			do
			{
				nArr.push( { name: dSub.name, ind: ind } )
				ind++;
				if( !dSub.parent_object_id.HasValue )
				{
					nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
					break
				}
				else
					dSub = dSub.parent_object_id.OptForeignElem;
			}
			while( true )
			nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
			sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")
		}
		catch( ex ){}
		if( resp != "" )
		{
			recr_collab = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + resp + "' return $i" ) );
			if( recr_collab != undefined )
			{
				tools.create_notification( "rb_hire_rosbank_manager_comment", recr_collab.id, sub_staff_name, dRequest.DocID, null, dRequest.TopElem );
			}

		}
		
		send_notification_podbor( "podbor" );
		MESSAGE = "ALERT=��� ����� ��������;OPENURL=view_doc.html?mode=request&object_id=" + request_id
		break;
}