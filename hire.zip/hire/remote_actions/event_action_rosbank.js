//�������� ��� ��������� Estaff
/*
	<wvars>
		<wvar>
			<name>action</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>status</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>event_id</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>tmp</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>req_id</name>
			<type>string</type>
			<position>5</position>
		</wvar>
		<wvar>
			<name>event_type</name>
			<type>string</type>
			<position>6</position>
		</wvar>
		<wvar>
			<name>vacancy_id</name>
			<type>string</type>
			<position>7</position>
		</wvar>
		<wvar>
			<name>ruk_sb_collaborator_id</name>
			<type>string</type>
			<position>8</position>
		</wvar>
		<wvar>
			<name>candidate_name</name>
			<type>string</type>
			<position>9</position>
		</wvar>
		<wvar>
			<name>CONTEXT</name>
			<type>string</type>
			<position>10</position>
		</wvar>
	</wvars>
*/

function set_status( status, e_id, comment )
{
	_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
	resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=set_status_event&event_id=' + e_id + '&status=' + status ) , 'post', Base64Encode( comment ) );
	recr = OpenDocFromStr( resp.Body ).TopElem;
	catEvent = ArrayOptFirstElem( XQuery( "for $i in cc_estaff_events where $i/code = '" + e_id + "' return $i" ) );
	if( catEvent != undefined )
	{
		docEstaffEvent = OpenDoc( UrlFromDocID( catEvent.id ) );
		docEstaffEvent.TopElem.contact_fullname = curUser.fullname;
		if( !docEstaffEvent.TopElem.finish_date.HasValue )
			docEstaffEvent.TopElem.finish_date = Date();
		docEstaffEvent.TopElem.comment_sogl += ( docEstaffEvent.TopElem.comment_sogl != "" ? "\n" : "" ) + comment;
		docEstaffEvent.Save();
	}
	if( event_type == "rosbank_arbitrazh_sb" && status == "succeeded" )
	{
		rType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_sb_go' return $i" ) );
		requestTypeDoc = OpenDoc( UrlFromDocID( rType.id ) ).TopElem;

		nrequestDoc = OpenNewDoc( 'x-local://wtv/wtv_request.xmd' );
		tools.common_filling( 'request_type', nrequestDoc.TopElem, rType.id, requestTypeDoc );
		nrequestDoc.TopElem.object_id = recr.event;
				
		nrequestDoc.TopElem.custom_elems.ObtainChildByKey( "sb_go" ).value = false;
		nrequestDoc.TopElem.workflow_fields.ObtainChildByKey( "CommentForSB" ).value = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "CommentForSB" ).value;
		
		nrequestDoc.BindToDb( DefaultDb );
		nrequestDoc.Save();
	}
	//tools.start_agent( 6480803783908940642 );
	if( recr.recr != "" && event_type != "event_type_7"  )
	{
		recr_collab = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + recr.recr + "' return $i" ) );
			standart_text = "���������: " + ( dVac.workflow_fields.GetOptChildByKey( "new_job" ).value == "true" || dVac.workflow_fields.GetOptChildByKey( "new_job" ).value == "1" ?  dVac.workflow_fields.GetOptChildByKey( "job_name" ).value : OpenDoc( UrlFromDocID( Int( dVac.workflow_fields.GetOptChildByKey( "job_id" ).value ) ) ).TopElem.name ) + "
�������������: " + get_sub_staff( dVac )+ "
*****************
��� c�����������: " + curUser.fullname + "
��� ���������: " + candidate_name +  "
�������: " + respDoc.name ;
			switch( event_type )
			{
				case "rosbank_arbitrazh_sb":
				case "rb_event_type_7":
					text = "�� �������� � " + dVac.code + " �� " + dVac.create_date + " ������� ����� �� ������� " + ( event_type == "rosbank_arbitrazh_sb" ? "�������� ��" : "�Job offer�" ) + ".
" + standart_text + "
������� � E-Staff, ����� ������������ � ���."
					break;
				case "event_type_6":
				case "rosbank_sb_go":
					//respq = HttpRequest( ( UrlAppendPath( _url, '/rosbank_service.xml?method=get_event_data&event_id=' +  event_id )) , 'get' );
					//respDoc = OpenDocFromStr( respq.Body ).TopElem;
					send_notification_group( "rosbank_verificationsb_" + dTVac.hub_id, "rb_hire_rosbank_sogl_sb", false, ( status == "failed" ? "�������� �� ��������" : "�������� ��������" ) + "$$" + respDoc.candidate_id )
					text = "�� �������� � " + dVac.code + " �� " + dVac.create_date + " ������� ����� �� ������ ������������.
" + standart_text + "
������� � E-Staff, ����� ������������ � ���."
					break;
				default:
					text = "�� �������� � " + dVac.code + " �� " + dVac.create_date + " ������� ����� �� ������������.
" + standart_text + "
������� � E-Staff, ����� ������������ � ���."
			}
		if( recr_collab != undefined )
		{
			tools.create_notification( "rb_hire_rosbank_event_status", recr_collab.id, text + "$$������ �� ������ � " + dVac.code + ", �������� - " + candidate_name + ", ������� - " + respDoc.name, Int( vacancy_id ), null, dVac );
		}
	}
}

function get_sub_staff( TE )
{
	if( OptInt( TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value ) == 1 || TE.workflow_fields.ObtainChildByKey( "new_subdivision" ).value == "true" )
	{
		subname = TE.workflow_fields.ObtainChildByKey( "subdivision_name" ).value
		return subname;
	}
	else
	{
		sub = OpenDoc( UrlFromDocID( Int( TE.workflow_fields.ObtainChildByKey( "subdivision_id" ).value ) ) ).TopElem;

		dSub = sub;
		nArr = new Array();
		ind = 0
		do
		{
			nArr.push( { name: dSub.name, ind: ind } )
			ind++;
			if( !dSub.parent_object_id.HasValue )
			{
				nArr.push( { name: dSub.org_id.OptForeignElem.name, ind: ind } )
				break
			}
			else
				dSub = dSub.parent_object_id.OptForeignElem;
		}
		while( true )
		nArr = ArraySort( nArr, "OptInt( This.ind )", "-" )
		sub_staff_name = ArrayMerge( nArr, "This.name", " -> ")
		return sub_staff_name;
	}
}

function send_notification_group( type, notif, buf, text )
{
	gr = ArrayOptFirstElem( XQuery( "for $i in groups where $i/code = '" + type + "' return $i" ) );
	teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
	t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
	if( StrContains( t_send, "�� ����� �����" ) )
		tools.create_notification( notif + "_group", gr.id, text, vacancy_id, teGroup, dVac );
	if( StrContains( t_send, "������� ���������� ������" ) )
		for( elem in XQuery( "for $i in group_collaborators where $i/group_id = " + gr.id + " return $i" ) )
			if( !buf || elem.collaborator_id != dVac.person_id )
				tools.create_notification( notif, elem.collaborator_id, text, vacancy_id, null, dVac );
}

req_id = OptInt( req_id );
_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_vacancy_data&vacancy_id=' + vacancy_id ) , 'post', '' );
dTVac = OpenDocFromStr( resp.Body ).TopElem;
resp = HttpRequest( ( UrlAppendPath( _url, '/rosbank_service.xml?method=get_event_data&event_id=' + event_id )) , 'get' );
respDoc = OpenDocFromStr( resp.Body ).TopElem;
try
{
	dVac = OpenDoc( UrlFromDocID( Int( vacancy_id ) ) ).TopElem;
}
catch( ex )
{
	dVac = OpenNewDoc( "x-local://wtv/wtv_request.xmd" ).TopElem;
	
	dVac.code = dTVac.code;
	pers = undefined;
	if( dTVac.person_code.HasValue )
		pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + dTVac.person_code + "' return $i" ) );
	if( pers != undefined )
		dVac.person_id = pers.id
	dVac.create_date = dTVac.date;
	dVac.workflow_fields.ObtainChildByKey( "hub_id" ).value = dTVac.hub_id;
	dVac.workflow_fields.ObtainChildByKey( "new_job" ).value = "true";
	dVac.workflow_fields.ObtainChildByKey( "job_name" ).value =DecodeCharset( Base64Decode( dTVac.job_name ), "windows-1251" ) ;
	dVac.workflow_fields.ObtainChildByKey( "new_subdivision" ).value = "true";
	dVac.workflow_fields.ObtainChildByKey( "subdivision_name" ).value = DecodeCharset( Base64Decode( dTVac.sub_staff_name ), "windows-1251" ) ;
}

dVac.workflow_fields.ObtainChildByKey( "hub_id" ).value = dTVac.hub_id;
recr = undefined
if( respDoc.recr_id != "" )
	recr = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + respDoc.recr_id + "' return $i" ) )
dVac.workflow_fields.ObtainChildByKey( "recr" ).value = respDoc.recr_fullname + ( recr != undefined ? ", " + recr.email : "" );

switch( action )
{
	case "set_status":
		if( req_id == undefined )
			set_status( status, event_id, ( tmp != "" ? curUser.fullname + ": " + tmp : "" ) );
		else
		{
			requestDoc = OpenDoc( UrlFromDocID( req_id ) );
			if( event_type == "rosbank_arbitrazh_sb" )
			{
				CONTEXT = tools.read_object( CONTEXT );
			
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "CommentForSB" ).value = curUser.fullname + ": " + CONTEXT.GetOptProperty( "CommentForSB", "" );

			}
				
			if( tmp != "" && requestDoc.TopElem.request_type_id != ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_sb_go' return $i" ) ).id )
				requestDoc.TopElem.comment += ( requestDoc.TopElem.comment != "" ? "\n" : "" ) + curUser.fullname + ": " + tmp;
			if( status == "failed" && event_type != "event_type_6" && event_type != "rosbank_arbitrazh_sb" )
			{
				if( requestDoc.TopElem.custom_elems.GetOptChildByKey( "sb_go" ) != undefined && String( requestDoc.TopElem.custom_elems.GetOptChildByKey( "sb_go" ).value ) == "false" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( "comment" ).value = curUser.fullname + ": " + tmp
				if( requestDoc.TopElem.custom_elems.GetOptChildByKey( "go_sb" ) != undefined && String( requestDoc.TopElem.custom_elems.GetOptChildByKey( "go_sb" ).value ) == "false" )
					requestDoc.TopElem.comment += ( requestDoc.TopElem.comment != "" ? "\n" : "" ) + curUser.fullname + ": " + tmp;
				requestDoc.TopElem.status_id = "ignore";
				set_status( status, event_id, requestDoc.TopElem.comment );
			}
			else
			{
				requestDoc.TopElem.custom_elems.ObtainChildByKey( String( curUserID ) ).value = "true";
				if( requestDoc.TopElem.custom_elems.GetOptChildByKey( "hr" ) != undefined && String( requestDoc.TopElem.custom_elems.GetOptChildByKey( "hr" ).value ) == "false" )
				{
					isHR = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where  $i/code = 'hr_" + dVac.workflow_fields.ObtainChildByKey( "hub_id" ).value + "' and $i/collaborator_id = " + curUserID + " return $i" ) ) != undefined;
					if( isHR )
						requestDoc.TopElem.custom_elems.ObtainChildByKey( "hr" ).value = "true";
				}
				if( requestDoc.TopElem.custom_elems.GetOptChildByKey( "sb_go" ) != undefined && String( requestDoc.TopElem.custom_elems.GetOptChildByKey( "sb_go" ).value ) == "false" )
				{
					sb_go = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where  $i/code = 'sb_" + dVac.workflow_fields.ObtainChildByKey( "hub_id" ).value + "' and $i/collaborator_id = " + curUserID + " return $i" ) ) != undefined;
					if( sb_go )
					{
						_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? '' : tools_web.get_url_protocol( Request.Url ) ) + global_settings.settings.recruitment.estaff_server_url;
						resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_event_data&event_id=' + event_id ) , 'post', '' );
						//alert(resp.Body)
						ev = OpenDocFromStr( resp.Body ).TopElem

						requestDoc.TopElem.custom_elems.ObtainChildByKey( "sb_go" ).value = "true";
						
						link = UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + event_id + "&vacancy_id=" + ev.vacancy_id )  + "&&" + ev.candidate_name  + "&&" + event_id + "&&" + ev.is_urgent + "&&" + status + "&&" + curUser.fullname + "&&" + respDoc.region+"&&" + ev.comment + ( ev.comment != "" ? "\n" : "" ) + curUser.fullname + ": " + tmp;
						ruk_sb_collaborator_id = OptInt( ruk_sb_collaborator_id );
						if( ruk_sb_collaborator_id == undefined )
						{
							//send_notification_group( dVac.workflow_fields.ObtainChildByKey( "hub_id" ).value + '_sb', "rb_hire_rosbank_sb_go_event_15", false, link );
							MESSAGE = "ALERT=���������� ������� ������������� ������������ ��;"
							break;
						}
						else
						{
							requestDoc.TopElem.workflow_fields.ObtainChildByKey( "ruk_sb_collaborator_id" ).value = ruk_sb_collaborator_id;
							tools.create_notification( "rb_hire_rosbank_sb_go_event_15", ruk_sb_collaborator_id, link, vacancy_id, null, dVac );
						}
						requestDoc.TopElem.custom_elems.ObtainChildByKey( "go_sb" ).value = "false";
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( "comment" ).value = curUser.fullname + ": " + tmp
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( "status" ).value = status;
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sb_go" ).value = curUserID;
					}
				}
				if( requestDoc.TopElem.custom_elems.GetOptChildByKey( "go_sb" ) != undefined && String( requestDoc.TopElem.custom_elems.GetOptChildByKey( "go_sb" ).value ) == "false" )
				{
					
					go_sb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where  $i/code = '" + dVac.workflow_fields.ObtainChildByKey( "hub_id" ).value + "_sb' and $i/collaborator_id = " + curUserID + " return $i" ) ) != undefined;
					if( go_sb )
					{
						requestDoc.TopElem.comment += ( requestDoc.TopElem.comment != "" ? "\n" : "" ) + curUser.fullname + ": " + tmp;
						requestDoc.TopElem.custom_elems.ObtainChildByKey( "go_sb" ).value = "true";
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( "go_sb" ).value = curUserID;
					}
				}
				if( requestDoc.TopElem.custom_elems.GetOptChildByKey( "arbitrazhsb" ) != undefined && String( requestDoc.TopElem.custom_elems.GetOptChildByKey( "arbitrazhsb" ).value ) == "false" )
				{
					
					arbitrrazhsb = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where  $i/code = 'arbitrazhsb' and $i/collaborator_id = " + curUserID + " return $i" ) ) != undefined;
					if( arbitrrazhsb )
					{
						//requestDoc.TopElem.comment += ( requestDoc.TopElem.comment != "" ? "\n" : "" ) + curUser.fullname + ": " + tmp;
						requestDoc.TopElem.custom_elems.ObtainChildByKey( "arbitrazhsb" ).value = "true";
						requestDoc.TopElem.workflow_fields.ObtainChildByKey( "arbitrazhsb" ).value = curUserID;
					}
				}
				
				if( ArrayOptFind( requestDoc.TopElem.custom_elems, "This.value == 'false'" ) == undefined )
				{
					requestDoc.TopElem.status_id = "close";
					set_status( status, event_id, requestDoc.TopElem.comment );
				}
			}
			requestDoc.Save();
			
		}
		if( status == "failed" )
			MESSAGE = "ALERT=������� ���������;";
		else
			MESSAGE = "ALERT=������� ��������;";
		break;
		
}