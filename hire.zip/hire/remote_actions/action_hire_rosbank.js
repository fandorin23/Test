//�������� ������ �� ����� ( ������� )

/*
	<wvars>
		<wvar>
			<name>action</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>object_id</name>
			<type>string</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>CONTEXT</name>
			<type>string</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>vacancy_id</name>
			<type>string</type>
			<position>4</position>
		</wvar>
    </wvars>    
*/

function send_notification_pers( type )
{
	if( type == "staff" )
		cond = " $i/code = 'staff_go' "
	else if( type == "im" )
		cond = " $i/code = 'international_mobility' "
	else if( type == "hr" && requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
		cond = " $i/code = '" + type + "_go_net' "
	else if( type == "hr" && ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
		cond = " $i/code = '" + type + "_go' "
	else
		cond = " $i/code = '" + type + "_" + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value + "' ";
	arr = XQuery( "for $i in group_collaborators where " + cond + " return $i" );
	for( gr in ArraySelectDistinct( arr, "This.group_id" ) )
	{
		teGroup = OpenDoc( UrlFromDocID( gr.group_id ) ).TopElem;
		t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
		if( StrContains( t_send, "�� ����� �����" ) )
			tools.create_notification( "rb_hire_rosbank_hire_" + type + "_group", gr.group_id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
		if( StrContains( t_send, "������� ���������� ������" ) )
			for( elem in ArraySelect( arr, "This.group_id == gr.group_id" ) )
				tools.create_notification( "rb_hire_rosbank_hire_" + type, elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
	}
	
}

function add_workflow( obj, st, fin )
{
	fldLogEntryChild = obj.workflow_log_entrys.AddChild();
	fldLogEntryChild.create_date = Date();
	obj.workflow_fields.ObtainChildByKey( fldLogEntryChild.create_date ).value = obj.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value;
	fldLogEntryChild.person_id = curUserID;
	fldLogEntryChild.person_fullname = curUser.fullname;
	fldLogEntryChild.begin_state = st;
	fldLogEntryChild.finish_state = fin;
}

function check_access( type )
{
	if( type == "sogl_manager" )
	{
		if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == undefined && requestDoc.TopElem.person_id == curUserID )
			return true
		if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == curUserID && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == curUserID && This.begin_state == 'sogl_manager'" ) == undefined )
		{
			return true
		}
		else if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( 'sogl_person_id' ).value ) && This.begin_state == 'sogl_manager'" ) != undefined )
		{

			if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == curUserID && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == curUserID && This.begin_state == 'sogl_manager'" ) == undefined )
			{
				return true
			}
			else if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( 'sogl_person_id_2' ).value ) && This.begin_state == 'sogl_manager'" ) != undefined )
			{
				if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) == curUserID && ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == curUserID && This.begin_state == 'sogl_manager'" ) == undefined)
				{
					return true
				}
			}
		}
		return false;
	}
	else
	{
		if( type == "cuchr_go" )
			cond = " $i/code = 'cuchr_go' "
		else if( type == "im" )
			cond = " $i/code = 'international_mobility' "
		else if( type == "hr" )
			cond = " $i/code = 'hr_" + ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ? "go" : "go_net" ) + "' "
		else
			cond = " $i/code = '" + type + "_" + ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ";
		arr = XQuery( "for $i in group_collaborators where " + cond + " and $i/collaborator_id = " + curUserID + " return $i" );
		return ( ArrayOptFirstElem( arr ) != undefined );
	}
}

function clear_gph()
{
	if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "forma_hire" ).value == "1002" || requestDoc.TopElem.workflow_fields.ObtainChildByKey( "forma_hire" ).value == "1003" )
	{
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "job_id" ).value = "";
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "staff_unit_name" ).value = "";
		requestDoc.TopElem.workflow_fields.ObtainChildByKey( "staff_unit_position_name" ).value = "";
	}
}

isHR = ArrayOptFirstElem( XQuery( "for $i in group_collaborators where contains( $i/code, 'hr_' ) and $i/collaborator_id = " + curUserID + " return $i" ) ) != undefined;
arr_need_fields = new Array( "final_candidate", "podbor_for", "job_id", "position_instruction", "gain", "probation", "forma_hire", "place_id", "pomechenie_id", "justification_acceptance", "hub_id", "is_digital", "format_of_work" );
//if( isHR )
//	arr_need_fields.push( "staff_unit" );
arr_need_field_names = new Array( "��� ��������� ���������", "��������� ���", "���������", "������� ����������� ����������", "�����",  "������������� ����", "����� �����", "������� ����� (�����)", "���������, � �������� �����", "����������� ������", "����� ����������� �", "�������", "Digital", "������ ������" );
MESSAGE = "";
try
{
	//alert("CONTEXT n\ " + CONTEXT );
	CONTEXT = tools.read_object( CONTEXT );
	//alert( 'action '+action )
	switch( action )
	{
		case "check_forma":
			forma = CONTEXT.GetOptProperty( "pole_forma_hire" );
			switch( forma )
			{	
				case "1002":
				case "1003":
				case "1005":
					MESSAGE = "HIDE=StackPanelStartDate;SHOW=PeriodDate;";
					break;
				case "1004":
					//if(  CONTEXT.GetOptProperty( "pole_hub_id", "" ) == "" )
					//{
						MESSAGE = "HIDE=StackPanelStartDate;SHOW=PeriodDate;";
						break;
					//}
					//else
					//	MESSAGE = "HIDE=StackPanelStartDate;";
				case "1006":
				case "1001":
					if( forma == "1001" || forma == "1006" )
						MESSAGE = "SHOW=StackPanelStartDate;"

				default:
					MESSAGE += "HIDE=PeriodDate;";
			}
			switch( forma )
			{	
				case "1002":
				case "1003":
				case "1004":
					MESSAGE += "SHOW=StackPanelKuratorSubdivision;";
					break;
				default:
					MESSAGE += "HIDE=StackPanelKuratorSubdivision;";
			}
			break;

		case "check_forma2":
			hub_id = CONTEXT.GetOptProperty( "pole_hub_id" );
			podbor_for = CONTEXT.GetOptProperty( "pole_podbor_for" );
			if( podbor_for == "net" && hub_id == "go" )
				MESSAGE = "SET=pole_hub_id,;ALERT=��� ����. ����� ����� ���� ������ ������ ��������� �������� ���;"

			break;
		case "check_forma3":
			hub_id = CONTEXT.GetOptProperty( "pole_hub_id" );
			podbor_for = CONTEXT.GetOptProperty( "pole_podbor_for" );
			if( podbor_for == "net" && hub_id == "go" )
				MESSAGE = "SET=pole_hub_id,;"

			break;

		case "next_stage":
			
			arr_not_fields = new Array();
			for( i = 0; i < ArrayCount( arr_need_fields ); i++ )
			{

				if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" && ( arr_need_fields[ i ] != "job_id" || CONTEXT.GetOptProperty( "pole_forma_hire" ) != "1002" ) && ( ( arr_need_fields[ i ] != "job_id" && arr_need_fields[ i ] != "staff_unit" ) || CONTEXT.GetOptProperty( "pole_forma_hire" ) != "1003" )  )
				{
					if( ( arr_need_fields[ i ] == "pomechenie_id" || arr_need_fields[ i ] == "place_id" ) && tools_web.is_true( CONTEXT.GetOptProperty( "pole_place_not_need" ) ) )
						continue;
					arr_not_fields.push( arr_need_field_names[ i ] );
				}
			}
			if( OptInt( CONTEXT.GetOptProperty( "pole_final_candidate" ) ) == undefined)
				arr_not_fields.push( "��� ��������� ���������" );
			if( true && ( CONTEXT.GetOptProperty( "pole_forma_hire" ) == "1002" || CONTEXT.GetOptProperty( "pole_forma_hire" ) == "1003" || CONTEXT.GetOptProperty( "pole_forma_hire" ) == "1004" ) )
			{
				if( CONTEXT.GetOptProperty( "pole_kurator_subdivision_id" ) == "" )
					arr_not_fields.push( "�������������-�������" );
			}

			if( CONTEXT.GetOptProperty( "pole_is_digital", "" ) == "yes" )
			{
				if( OptInt( CONTEXT.GetOptProperty( "pole_digital_role_id", "" ) ) == undefined )
					arr_not_fields.push( "���� digital" );
			}
			if( tools_web.is_true( CONTEXT.GetOptProperty( "pole_not_rf" ) ) && CONTEXT.GetOptProperty( "pole_country" ) == "" )
				arr_not_fields.push( "������" );
			if( CONTEXT.GetOptProperty( "pole_forma_hire" ) == "1001" && CONTEXT.GetOptProperty( "pole_start_job_date", "" ) == "" )
				arr_not_fields.push( "���� ������ ������" );
			/*if( ( CONTEXT.GetOptProperty( "pole_podbor_for" ) != "go" && CONTEXT.GetOptProperty( "pole_forma_hire" ) != "" ) )
			{
				if( CONTEXT.GetOptProperty( "pole_hub_id" ) == "" )
					arr_not_fields.push( "������ ����������� �" );
			}*/
			if(  ( CONTEXT.GetOptProperty( "pole_justification_acceptance" ) == "2" || CONTEXT.GetOptProperty( "pole_justification_acceptance" ) == "3" || CONTEXT.GetOptProperty( "pole_justification_acceptance" ) == "4" ) )
			{
				if( CONTEXT.GetOptProperty( "pole_change_coll_id" ) == "" )
					arr_not_fields.push( "������ ����" );
			}
			
			if( CONTEXT.GetOptProperty( "isNew", "" ) == "true" ){
				if(CONTEXT.GetOptProperty( "pole_hire_COI", "" ) == "" || 
				CONTEXT.GetOptProperty( "pole_hire_COI", "" ) == null || 
				CONTEXT.GetOptProperty( "pole_hire_COI", "" ) == undefined ||				 
				  OptInt(CONTEXT.GetOptProperty( "pole_hire_COI", "" )) != 1)
				{
						arr_not_fields.push( "������������� ���������� ���������� ��������� ���������" );
				} 
			}

			if( isHR )
			{
				if( tools_web.is_true( CONTEXT.GetOptProperty( "pole_change_staff_unit" ) ) )
				{
					if( CONTEXT.GetOptProperty( "pole_new_job_id" ) == "" && CONTEXT.GetOptProperty( "pole_new_job_staff_name" ) == ""  )
					{
						if( CONTEXT.GetOptProperty( "pole_podbor_for" ) != "" )
						{
							if( CONTEXT.GetOptProperty( "pole_position_class_id" ) == "" )
							{
								arr_not_fields.push( "����������� ����� (��)" );
								arr_not_fields.push( "������� ������� �������" );
								arr_not_fields.push( "������ �������" );
							}
						}
						/*else
						{
							arr_not_fields.push( "������� ������� �������" );
							arr_not_fields.push( "������ �������" );
						}*/
					}
					/*arr_not_fields.push( "������ �������" );
					if( CONTEXT.GetOptProperty( "pole_new_job_staff_id" ) == "" )
						arr_not_fields.push( "������� ������� �������" );
						
					if( CONTEXT.GetOptProperty( "pole_podbor_for" ) == "go" )
					{
						if( CONTEXT.GetOptProperty( "pole_position_class_id" ) == "" )
							arr_not_fields.push( "����������� ����� (��)" );
					}*/
				}
				else
				{
					if( CONTEXT.GetOptProperty( "pole_staff_unit_name" ) == "" && CONTEXT.GetOptProperty( "pole_forma_hire" ) != "1002" )
						 arr_not_fields.push( "�������" );
				}
			}
			
			
			if( ArrayOptFirstElem( arr_not_fields ) != undefined )
			{
				MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
				break;
			}
			
		case "save":
		case "save_change":
		case "cuchr_go":
		case "cuchr":

			object_id = OptInt( object_id )
			requestTypeID = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_hire' return $i" ) ).id;
			requestTypeDoc = OpenDoc( UrlFromDocID( requestTypeID ) ).TopElem;
			if( object_id == undefined )
			{
				requestDoc = OpenNewDoc( 'x-local://wtv/wtv_request.xmd' );
				requestDoc.BindToDb( DefaultDb );
				requestDoc.TopElem.object_id = vacancy_id;
				requestDoc.TopElem.person_id = curUserID;
				tools.common_filling( 'collaborator', requestDoc.TopElem, curUserID, curUser );
				requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
				//add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "" );
			}
			else
				requestDoc = OpenDoc( UrlFromDocID( object_id ) );
				
			tools.common_filling( 'request_type', requestDoc.TopElem, requestTypeID, requestTypeDoc );

			if ( ! requestDoc.TopElem.workflow_id.HasValue )
				requestDoc.TopElem.workflow_id = requestTypeDoc.workflow_id;
			workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			function check_sogl_edit( sogl_person_id )
			{
				sogl_person_id = OptInt( sogl_person_id );
				if( sogl_person_id == undefined )
					return true;
				if( ArrayOptFind( requestDoc.TopElem.workflow_log_entrys, "This.person_id == sogl_person_id && This.begin_state == 'sogl_manager'" ) == undefined )
					return true;
				return false;
			}
			if( action == "save_change" && requestDoc.TopElem.workflow_state == "sogl_manager" )
			{
					nSogl = true;
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_rosbank_hire_sogl_manager", OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) )
							nSogl = true;
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_rosbank_hire_sogl_manager", OptInt(CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( nSogl )
					{
						nSogl = false;
						if( !check_sogl_edit( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) )
							nSogl = true;
						else if( OptInt( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) != undefined && requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) != OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) )
						{
							nSogl = false;
							tools.create_notification( "rb_hire_rosbank_hire_sogl_manager", OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ), "", requestDoc.DocID, null, requestDoc.TopElem );
						}
					}
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) == undefined || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) == undefined || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) == undefined )
					{
						nSoglId = undefined;
						if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) != undefined && check_sogl_edit( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) ) ) )
							nSoglId = OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id", "" ) );
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) != undefined && check_sogl_edit( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) ) ) )
							nSoglId = OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2", "" ) );
						else if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) != undefined && check_sogl_edit( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) ) ) )
							nSoglId = OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3", "" ) );
						if( nSoglId == undefined )
						{
							clear_gph();
							nState = "";
							sogl_id = ""
							nState = "hr";
							
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, nState );
							requestDoc.TopElem.workflow_state = nState;
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							
							if( nState == "hr" )
								send_notification_pers( "hr" )
						}
					}
					
					
			}
			for( elem in CONTEXT )
			{
				
				if( elem == "pole_comment_hire" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value += ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value != "" ? "<br>" : "" ) + curUser.fullname + " : " + StrReplace( CONTEXT.GetOptProperty( elem, "" ), "\n", "<br>" );
				else if( elem == "pole_premium_percent" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = StrRealFixed( OptReal( StrReplace( CONTEXT.GetOptProperty( elem, "" ), ",", "." ), 0 ), 2 );
				else if( StrBegins( elem, "pole_" ) )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
			}

			if( tools_web.is_true( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "change_staff_unit" ).value ) && OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "new_job_id" ).value ) != undefined )
			{
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "staff_unit_name" ).value = "";
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "staff_unit_position_name" ).value = "";
			}
			_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
			if( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "final_candidate" ) != undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "final_candidate" ).value ) != undefined )
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_candidate_name&candidate_id=' + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "final_candidate" ).value ) , 'post' ).Body
			else
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value = "";
			requestDoc.Save();

			if( action == "save" || action == "reject" || action == "save_change" )
			{
				MESSAGE = "ALERT=������ ���������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
				if( !requestDoc.TopElem.workflow_state.HasValue )
				{
					//add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "draft" );
					requestDoc.TopElem.workflow_state = "draft";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					requestDoc.Save();
				}
				else if( action == "reject" )
				{
					add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "reject" );
					requestDoc.TopElem.workflow_state = "reject";
					requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
					requestDoc.Save();
					MESSAGE = "ALERT=������ ���������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
				}
				else if( action == "save_change" )
					MESSAGE = "ALERT=��������� ���������;OPENURL=view_doc.html?mode=rosbank_requests&tab=2";
			}
			else if( action == "cuchr_go" || action == "cuchr" )
			{
				add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, action );
				requestDoc.TopElem.workflow_state = action;
				requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
				requestDoc.Save();
				send_notification_pers( "cuchr" );
				MESSAGE = "ALERT=������ ����������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
			}
			else if( action == "next_stage" )
			{
				if( !requestDoc.TopElem.workflow_state.HasValue )
				{
					//add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "draft" );
					requestDoc.TopElem.workflow_state = "draft";
				}
				switch( requestDoc.TopElem.workflow_state )
				{
					case "":
					case "draft":
						clear_gph();
						MESSAGE = "ALERT=������������� ���������� �� ������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=2";
						if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value != "" )
						{
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "sogl_manager" );
							requestDoc.TopElem.workflow_state = "sogl_manager";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							tools.create_notification( "rb_hire_rosbank_hire_sogl_manager", requestDoc.TopElem.workflow_fields.ObtainChildByKey( "sogl_person_id" ).value, "", requestDoc.DocID, null, requestDoc.TopElem );
							requestDoc.Save();
							break;
						}
					case "sogl_manager":
						if( !check_access( "sogl_manager" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						clear_gph();
						nState = "";
						sogl_id = ""
						if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) != undefined )
						{
							nState = "sogl_manager";
							sogl_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value
						}
						else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) != undefined )
						{
							nState = "sogl_manager";
							sogl_id = requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value
						}
						else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) == curUserID || ( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == undefined ) || ( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == curUserID && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) == undefined ) )
						{
							nState = "hr";
						}
						else if( OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id" ).value ) == undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_3" ).value ) == undefined && OptInt( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "sogl_person_id_2" ).value ) == undefined )
						{
							nState = "hr";
						}
						if( nState == "" )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						if( requestDoc.TopElem.workflow_state != "" && requestDoc.TopElem.workflow_state != "draft" )
							tools.create_notification( "rb_hire_rosbank_pred_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, nState );
						requestDoc.TopElem.workflow_state = nState;
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						
						if( nState == "hr" )
							send_notification_pers( "hr" )
						else
						{
							tools.create_notification( "rb_hire_rosbank_hire_sogl_manager", sogl_id, "", requestDoc.DocID, null, requestDoc.TopElem );
						}
						if( MESSAGE != "" )
							requestDoc.Save();
						break;
					case "hr":
						if( !check_access( "hr" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						clear_gph();
						tools.create_notification( "rb_hire_rosbank_pred_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
						if( false && ArrayOptFirstElem( XQuery( "for $i in group_collaborators where contains( $i/code, 'hr_" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "hub_id" ).value + "' ) and $i/collaborator_id = " + curUserID + " return $i" ) ) == undefined && ArrayOptFirstElem( XQuery( "for $i in group_collaborators where contains( $i/code, 'hr_go_net' ) and $i/collaborator_id = " + curUserID + " return $i" ) ) != undefined )
						{
							if( tools_web.is_true( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "change_staff_unit" ).value ) && ( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "position_class_id" ).value ) != undefined || OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "new_job_id" ).value ) != undefined || requestDoc.TopElem.workflow_fields.ObtainChildByKey( "new_job_staff_name" ).value != "" || requestDoc.TopElem.workflow_fields.ObtainChildByKey( "grade_hire_id" ).value != "" ) )
								send_notification_pers( "staff" );
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "cuchr" );
							requestDoc.TopElem.workflow_state = "cuchr";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							send_notification_pers( "cuchr" );
							dVac = OpenDoc( UrlFromDocID( requestDoc.TopElem.object_id ) );
							workflowDocVac = OpenDoc( UrlFromDocID( dVac.TopElem.workflow_id ) ).TopElem
							dVac.TopElem.workflow_state = "cuchr";
							dVac.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDocVac );
							dVac.Save();
						}
						else if( tools_web.is_true( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "not_rf" ).value ) )
						{
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "im" );
							requestDoc.TopElem.workflow_state = "im";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							send_notification_pers( "im" );
						}
						else
						{
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "dmto" );
							requestDoc.TopElem.workflow_state = "dmto";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							send_notification_pers( "dmto" );
						}
						break;
					case "im":
						if( !check_access( "im" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						clear_gph();
						tools.create_notification( "rb_hire_rosbank_pred_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "dmto" );
						requestDoc.TopElem.workflow_state = "dmto";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "dmto" );
						break;
					case "dmto":
						if( !check_access( "dmto" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						arr_need_fields = new Array( "place_id", "pomechenie_id" );
						arr_need_field_names = new Array( "������� ����� (�����)", "���������, � �������� �����" );
						arr_not_fields = new Array();
						for( i = 0; i < ArrayCount( arr_need_fields ); i++ )
						{
							if( OptInt( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == undefined && !tools_web.is_true( CONTEXT.GetOptProperty( "pole_place_not_need" ) ) )
							{
								arr_not_fields.push( arr_need_field_names[ i ] );
							}
						}
						if( ArrayOptFirstElem( arr_not_fields ) != undefined )
						{
							MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
							break;
						}
						tools.create_notification( "rb_hire_rosbank_pred_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
						//if( tools_web.is_true( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "change_staff_unit" ).value ) && ( OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "position_class_id" ).value ) != undefined || OptInt( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "new_job_id" ).value ) != undefined || requestDoc.TopElem.workflow_fields.ObtainChildByKey( "new_job_staff_name" ).value != "" || requestDoc.TopElem.workflow_fields.ObtainChildByKey( "grade_hire_id" ).value != "" ) )
						//	send_notification_pers( "staff" );
						if( tools_web.is_true( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "change_staff_unit" ).value ) )
						{
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "staff" );
							requestDoc.TopElem.workflow_state = "staff";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							arr = XQuery( "for $i in group_collaborators where $i/code = 'staff_go' return $i" );
							for( gr in ArraySelectDistinct( arr, "This.group_id" ) )
							{
								teGroup = OpenDoc( UrlFromDocID( gr.group_id ) ).TopElem;
								t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
								if( StrContains( t_send, "�� ����� �����" ) )
									tools.create_notification( "rb_hire_rosbank_hire_staff_group", gr.group_id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
								if( StrContains( t_send, "������� ���������� ������" ) )
									for( elem in ArraySelect( arr, "This.group_id == gr.group_id" ) )
										tools.create_notification( "rb_hire_rosbank_hire_staff", elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
							}
						}
						else
						{
							add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "cuchr" );
							requestDoc.TopElem.workflow_state = "cuchr";
							requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
							send_notification_pers( "cuchr" );
						}
						//dVac = OpenDoc( UrlFromDocID( requestDoc.TopElem.object_id ) );
						//workflowDocVac = OpenDoc( UrlFromDocID( dVac.TopElem.workflow_id ) ).TopElem
						//dVac.TopElem.workflow_state = "cuchr";
						//dVac.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDocVac );
						//dVac.Save();
						break;
					case "staff":
						if( ArrayOptFirstElem( XQuery( "for $i in group_collaborators where $i/code = 'staff_go' and $i/collaborator_id = " + curUserID + " return $i" ) ) == undefined )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "cuchr" );
						tools.create_notification( "rb_hire_rosbank_pred_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
						requestDoc.TopElem.workflow_state = "cuchr";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						send_notification_pers( "cuchr" );
						break;
						
					case "cuchr":
						if( !check_access( "cuchr" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
					case "cuchr_go":
						if( requestDoc.TopElem.workflow_state == "cuchr_go" && !check_access( "cuchr_go" ) )
						{
							MESSAGE = "ALERT=� ��� ��� ���� �� ������������ ������� �������������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3";
							break;
						}
						arr_need_fields = new Array( "hire_date", "fire_hire_coaching" );
						arr_need_field_names = new Array( "���� ������", "�������� ����������" );
						arr_not_fields = new Array();
						for( i = 0; i < ArrayCount( arr_need_fields ); i++ )
						{
							if( String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) ) == "" || String( CONTEXT.GetOptProperty( "pole_" + arr_need_fields[ i ] ) )  == "undefined" )
							{
								arr_not_fields.push( arr_need_field_names[ i ] );
							}
						}
						if( ArrayOptFirstElem( arr_not_fields ) != undefined )
						{
							MESSAGE = "ALERT=" +  "�� ��������� ������������ ���� : " + ArrayMerge( arr_not_fields, "This", ", " );
							break;
						}
						//tools.create_notification( "rb_hire_rosbank_pred_init", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
						add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "candidate" );
						requestDoc.TopElem.workflow_state = "candidate";
						requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
						_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
						recr = HttpRequest( UrlAppendPath( _url, "/rosbank_service.xml?method=set_hire_date&candidate_id=" + requestDoc.TopElem.workflow_fields.GetOptChildByKey( "final_candidate" ).value + "&vacancy_id=" + requestDoc.TopElem.object_id  + "&fire=" + requestDoc.TopElem.workflow_fields.ObtainChildByKey( "fire_hire_coaching" ).value ) , 'post', Base64Encode( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "hire_date" ).value ) ).Body
						if( recr != "" )
						{
							recr = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + recr + "' return $i" ) );
							if( recr != undefined )
								tools.create_notification( "rb_hire_rosbank_hire_recr", recr.id, "", requestDoc.DocID, null, requestDoc.TopElem );
						}
						dVac = OpenDoc( UrlFromDocID( requestDoc.TopElem.object_id ) );
						add_workflow( dVac.TopElem, dVac.TopElem.workflow_state, "candidate" );
						dVac.TopElem.workflow_state = "candidate";
						workflowDocVac = OpenDoc( UrlFromDocID( dVac.TopElem.workflow_id ) ).TopElem
						dVac.TopElem.workflow_state_name = dVac.TopElem.get_workflow_state_name( workflowDocVac );
						dVac.TopElem.workflow_fields.ObtainChildByKey( "date_registration" ).value = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "hire_date" ).value;
						dVac.TopElem.workflow_fields.ObtainChildByKey( "fire_coaching" ).value = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "fire_hire_coaching" ).value;
						dVac.Save();
						
						tools.create_notification( "rb_hire_rosbank_hire_manager", dVac.TopElem.person_id, "", requestDoc.DocID, null, requestDoc.TopElem );
						//send_notification_pers( "cuchr" );
						break;
					
				}
				//alert( "MESSAGE 1 " + MESSAGE )
				if( MESSAGE == "" )
				{
					requestDoc.Save();
					MESSAGE = "OPENURL=view_doc.html?mode=rosbank_requests&tab=3"
				}
			}
			//alert( "MESSAGE 2 " + MESSAGE )
			
			break;
			
		case "reject":
			object_id = OptInt( object_id )
			requestDoc = OpenDoc( UrlFromDocID( object_id ) );
			workflowDoc = OpenDoc( UrlFromDocID( requestDoc.TopElem.workflow_id ) ).TopElem;
			for( elem in CONTEXT )
				if( elem == "pole_comment_hire" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value += ( requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value != "" ? "<br>" : "" ) + curUser.fullname + " : " + StrReplace( CONTEXT.GetOptProperty( elem, "" ), "\n", "<br>" );
				else if( elem == "pole_premium_percent" )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = StrRealFixed( OptReal( StrReplace( CONTEXT.GetOptProperty( elem, "" ), ",", "." ), 0 ), 2 );
				else if( StrBegins( elem, "pole_" ) )
					requestDoc.TopElem.workflow_fields.ObtainChildByKey( StrReplace( elem, "pole_", "" ) ).value = CONTEXT.GetOptProperty( elem, "" );
			add_workflow( requestDoc.TopElem, requestDoc.TopElem.workflow_state, "reject" );
			requestDoc.TopElem.workflow_state = "draft";
			requestDoc.TopElem.workflow_state_name = requestDoc.TopElem.get_workflow_state_name( workflowDoc );
			if( requestDoc.TopElem.person_id != curUserID )
				tools.create_notification( "rb_hire_rosbank_hire_reject_request", requestDoc.TopElem.person_id, curUser.fullname, requestDoc.DocID, null, requestDoc.TopElem );
			
			requestDoc.TopElem.doc_info.creation.app_instance_id += "," + ArrayMerge( requestDoc.TopElem.workflow_log_entrys, "This.person_id", "," );
			if( !StrContains( requestDoc.TopElem.doc_info.creation.app_instance_id, String( curUserID ) ) )
				requestDoc.TopElem.doc_info.creation.app_instance_id += "," + curUserID;
			try
			{
				log_states = new Array();
				if( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
					log_states = OpenDocFromStr( requestDoc.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
				if( ArrayOptFirstElem( log_states ) != undefined )
					requestDoc.TopElem.workflow_log_entrys.AssignElem( log_states );
				requestDoc.TopElem.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value = requestDoc.TopElem.workflow_log_entrys.Xml;
			}
			catch( err ){ alert( err ); }
			requestDoc.TopElem.workflow_log_entrys.Clear();
			requestDoc.Save();

			MESSAGE = "ALERT=������������� ���������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3;";

			break;
		case "robot":
			object_id = OptInt( object_id )
			requestDoc = OpenDoc( UrlFromDocID( object_id ) );
			fldLogEntryChild = requestDoc.TopElem.workflow_log_entrys.AddChild();
			fldLogEntryChild.create_date = Date();
			requestDoc.TopElem.workflow_fields.ObtainChildByKey( fldLogEntryChild.create_date ).value = requestDoc.TopElem.workflow_fields.ObtainChildByKey( "candidate_fullname" ).value;
			fldLogEntryChild.person_id = curUserID;
			fldLogEntryChild.action_id = "robot";
			fldLogEntryChild.person_fullname = curUser.fullname;
			fldLogEntryChild.begin_state = requestDoc.TopElem.workflow_state;
			fldLogEntryChild.finish_state = requestDoc.TopElem.workflow_state;
			
			requestDoc.TopElem.workflow_fields.ObtainChildByKey( "robot" ).value = true
			requestDoc.Save();

			MESSAGE = "ALERT=������������� ����������;OPENURL=view_doc.html?mode=rosbank_requests&tab=3;";

			break;
		case "check_grade":
			try
			{
				dPC = OpenDoc( UrlFromDocID( Int( CONTEXT.GetOptProperty( "pole_position_class_id", "" ) ) ) ).TopElem;
				if( dPC.grade.HasValue )
				{
					//dGrade = OpenDoc( UrlFromDocID( Int( dPC.grade_id ) ) ).TopElem;
					MESSAGE = "SET=pole_grade_hire_id," + dPC.grade + ";SET=GradeHire," + dPC.grade + ";SET=PositionClass," + dPC.pozi_klass;
				}
			}
			catch( ex ){ alert( "hire\remote_actions\action_hire_rosbank.js" + ex ); MESSAGE = "SET=pole_grade_hire_id,;SET=GradeHire,;SET=PositionClass,;"; }
			break;
		case "pole_staff_unit":
		case "pole_new_job_staff_id":
			res = "";
			position_name = "";
			if( OptInt( CONTEXT.GetOptProperty( action, "" ) ) != undefined )
			{
				d = OpenDoc( UrlFromDocID( OptInt( CONTEXT.GetOptProperty( action, "" ) ) ) ).TopElem;
				res = d.job_name + "(" + d.person_full_name + ", ���. � " + d.assignment_number + "), ����� " + d.grade + ", �� " + d.position_class;
				position_name = StrReplace( StrReplace( d.position_name, ",", UrlEncode( "," ) ), ";", UrlEncode( ";" ) );
			}
			MESSAGE = "SET=" + ( action == "pole_staff_unit" ? "pole_staff_unit_name," : "pole_new_job_staff_name," ) + StrReplace( StrReplace( res, ",", UrlEncode( "," ) ), ";", UrlEncode( ";" ) )  + ";SET=" + ( action == "pole_staff_unit" ? "pole_staff_unit_position_name," : "pole_new_job_staff_position_name," ) + position_name;
			break;

		case "check_percent_premium":
			if( StrReal( OptReal( CONTEXT.GetOptProperty( "pole_premium_percent", "" ), 0 ), 2 ) != CONTEXT.GetOptProperty( "pole_premium_percent", "" ) )
				MESSAGE = "SET=pole_premium_percent," + StrReal( OptReal( CONTEXT.GetOptProperty( "pole_premium_percent", "" ), 0 ), 2 ) + ";";
			break;

		case "sogl_person_id_2":
		case "sogl_person_id_3":
		case "sogl_person_id":
			MESSAGE = "";
			p_id = OptInt( CONTEXT.GetOptProperty( "Tmp" ) );
			if( p_id == undefined )
			{
				switch( action )
				{
					case "sogl_person_id":
						MESSAGE = "SET=pole_sogl_person_id,;SET=SoglCollaboratorName,;HIDE=StackPanelSoglCollab2;"
					case "sogl_person_id_2":
						MESSAGE += "SET=pole_sogl_person_id_2,;SET=SoglCollaboratorName2,;HIDE=StackPanelSoglCollab3;"
					case "sogl_person_id_3":
						MESSAGE += "SET=pole_sogl_person_id_3,;SET=SoglCollaboratorName3,;"
						break;
				}
				if( MESSAGE != "" )
					break;
			}
			switch( action )
			{
				case "sogl_person_id_3":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2" ) ) == undefined )
					{
						MESSAGE = "ALERT=���������� ������� ������� ������������ �� ������������� 2;"
						break;
					}
				case "sogl_person_id_2":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id" ) ) == undefined )
					{
						MESSAGE = "ALERT=���������� ������� ������� ������������ �� �������������;"
						break;
					}
					break;
			}
			if( MESSAGE != "" )
				break;
			
			switch( action )
			{
				case "sogl_person_id_3":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
				case "sogl_person_id_2":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
				case "sogl_person_id":
					if( OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_2" ) ) == p_id || OptInt( CONTEXT.GetOptProperty( "pole_sogl_person_id_3" ) ) == p_id )
					{
						MESSAGE = "ALERT=���� ��������� ��� ������ �����������;"
						break;
					}
					break;
			}
			if( MESSAGE != "" )
				break;
				
			teUser = OpenDoc( UrlFromDocID( p_id ) ).TopElem;
			switch( action )
			{
				case "sogl_person_id_3":
					MESSAGE = "SET=pole_sogl_person_id_3," + p_id + ";SET=SoglCollaboratorName3," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
				case "sogl_person_id_2":
					MESSAGE = "SHOW=StackPanelSoglCollab3;SET=pole_sogl_person_id_2," + p_id + ";SET=SoglCollaboratorName2," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
				case "sogl_person_id":
					MESSAGE = "SHOW=StackPanelSoglCollab2;SET=pole_sogl_person_id," + p_id + ";SET=SoglCollaboratorName," + teUser.fullname + ";HIDE=CheckBoxJob;"
					break;
			}
				
			break;

		case "check_digital":
			iDigitalID = OptInt( CONTEXT.GetOptProperty( "pole_digital_role_id" ) );
			if( iDigitalID != undefined )
			{
				teDigital = OpenDoc( UrlFromDocID( iDigitalID ) ).TopElem;
				
				MESSAGE = "SHOW=DigitalDesc;SET=pole_digital_desc," +  StrReplace( StrReplace( StrReplace( HtmlToPlainText(  StrReplace( StrReplace( teDigital.desc, "</p>", "$$$$" ), "<p>", "" ) ), ";", "%3B" ), ",", "%2C" ), "$$$$", "\n" )+ ";"
			}
			else
				MESSAGE = "HIDE=DigitalDesc;SET=pole_digital_desc,;"
			
			break;

	}
	//alert('MESSAGE '+MESSAGE)
}
catch( ex )
{
	alert("hire\remote_actions\action_hire_rosbank.js" + ex );
	MESSAGE = "ALERT=��������� ������ ��� ���������� ��������. ���������� � ��������������.;REFRESH;";
}