EnableLog("rb_hire_rosbank_account_task", true);
LogEvent(
	"rb_hire_rosbank_account_task",
	"������������ ����� ��� ������� �������� start"
  );

oAnswer = new Object();
oAnswer.error = 0;
oAnswer.message = "";
oAnswer.result = new Array();

try
{
	
	function get_desc( type_id, code, tmp )
	{
		switch( type_id )
		{
			case "rb_hire_001":
				return StrReplace( "��� ���������� ������� ������������� � ������ �� ������ �� ������ � {PARAM1}", "{PARAM1}", code );
			case "rb_hire_002":
				return StrReplace( "��� ���������� ����������� ������������� � ������ �� ������ �� ������ � {PARAM1}", "{PARAM1}", code );
			case "rb_hire_003":
				return StrReplace( "��� ���������� ��������������� ������������� � ������ �� ������ �� ������ � {PARAM1}", "{PARAM1}", code );
			case "rb_hire_004":
				return StrReplace( "��� ���������� ����������� ������ �� ������ � {PARAM1}", "{PARAM1}", code );
			case "rb_hire_005":
				return StrReplace( "���� ������ �� ������ � {PARAM1} ���������� �� ���������", "{PARAM1}", code );
			case "rb_hire_006":
				return StrReplace( "��� ���������� ����������� ������ �� ������� � {PARAM1}", "{PARAM1}", code );
			case "rb_hire_007":
				return StrReplace( "���� ������ �� ������� � {PARAM1} ���������� �� ���������", "{PARAM1}", code );
			case "rb_hire_008":
				return StrReplace( StrReplace( "��� ���������� ������������ �������� ����� �� ��������� {PARAM2} , ������ �� ������ � {PARAM1}", "{PARAM1}", code ), "{PARAM2}", tmp );
			case "rb_hire_009":
				return StrReplace( StrReplace( "��� ���������� ������������ �������� ����� �� ��������� {PARAM2} , ������ �� ������ � {PARAM1}", "{PARAM1}", code ), "{PARAM2}", tmp );
			case "rb_hire_010":
				return StrReplace( StrReplace( "����������, ������������ �������� ����� �� ������ ��������� ��� ������� � {PARAM1}", "{PARAM1}", code ), "{PARAM2}", tmp );
			case "rb_hire_011":
				return "�����������  ������ �� '����������' � ��� �������������";
			case "rb_hire_012":
				return StrReplace( StrReplace( "�������� ���� '���������� � ������' ��� {PARAM2}", "{PARAM1}", code ), "{PARAM2}", tmp );
			case "rb_hire_013":
				return StrReplace( StrReplace( "������������ ���������� � ������ ��� ���������� {PARAM2}", "{PARAM1}", code ), "{PARAM2}", tmp );
			case "rb_hire_014":
				return "����������, ������� ���� ������� � ��������� '���������� � ������' � ���� ��������.";
			case "rb_hire_015":
				return "����������, ������� ���� ������� � ��������� '���������� � ������'.";
			case "rb_hire_016":
				return "������� � ��������. ����������� �� WebTutor �� �������� �������� (���������� ����������� Online-������)";
			case "rb_hire_017":
				return "������� � ��������. ����������� �� WebTutor �� ������������/���������� ������ �� '����������'";
			case "rb_hire_018":
				return "������� � ��������. ����������� �� WebTutor �� ����� �������";
			case "rb_hire_019":
			case "rb_hire_020":
				return "������� � ��������. ����������� �� ������� �� ����� �������";
		}
		return "";
	}
	
	function add_task( task_id, person_id, task_type_id, url, create_date, code, tmp )
	{
		person_id = Int( person_id );
		oPerson = ArrayOptFind( arrResult, "This.id == " + person_id );
		if( oPerson == undefined )
		{
			oPerson = new Object();
			oPerson.id = person_id;
			sLogin = "";
			catPerson = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/id = " + person_id + " return $i" ) );
			if( catPerson != undefined )
				sLogin = catPerson.login.Value;
			oPerson.login = sLogin;
			oPerson.tasks = new Array();
			arrResult.push( oPerson );
		}
		//alert( task_id + " " + get_desc( task_type_id, code, tmp ) )
		oPerson.tasks.push( { task_id: task_id, type_id: task_type_id, url: String( url ), desc: get_desc( task_type_id, code, tmp ), create_date: create_date, code: code } )
	}
	function add_task_event( task_id, person_id, task_type_id, url, thema, body, create_date )
	{
		oPerson = ArrayOptFind( arrResult, "This.id == " + person_id );
		if( oPerson == undefined )
		{
			oPerson = new Object();
			oPerson.id = person_id;
			sLogin = "";
			catPerson = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/id = " + person_id + " return $i" ) );
			if( catPerson != undefined )
				sLogin = catPerson.login.Value;
			oPerson.login = sLogin;
			oPerson.tasks = new Array();
			arrResult.push( oPerson );
		}
		oPerson.tasks.push( { task_id: task_id, type_id: task_type_id, url: String( url ), subject: String( thema ), body: String( body ), desc: get_desc( task_type_id), create_date: create_date, code: "" } )
	}
	function get_value( name, doc )
	{
		if( doc.workflow_fields.GetOptChildByKey( name ) != undefined )
			return doc.workflow_fields.GetOptChildByKey( name ).value.Value;
		else if( doc.custom_elems.GetOptChildByKey( name ) != undefined )
			return doc.custom_elems.GetOptChildByKey( name ).value.Value;
		else
			return "";
	}

	sAction = "get_tasks";

	switch ( sAction )
	{
		case 'get_tasks':
			arrResult = new Array();
			
			rType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank' return $i" ) );
			aType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rosbank_hire' return $i" ) );
			tType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_transfer' return $i" ) );
			
			xarrRequests = ArraySelectAll( XQuery( "for $i in requests where $i/request_type_id = " + rType.id + " and $i/status_id = 'active' order by $i/id return $i" ) );
			/////////////////////////////////////////////////////////////////////rb_hire_001
			LogEvent("rb_hire_rosbank_account_task","rb_hire_001");
			//alert(ArrayOptFirstElem( xarrRequests ) != undefined)
			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
				resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_vacancy_with_final_candidate' ) , 'post',  Base64Encode( ArrayMerge( xarrRequests, "This.id", "," ) ) );
				//alert(resp.Body)
				for( elem in OpenDocFromStr( resp.Body ).TopElem )
					try
					{
						//alert( elem.id )
						carRequest = ArrayOptFindBySortedKey( xarrRequests, Int( elem.id ), "id" );
						
						for( cand in elem.candidates )
						{
							//alert( "for $i in requests where $i/request_type_id = " + aType.id + " and $i/object_id = " + elem.id + " and $i/status_id = 'active' return $i" )
							hir = ArrayOptFirstElem( XQuery( "for $i in requests where $i/request_type_id = " + aType.id + " and $i/object_id = " + elem.id + " and $i/status_id = 'active' return $i" ) );
							//alert(hir == undefined)
							if( hir == undefined )
							{
								teRequest = OpenDoc( UrlFromDocID( Int( elem.id ) ) ).TopElem;
								cat = ArrayOptFind( teRequest.workflow_log_entrys, "This.finish_state == 'podbor'" );
								
								add_task( elem.id, carRequest.person_id.Value, "rb_hire_001", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.id ), ( cat != undefined ? cat.create_date.Value : "" ), carRequest.code.Value );
							}
							break;
						}
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			
			/////////////////////////////////////////////////////////////////////rb_hire_002
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_002"
			  );
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + aType.id + " and $i/status_id = 'active' and $i/workflow_state = 'sogl_manager' return $i" );
			function get_sogl( te )
			{
				if( OptInt( get_value( "sogl_person_id", te ) ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id", te ) ) && ( This.begin_state == "sogl_manager" )' ) == undefined )
					return OptInt( get_value( "sogl_person_id", te ) );
				else if( OptInt( get_value( "sogl_person_id_2", te ) ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id_2", te ) ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id", te ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
					return OptInt( get_value( "sogl_person_id_2", te ) );
				else if( OptInt( get_value( "sogl_person_id_3", te ) ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id_3", te ) ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id", te ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_person_id_2", te ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
					return OptInt( get_value( "sogl_person_id_3", te ) );
				if( OptInt( get_value( "sogl_collaborator_id", te ) ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id", te ) ) && ( This.begin_state == "sogl_manager" )' ) == undefined )
					return OptInt( get_value( "sogl_collaborator_id", te ) );
				else if( OptInt( get_value( "sogl_collaborator_id_2", te ) ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id_2", te ) ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id", te ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
					return OptInt( get_value( "sogl_collaborator_id_2", te ) );
				else if( OptInt( get_value( "sogl_collaborator_id_3", te ) ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id_3", te ) ) && ( This.begin_state == "sogl_manager" )' ) == undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id", te ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined && ArrayOptFind( te.workflow_log_entrys, 'This.person_id == OptInt( get_value( "sogl_collaborator_id_2", te ) ) && ( This.begin_state == "sogl_manager" )' ) != undefined )
					return OptInt( get_value( "sogl_collaborator_id_3", te ) );
				return undefined;
			}
			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				for( elem in xarrRequests )
					try
					{
						
						teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
						iPersonID = get_sogl( teRequest );
						cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
						if( iPersonID != undefined )
							add_task( elem.id, iPersonID, "rb_hire_002", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.id ), cat.create_date.Value, elem.object_id.ForeignElem.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_003
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_003"
			);
			function is_reject( te )
			{
				log_states = new Array();
				nArr = te.workflow_log_entrys.Clone();
				if( te.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value != "" )
					log_states = OpenDocFromStr( te.workflow_fields.ObtainChildByKey( "workflow_log_entrys" ).value ).TopElem;
				if( ArrayOptFirstElem( log_states ) != undefined )
					nArr.AssignElem( log_states );
					
				catState = ArrayOptFirstElem( ArraySort( nArr, "This.create_date", "-" ) );
				return catState != undefined && ( catState.finish_state == "draft" || catState.begin_state != "draft" ) ? catState.create_date.Value : null;
			}
			
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + aType.id + " and $i/status_id = 'active' and $i/workflow_state = 'draft' return $i" );

			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				for( elem in xarrRequests )
					try
					{
						teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
						
						if( is_reject( teRequest ) != null )
							add_task( elem.id, teRequest.person_id, "rb_hire_003", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.id ), is_reject( teRequest ), elem.object_id.ForeignElem.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_004
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_004"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + rType.id + " and $i/status_id = 'active' and $i/workflow_state = 'sogl_manager' return $i" );

			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				for( elem in xarrRequests )
					try
					{

						teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
						iPersonID = get_sogl( teRequest );
						cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
						if( iPersonID != undefined )
							add_task( elem.id, iPersonID, "rb_hire_004", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.id ), cat.create_date.Value, teRequest.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_005
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_005"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + rType.id + " and $i/status_id = 'active' and $i/workflow_state = 'draft' return $i" );

			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				for( elem in xarrRequests )
					try
					{
						teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
						
						if( is_reject( teRequest ) != null )
							add_task( elem.id, teRequest.person_id, "rb_hire_005", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.id ), is_reject( teRequest ), teRequest.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_006
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_006"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + tType.id + " and $i/status_id = 'active' and $i/workflow_state = 'sogl_manager' return $i" );

			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				for( elem in xarrRequests )
					try
					{
						teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
						iPersonID = get_sogl( teRequest );
						cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
						if( iPersonID != undefined )
							add_task( elem.id, iPersonID, "rb_hire_006", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.id ), cat.create_date.Value, teRequest.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_007
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_007"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + tType.id + " and $i/status_id = 'active' and $i/workflow_state = 'draft' return $i" );

			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				for( elem in xarrRequests )
					try
					{
						teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
						
						if( is_reject( teRequest ) != null )
							add_task( elem.id, teRequest.person_id, "rb_hire_007", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_transfer_request&object_id=" + elem.id ), is_reject( teRequest ), teRequest.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_008
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_008"
			);
			resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&period=90days&event_type=event_type_1' ) , 'post' );
			if( resp.Body != "" )
			{
				//alert("test event_type_1 before OpenDocFromStr");
				arr = OpenDocFromStr( resp.Body ).TopElem;
				LogEvent(
					"rb_hire_rosbank_account_task",
					"test event_type_1 after OpenDocFromStr"
				);
				for( ev in arr )
					try
					{
						//teRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
						if(ev.PropertyExists("vacancy_id")){
							for( sogl in String( ev.persons ).split( ";" ) )
							{
								if( sogl == "" )
									continue;
								pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
								if( pers != undefined )
									add_task( ev.vacancy_id, pers.id, "rb_hire_008", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id ), ev.date.Value, ev.vacancy_code, Base64Decode( ev.candidate_fullname ) );
							}
						}
					}
					catch( err ){ LogEvent("rb_hire_rosbank_account_task",err); }
			}
			//alert("test event_type_2 before OpenDocFromStr");
			resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&period=90days&event_type=event_type_2' ) , 'post' );
			//alert("test event_type_2 after OpenDocFromStr");
			if( resp.Body != "" )
			{
				arr = OpenDocFromStr( resp.Body ).TopElem;
				for( ev in arr )
					try
					{
						//teRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
						if(ev.PropertyExists("vacancy_id")){
							for( sogl in String( ev.persons ).split( ";" ) )
							{
								if( sogl == "" )
									continue;
								pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
								if( pers != undefined )
									add_task( ev.vacancy_id, pers.id, "rb_hire_008", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id ), ev.date.Value, ev.vacancy_code, Base64Decode( ev.candidate_fullname ) );
							}
						}
					}
					catch( err ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_009
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_009"
			);
			resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&period=90days&event_type=event_type_4' ) , 'post' );
			if( resp.Body != "" )
			{
				arr = OpenDocFromStr( resp.Body ).TopElem;
				for( ev in arr )
					try
					{
						//teRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
						if(ev.PropertyExists("vacancy_id")){
							for( sogl in String( ev.persons ).split( ";" ) )
							{
								if( sogl == "" )
									continue;
								pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
								if( pers != undefined )
									add_task( ev.vacancy_id, pers.id, "rb_hire_009", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id ), ev.date.Value, ev.vacancy_code, Base64Decode( ev.candidate_fullname ) );
							}
						}
					}
					catch( err ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			/////////////////////////////////////////////////////////////////////rb_hire_010
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_010"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + rType.id + " and $i/status_id = 'close' and $i/workflow_state = 'complete' return $i" );
			if( ArrayOptFirstElem( xarrRequests ) != undefined )
			{
				carResponseType = ArrayOptFirstElem( XQuery( "for $i in response_types where $i/code = 'rosbank_vacancy' return $i" ) )
				xarrResponse = ArrayDirect( XQuery( "for $i in responses where $i/response_type_id = " + carResponseType.id + " and MatchSome( $i/object_id, ( " + ArrayMerge( xarrRequests, "This.id", "," ) + " ) ) return $i" ) );
			
				for( elem in xarrRequests )
					try
					{
						
						if( ArrayOptFind( xarrResponse, "This.object_id == elem.id" ) == undefined )
							add_task( elem.id, elem.person_id, "rb_hire_010", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=response_rosbank&object_id=" + elem.id ), elem.close_date.Value, elem.code.Value );
								
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
			}
			
			
			
			/////////////////////////////////////////////////////////////////////rb_hire_011
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_011"
			);
			oRequestType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_diver_request' return $i" ) );
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + oRequestType.id + " and $i/status_id = 'active' and ( $i/workflow_state = 'subdivision' ) return $i" );
			for( elem in xarrRequests )
				try
				{
					teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
					boss = ArrayOptFirstElem( XQuery( "for $i in positions where ( $i/position_date = null() or $i/position_date <= date( '" + Date() + "' ) ) and ( $i/position_finish_date = null() or $i/position_finish_date > date( '" + Date() + "' ) ) and  $i/is_boss = true() and $i/parent_object_id = " + elem.object_id + " return $i" ) );
					cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
					if( boss != undefined )
						add_task( elem.id, boss.basic_collaborator_id, "rb_hire_011", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_diver_request&object_id=" + elem.id ), cat.create_date.Value, teRequest.code.Value );

				}
				catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
				
				
			/////////////////////////////////////////////////////////////////////rb_hire_012
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_012"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + oRequestType.id + " and $i/status_id = 'active' and ( $i/workflow_state = 'sogl' ) return $i" );
			for( elem in xarrRequests )
				try
				{
					teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
					cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
					if( OptInt( teRequest.workflow_fields.ObtainChildByKey( "kurator_id" ).value ) != undefined && teRequest.workflow_fields.ObtainChildByKey( "diver_date" ).value == "" )
					{
						teUser = OpenDoc( UrlFromDocID( teRequest.person_id ) ).TopElem;
						add_task( elem.id, OptInt( teRequest.workflow_fields.ObtainChildByKey( "kurator_id" ).value ), "rb_hire_012", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_diver_request&object_id=" + elem.id ), cat.create_date.Value, teRequest.code.Value, teUser.fullname );
					}
				}
				catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
				
				
			/////////////////////////////////////////////////////////////////////rb_hire_013
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_013"
			);
			xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + oRequestType.id + " and $i/status_id = 'active' and ( $i/workflow_state = 'manager' ) return $i" );
			for( elem in xarrRequests )
				try
				{
					teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
					cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
					teUser = OpenDoc( UrlFromDocID( teRequest.person_id ) ).TopElem;
					add_task( elem.id, OptInt( teRequest.workflow_fields.ObtainChildByKey( "manager_id" ).value ), "rb_hire_013", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_diver_request&object_id=" + elem.id ), cat.create_date.Value, teRequest.code.Value, String( teUser.fullname ) );

				}
				catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }
				
			/////////////////////////////////////////////////////////////////////rb_hire_014 015
			LogEvent(
				"rb_hire_rosbank_account_task",
				"rb_hire_014"
			);
			/*xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + oRequestType.id + " and $i/status_id = 'active' and ( $i/workflow_state = 'sogl_and_send' ) return $i" );
			for( elem in xarrRequests )
				try
				{
					teRequest = OpenDoc( UrlFromDocID( elem.id ) ).TopElem;
					cat = teRequest.workflow_log_entrys[ ArrayCount( teRequest.workflow_log_entrys ) - 1 ];
					if( OptInt( teRequest.workflow_fields.ObtainChildByKey( "kurator_id" ).value ) != undefined )
						add_task( elem.id, OptInt( teRequest.workflow_fields.ObtainChildByKey( "kurator_id" ).value ), "rb_hire_014", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_diver_request&object_id=" + elem.id ), cat.create_date.Value );
				}
				catch( ex ){ alert( ex ); }
				*/
				
			function send_task( request_id, top_elem, diver_date )
			{
				cat = top_elem.workflow_log_entrys[ ArrayCount( top_elem.workflow_log_entrys ) - 1 ];
				if( ArrayOptFirstElem( XQuery( "for $i in responses where $i/response_type_id = " + oResponseTypeKurator.id + " and $i/object_id = " + request_id + " and $i/person_id = " + top_elem.workflow_fields.ObtainChildByKey( "kurator_id" ).value + " and doc-contains( $i/id, 'wt_data', '[diver_date=" + StrReplace( diver_date, " ", "_" ) + "]' ) return $i" ) ) == undefined )
					add_task( request_id, OptInt( top_elem.workflow_fields.ObtainChildByKey( "kurator_id" ).value ), "rb_hire_014", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_diver_request&object_id=" + request_id ), cat.create_date.Value, top_elem.code.Value );
				//alert("for $i in responses where $i/response_type_id = " + oResponseType.id + " and $i/object_id = " + request_id + " and $i/person_id = " + top_elem.person_id + " and doc-contains( $i/id, 'wt_data', '[diver_date=" + StrReplace( diver_date, " ", "_" ) + "]' ) return $i")
				if( ArrayOptFirstElem( XQuery( "for $i in responses where $i/response_type_id = " + oResponseType.id + " and $i/object_id = " + request_id + " and $i/person_id = " + top_elem.person_id + " and doc-contains( $i/id, 'wt_data', '[diver_date=" + StrReplace( diver_date, " ", "_" ) + "]' ) return $i" ) ) == undefined )
				{
					//alert( "for $i in responses where $i/response_type_id = " + oResponseType.id + " and $i/object_id = " + request_id + " and $i/person_id = " + top_elem.person_id + " and doc-contains( $i/id, 'wt_data', '[diver_date=" + StrReplace( diver_date, " ", "_" ) + "]' ) return $i" )
					add_task( request_id, top_elem.person_id, "rb_hire_015", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_rosbank_diver_request&object_id=" + request_id ), cat.create_date.Value, top_elem.code.Value );
				}
			}


			oResponseTypeKurator = ArrayOptFirstElem( XQuery( "for $i in response_types where $i/code = 'rb_hire_rosbank_diver_kurator_response' return $i" ) )
			oResponseType = ArrayOptFirstElem( XQuery( "for $i in response_types where $i/code = 'rb_hire_rosbank_diver_response' return $i" ) )
			
			for( req in XQuery( "for $i in requests where $i/request_type_id = " + oRequestType.id + " and $i/workflow_state = 'sogl_and_send' return $i" ) )
					try
					{
						docRequest = OpenDoc( UrlFromDocID( req.id ) );
						dDiverDate = DateNewTime( Date( docRequest.TopElem.workflow_fields.ObtainChildByKey( "diver_date" ).value ), 0, 0, 0 )
						if( true )
							send_task( req.id, docRequest.TopElem, docRequest.TopElem.workflow_fields.ObtainChildByKey( "diver_date" ).value );
					}
					catch( ex ){ LogEvent("rb_hire_rosbank_account_task",ex ); }

			/////////////////////////////////////////////////////
			
			
			LogEvent(
				"rb_hire_rosbank_account_task",
				"notif"
			);
			for( notif in [ "rb_hire_rosbank_transfer_person_sogl", "rb_hire_mobility_candidate", "rb_hire_mobilite_create_resume", "rb_hire_mobility_reject", "rb_hire_rosbank_mobility_friends_success", "rb_hire_rosbank_mobility_friends_failed", "rb_hire_rosbank_mobility_friends_answer_recr", "rb_hire_rosbank_diver_reject", "rb_hire_rosbank_diver_sogl_subdivision", "rb_hire_rosbank_diver_sogl", "rb_hire_rosbank_diver_manager", "rb_hire_rosbank_self_denial", "rosbank_market_map", "rb_hire_rosbank_not_feedback", "rb_hire_rosbank_hire_manager", "rb_hire_rosbank_request_init", "rb_hire_rosbank_pred_init" ] )
			{
				catNotif = ArrayOptFirstElem( XQuery( "for $i in notifications where $i/code = " + XQueryLiteral( notif ) + " return $i" ) );
				if( catNotif != undefined )
				{
					xarr = XQuery( "for $i in cc_notification_for_accounts where $i/is_send != true() and $i/notification_id = " + catNotif.id + " return $i" );
						for( elem in xarr )
						try
						{
							docNotif = OpenDoc( UrlFromDocID( elem.id ) );
							switch( notif )
							{
								case "rb_hire_rosbank_self_denial":
								case "rb_hire_rosbank_not_feedback":
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_016", docNotif.TopElem.text, docNotif.TopElem.subject, "", elem.date.Value );
									break;
									
								case "rosbank_market_map":
									link = String( docNotif.TopElem.text ).split( "&&" )[ 0 ];
									link = String( link ).split( " " );
									link = link[ ArrayCount( link ) - 1 ]
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_016", link, docNotif.TopElem.subject, "", elem.date.Value );
									break;
									
								case "rb_hire_rosbank_request_init":
								case "rb_hire_rosbank_hire_manager":
								case "rb_hire_rosbank_pred_init":
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_016", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.sec_object_id ), docNotif.TopElem.subject, "", elem.date.Value );
									break;
									
								case "rb_hire_rosbank_diver_manager":
								case "rb_hire_rosbank_diver_sogl":
								case "rb_hire_rosbank_diver_sogl_subdivision":
								case "rb_hire_rosbank_diver_reject":
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_017", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.sec_object_id ), docNotif.TopElem.subject, "", elem.date.Value );
									break;
									
								case "rb_hire_rosbank_mobility_friends_answer_recr":
								case "rb_hire_rosbank_mobility_friends_failed":
								case "rb_hire_rosbank_mobility_friends_success":
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_018", "", docNotif.TopElem.subject, "", elem.date.Value );
									break;
									
								case "rb_hire_mobility_candidate":
								case "rb_hire_mobilite_create_resume":
								case "rb_hire_mobility_reject":
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_019", "", docNotif.TopElem.subject, "", elem.date.Value );
									break;

								case "rb_hire_rosbank_transfer_person_sogl":
									add_task_event( elem.active_notification_id, docNotif.TopElem.object_id, "rb_hire_020", UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=rb_hire_request&object_id=" + elem.sec_object_id ), docNotif.TopElem.subject, "", elem.date.Value );
									break;
									
							}
							docNotif.TopElem.is_send = true;
							docNotif.Save();
						}
						catch(ex){ LogEvent("rb_hire_rosbank_account_task",ex ); }
				}
			}
			sUpgradeId = tools.random_string( 10 );
			
			LogEvent(
				"rb_hire_rosbank_account_task",
				"sUpgradeId " + sUpgradeId + "\n" +
				"arrResult " + ArraySum( arrResult, "ArrayCount( This.tasks )" )
			);

			for( _user in arrResult )
			{
				
				for( _task in _user.tasks )
				{
					catTask = ArrayOptFirstElem( XQuery( "for $i in cc_rb_hire_rosbank_ac_tasks where $i/task_id = " + XQueryLiteral( String( _task.task_id ) ) + " and $i/task_type_id = '" + _task.type_id + "' and $i/is_archive = false() and $i/is_deleted = false() return $i" ) );
					if( catTask != undefined )
					{
						docTask = OpenDoc( UrlFromDocID( catTask.id ) );
					}
					else
					{
						docTask = tools.new_doc_by_name( "cc_rb_hire_rosbank_ac_task" );
						docTask.BindToDb( DefaultDb );
					}
					bUpgrade = false;
					teTask = docTask.TopElem;
					teTask.user_id = _user.id;
					teTask.code = _task.code;
					teTask.is_archive = false;
					teTask.is_deleted = false;
					teTask.task_id = _task.task_id;
										
					if( teTask.user_id != _user.id || teTask.task_type_id != _task.type_id || teTask.url != _task.url || teTask.subject != _task.GetOptProperty( "subject", "" ) || teTask.body != _task.GetOptProperty( "body", "" ) || teTask.desc != _task.desc || teTask.create_date != _task.create_date || ( teTask.upgrade_date.HasValue && teTask.upgrade_date < _task.create_date ) )
					{
						bUpgrade = true;
						teTask.is_sended = false;
						teTask.upgrade_date = Date();
					}
					
					teTask.login = _user.login;
					teTask.desc = _task.GetOptProperty( "desc", "" );
					teTask.task_type_id = _task.type_id;
					teTask.url = _task.url;
					teTask.subject = _task.GetOptProperty( "subject", "" );
					teTask.body = _task.GetOptProperty( "body", "" );
					teTask.create_date = _task.create_date;
					teTask.upgrade_id = sUpgradeId;
					docTask.Save();
				}
			}

			xarr = XQuery( "for $i in cc_rb_hire_rosbank_ac_tasks where $i/upgrade_id != " + XQueryLiteral( sUpgradeId ) + " and $i/is_archive = false() and $i/is_deleted = false() return $i" );
			LogEvent(
				"rb_hire_rosbank_account_task",
				"arrResult finish \n" + 
				"for $i in cc_rb_hire_rosbank_ac_tasks where $i/upgrade_id != " + XQueryLiteral( sUpgradeId ) + " and $i/is_archive = false() and $i/is_deleted = false() return $i \n" +
				"deleted " + ArrayCount( xarr )
			);
			for( _task in xarr )
			{
				docTask = OpenDoc( UrlFromDocID( _task.id ) );
				docTask.TopElem.is_deleted = true;
				docTask.Save();
			}
			
			break;
	}

}
catch( ex )
{
	LogEvent("rb_hire_rosbank_account_task",ex );
}	

LogEvent(
	"rb_hire_rosbank_account_task",
	"������������ ����� ��� ������� �������� finish"
);
EnableLog("rb_hire_rosbank_account_task", false);