alert( "�������� ����������� �� �������� Estaff. start" );

function send_notification_group( type, notif, buf, cand )
{
	gr = ArrayOptFirstElem( XQuery( "for $i in groups where $i/code = '" + type + "' return $i" ) );
	if( gr == undefined )
		return false;
	teGroup = OpenDoc( UrlFromDocID( gr.id ) ).TopElem;
	t_send = teGroup.custom_elems.ObtainChildByKey( "type_send" ).value;
	if( StrContains( t_send, "�� ����� �����" ) )
		tools.create_notification( notif + "_group", gr.id, cand, ev.vacancy_id, teGroup, dRequest );
	if( StrContains( t_send, "������� ���������� ������" ) )
		for( elem in XQuery( "for $i in group_collaborators where $i/group_id = " + gr.id + " return $i" ) )
			if( !buf || elem.collaborator_id != dRequest.person_id )
				tools.create_notification( notif, elem.collaborator_id, cand, ev.vacancy_id, null, dRequest );
}

_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
//alert("_url "+_url)
arr_events = new Array( 'event_type_1', 'event_type_2', 'event_type_3', 'event_type_5', 'rosbank_market_map' );
for( elem in arr_events )
	try
	{
		resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&event_type=' + elem ) , 'post' );
		if( resp.Body != "" )
		{
			arr = OpenDocFromStr( resp.Body ).TopElem;
			for( ev in arr )
				try
				{
					dRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
					link = "��������� �������: " + Base64Decode( ev.name ) + "
********************************
����� �����������, �������� �� ������ " + "
" + UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id ) + "&&��� ���������� ������������ �������� ����� �� ��������� " + Base64Decode( ev.candidate_fullname )
					//tools.create_notification( "rosbank_event_12", dRequest.person_id , link, ev.vacancy_id, null, dRequest );
					for( sogl in String( ev.persons ).split( ";" ) )
					{
						if( sogl == "" )
							continue;
						pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
						if( pers != undefined )
							tools.create_notification( "rb_hire_rosbank_event_12", pers.id , link, ev.vacancy_id, null, dRequest );
					}
					//	if( dRequest.person_id != sogl.person_id )
					//		tools.create_notification( "rosbank_event_12", sogl.person_id , link, ev.vacancy_id, null, dRequest );
				}
				catch( err ){ alert( "�������� ����������� �� �������� Estaff. " + err ); }
		}
		
	}
	catch( ex)
	{
		alert( "�������� ����������� �� �������� Estaff. " + ex );
	}
/*
arr_events = new Array(  'event_type_6' );
for( elem in arr_events )
	try
	{
		alert(elem)
		resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&event_type=' + elem ) , 'post' );
		if( resp.Body != "" )
		{
			alert(resp.Body)
			arr = OpenDocFromStr( resp.Body ).TopElem;
			for( ev in arr )
				try
				{
					
					try
					{
						docRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
						dRequest = docRequest.TopElem;
						if( elem == "event_type_6" && dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value != ev.hub_id )
						{
							dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value = ev.hub_id;
							docRequest.Save();
						}
					}
					catch( ex )
					{
						dRequest = OpenNewDoc( "x-local://wtv/wtv_request.xmd" ).TopElem;
						respt = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_vacancy_data&vacancy_id=' + ev.vacancy_id ) , 'post', '' );
						dTVac = OpenDocFromStr( respt.Body ).TopElem;
						dRequest.code = dTVac.code;
						dRequest.create_date = dTVac.date;
						dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value = dTVac.hub_id;
						dRequest.workflow_fields.ObtainChildByKey( "new_job" ).value = "true";
						dRequest.workflow_fields.ObtainChildByKey( "job_name" ).value = DecodeCharset( Base64Decode( dTVac.job_name ), "windows-1251" ) ;
						dRequest.workflow_fields.ObtainChildByKey( "new_subdivision" ).value = "true";
						dRequest.workflow_fields.ObtainChildByKey( "subdivision_name" ).value = DecodeCharset( Base64Decode( dTVac.sub_staff_name ), "windows-1251" ) ;
						dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value = ev.hub_id;
					}
					recr = undefined;
					if( ev.recr != "" )
						recr = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + ev.recr + "' return $i" ) )
					dRequest.workflow_fields.ObtainChildByKey( "recr" ).value = ev.recr_fullname + ( recr != undefined ? ", " + recr.email : "" );
					link = UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id )  + "&&" + Base64Decode( ev.candidate_fullname ) + "&&" + ev.id + "&&" + ev.is_urgent
					/*for( sogl in String( ev.persons ).split( ";" ) )
					{
						if( sogl == "" )
							continue;
						pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
						if( pers != undefined )
							tools.create_notification( "rosbank_sb_event_15", pers.id , link, ev.vacancy_id, null, dRequest );
					}*/
/*
					if( elem == "event_type_6" )
						send_notification_group( "sb_" + ev.hub_id, "rb_hire_rosbank_sb_event_15", false, link )
					else
					{
						//send_notification_group( 'go_sb', "rb_hire_rosbank_sb_go_event_15", false, link )
						send_notification_group( 'sb_go', "rb_hire_rosbank_sb_go_event_15", false, link )
					}
				}
				catch( err ){ alert( "�������� ����������� �� �������� Estaff 0. " + err ); }
		}
		
	}
	catch( ex)
	{
		alert( "�������� ����������� �� �������� Estaff. " + ex );
	}
*/
arr_events = new Array(  'rb_event_type_7' );
for( elem in arr_events )
	try
	{
		rType = ArrayOptFirstElem(XQuery( "for $i in request_types where $i/code = 'rosbank_job_offer' return $i" ));
		resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&event_type=' + elem ) , 'post' );
		if( resp.Body != "" )
		{
			arr = OpenDocFromStr( resp.Body ).TopElem;
			for( ev in arr )
				try
				{
					teRequest = null;
					clReq = ArrayOptFirstElem( XQuery( "for $i in requests where $i/object_id = " + ev.id + " and $i/request_type_id = " + rType.id + " return $i" ) );
					if( clReq != undefined )
						teRequest = OpenDoc( UrlFromDocID( clReq.id ) ).TopElem;
					dRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
					link = UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id )  + "&&" + Base64Decode( ev.candidate_fullname )
					/*for( sogl in String( ev.persons ).split( ";" ) )
					{
						if( sogl == "" )
							continue;
						pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
						if( pers != undefined )
							tools.create_notification( "rosbank_sb_event_15", pers.id , link, ev.vacancy_id, null, dRequest );
					}*/
					if( teRequest == null || !tools_web.is_true( teRequest.custom_elems.ObtainChildByKey( String( dRequest.person_id ) ).value ) )
					{
						tools.create_notification( "rb_hire_rosbank_event_12", dRequest.person_id, "��������� ����� ������� " + Base64Decode( ev.name ) + "
����� �����������, �������� �� ������ " + "
" + link, ev.vacancy_id, null, dRequest );
					}
					if( teRequest == null || !tools_web.is_true( teRequest.custom_elems.ObtainChildByKey( "hr" ).value ) )
					{
						send_notification_group( "hr_" + dRequest.workflow_fields.GetOptChildByKey( "hub_id" ).value , "rb_hire_rosbank_hr_event_17", true, link )
						//if( elem.collaborator_id != dRequest.person_id )
						//	tools.create_notification( "rosbank_hr_event_17", elem.collaborator_id, link, ev.vacancy_id, null, dRequest );
					}
				}
				catch( err ){ alert( "�������� ����������� �� �������� Estaff. " + err ); }
		}
		
	}
	catch( ex)
	{
		alert( "�������� ����������� �� �������� Estaff. " + ex );
	}

arr_events = new Array(  'event_rosbank_go_sb' );
for( elem in arr_events )
	try
	{
		resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&event_type=' + elem ) , 'post' );
		if( resp.Body != "" )
		{
			arr = OpenDocFromStr( resp.Body ).TopElem;
			for( ev in arr )
				try
				{
					try
					{
						dRequest = OpenDoc( UrlFromDocID( Int( ev.vacancy_id ) ) ).TopElem;
					}
					catch( ex )
					{
						dRequest = OpenNewDoc( "x-local://wtv/wtv_request.xmd" ).TopElem;
						respt = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_vacancy_data&vacancy_id=' + ev.vacancy_id ) , 'post', '' );
						dTVac = OpenDocFromStr( respt.Body ).TopElem;
						dRequest.code = dTVac.code;
						dRequest.create_date = dTVac.date;
						dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value = dTVac.hub_id;
						dRequest.workflow_fields.ObtainChildByKey( "new_job" ).value = "true";
						dRequest.workflow_fields.ObtainChildByKey( "job_name" ).value = DecodeCharset( Base64Decode( dTVac.job_name ), "windows-1251" ) ;
						dRequest.workflow_fields.ObtainChildByKey( "new_subdivision" ).value = "true";
						dRequest.workflow_fields.ObtainChildByKey( "subdivision_name" ).value = DecodeCharset( Base64Decode( dTVac.sub_staff_name ), "windows-1251" ) ;
						dRequest.workflow_fields.ObtainChildByKey( "hub_id" ).value = ev.hub_id;
					}
					link = UrlAppendPath( global_settings.settings.portal_base_url, "/view_doc.html?mode=event_estaff_rosbank&event_eid=" + ev.id + "&vacancy_id=" + ev.vacancy_id )  + "&&" + Base64Decode( ev.region + ev.candidate_fullname )
					/*for( sogl in String( ev.persons ).split( ";" ) )
					{
						if( sogl == "" )
							continue;
						pers = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + sogl + "' return $i" ) );
						if( pers != undefined )
							tools.create_notification( "rosbank_sb_event_15", pers.id , link, ev.vacancy_id, null, dRequest );
					}*/
					send_notification_group( "go_sb", "rb_hire_rosbank_go_sb_event_15", false, link )
					/*for( elem in XQuery( "for $i in group_collaborators where $i/code = 'go_sb' return $i" ) )
						tools.create_notification( "rosbank_go_sb_event_15", elem.collaborator_id, link, ev.vacancy_id, null, dRequest );*/
				}
				catch( err ){ alert( "�������� ����������� �� �������� Estaff 1. " + err ); }
		}
		
	}
	catch( ex)
	{
		alert( "�������� ����������� �� �������� Estaff. " + ex );
	}

arr_events = new Array(  'rosbank_friends' );
for( elem in arr_events )
	try
	{
		//alert( elem )
		resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_new_events&event_type=' + elem ) , 'post' );
		//alert( "resp.Body " + resp.Body )
		if( resp.Body != "" )
		{
			arr = OpenDocFromStr( resp.Body ).TopElem;
			for( ev in arr )
				try
				{
					if( ev.vacancy_recr != "" )
					{
						collab = ArrayOptFirstElem( XQuery( "for $i in collaborators where $i/code = '" + ev.vacancy_recr  + "' return $i" ) );
						if( collab != undefined )
							tools.create_notification( "rb_hire_rosbank_mobility_friends_send_recr", collab.id, ev.vacancy_id + "$$" + Base64Decode( ev.candidate_fullname ) )
					}
					
				}
				catch( err ){ alert( "�������� ����������� �� �������� Estaff. " + err ); }
		}
		
	}
	catch( ex)
	{
		alert( "�������� ����������� �� �������� Estaff. " + ex );
	}

alert( "�������� ����������� �� �������� Estaff. finish" );