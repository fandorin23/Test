//�������� ������ �� �������

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable indent */
//@ts-check
alert( "�������� ������ �� ������ start" );

function send_notification_pers( type, requestDoc )
{
	var cond;
	if( type == "staff" )
		cond = " $i/code = 'staff_go' "
	else if( type == "im" )
		cond = " $i/code = 'international_mobility' "
	else if( ( type == "svhr" || type == "hr" ) && requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
		cond = " $i/code = 'hr_go_net' "
	else if( ( type == "svhr" || type == "hr" ) && ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
		cond = " $i/code = 'hr_go' "
	else if( type == "job_hr"  )
	{
		if( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) != undefined &&  requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "net" )
			cond = " $i/code = 'hr_go_net' "
		else if( ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ) == undefined || requestDoc.TopElem.workflow_fields.GetOptChildByKey( "podbor_for" ).value == "go" ) )
			cond = " $i/code = 'hr_go' "
		type = "job"
	}
	else if( type == "job_ukil"  )
	{
		cond = " $i/code = 'ukil_go' ";
		type = "job"
	}
	else if( type == "ukil"  )
	{
		cond = " $i/code = 'ukil_go' ";
	}
	else
		cond = " $i/code = '" + ( type == "svhr" ? "hr" : type ) + "_" + ( requestDoc.TopElem.workflow_fields.GetOptChildByKey( "hub_id" ).value ) + "' ";
    var arr = XQuery( "for $i in group_collaborators where " + cond + " return $i" );
    var teGroup;
    var t_send;
    var gr={};
	for( gr in ArraySelectDistinct( arr, "This.group_id" ) )
	{
		teGroup = OpenDoc( UrlFromDocID( gr.group_id ) ).TopElem;
		t_send = String(teGroup.custom_elems.ObtainChildByKey( "type_send" ).value);
		if( StrContains( t_send, "�� ����� �����" ) )
			tools.create_notification( "rb_hire_rosbank_transfer_complete_group", gr.group_id, "", requestDoc.DocID, teGroup, requestDoc.TopElem );
		if( StrContains( t_send, "������� ���������� ������" ) )
			for( elem in ArraySelect( arr, "This.group_id == gr.group_id" ) )
				tools.create_notification( "rb_hire_rosbank_transfer_complete" , elem.collaborator_id, "", requestDoc.DocID, null, requestDoc.TopElem );
	}
	
}

function add_workflow( obj, st, fin )
{
	var fldLogEntryChild = obj.workflow_log_entrys.AddChild();
	fldLogEntryChild.create_date = Date();
	fldLogEntryChild.person_id = "";
	fldLogEntryChild.person_fullname = "";
	fldLogEntryChild.begin_state = st;
	fldLogEntryChild.finish_state = fin;
}

alert( "�������� ������ �� ������� start" );

var rType = ArrayOptFirstElem( XQuery( "for $i in request_types where $i/code = 'rb_hire_rosbank_transfer' return $i" ) );

var xarrRequests = XQuery( "for $i in requests where $i/request_type_id = " + rType.id + " and $i/workflow_state = 'in_job' return $i" );
var workflowDoc = OpenDoc( UrlFromDocID( ArrayOptFirstElem( xarrRequests ).workflow_id ) ).TopElem
var lDate = DateOffset( DateNewTime( Date() ), 0);
var elem = {};
var lState;
var req;
for( elem in xarrRequests )
	try
	{
		req = OpenDoc( UrlFromDocID( Int( elem.id ) ) );
		try
		{
			if( lDate < Date( req.TopElem.workflow_fields.ObtainChildByKey( "transfer_date" ).value ) ){
			alert("rb_hire_rosbank_transfer_close " +  lDate + " > " + Date( req.TopElem.workflow_fields.ObtainChildByKey( "transfer_date" ).value ));
			continue;}				
		}
		catch( err )
		{
			alert("rb_hire_rosbank_transfer_close " + err );
			continue;
		}
		req.TopElem.status_id = "close";
		lState = req.TopElem.workflow_state.Value;
		req.TopElem.workflow_state = "complete";
		add_workflow( req.TopElem, lState, req.TopElem.workflow_state )
		req.TopElem.close_date = Date();
		req.TopElem.workflow_state_name = req.TopElem.get_workflow_state_name( workflowDoc );
		req.Save();
		tools.create_notification( "rb_hire_rosbank_transfer_complete" , req.TopElem.person_id, "", req.DocID, null, req.TopElem );
		if( OptInt( String(req.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value) ) != undefined ){
			tools.create_notification( "rb_hire_rosbank_transfer_complete" , OptInt( String(req.TopElem.workflow_fields.ObtainChildByKey( "sogl_collaborator_id" ).value) ), "", Int(req.DocID), null, req.TopElem );
		}
		//send_notification_pers( "hr", req )
		if( req.TopElem.workflow_fields.ObtainChildByKey( "type_transfer" ).value == "with"){
			send_notification_pers( "ukil", req );
		}
	}
	catch( ex)
	{
		alert( "�������� ������ �� ������� " + ex );
	}

alert( "�������� ������ �� ������� finish" );