//�������� ��������
/*
param:
download_all_vacancy: bool
*/

alert( "�������� �������� start" );

download_all_vacancy = tools_web.is_true( Param.download_all_vacancy )
_url = ( StrBegins( global_settings.settings.recruitment.estaff_server_url, 'http://' ) || StrBegins( global_settings.settings.recruitment.estaff_server_url, 'https://' ) ? global_settings.settings.recruitment.estaff_server_url : "http://" + global_settings.settings.recruitment.estaff_server_url );
eee = undefined
if( !download_all_vacancy ){
	eee = ArrayOptFirstElem( XQuery( "for $i in vacancys order by $i/edit_date descending return $i" ) );
}

resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_deleted_vacancys' ) , 'post',  ( eee != undefined ? eee.edit_date : "" ) );
for( elem in OpenDocFromStr( resp.Body ).TopElem )
	try
	{
		
		vac = ArrayOptFirstElem( XQuery( "for $i in vacancys where $i/source_id = '" + elem.id + "' return $i" ) );
		if( vac != undefined )
			DeleteDoc( UrlFromDocID( vac.id ) );
	}
	catch( err ){ alert( err ) }

resp = HttpRequest( UrlAppendPath( _url, '/rosbank_service.xml?method=get_modification_vacancys' ) , 'post',  ( eee != undefined ? eee.edit_date : "" ) );
//alert(resp.Body)
for( elem in OpenDocFromStr( resp.Body ).TopElem )
	try
	{
		docVacancy = tools.obtain_doc_by_key( "vacancy", "source_id", String( elem.id ) );

		docVacancy.TopElem.name = DecodeCharset( Base64Decode( elem.name ), "windows-1251" );
		docVacancy.TopElem.source_id = elem.id;
		docVacancy.TopElem.edit_date = elem.update_date;
		docVacancy.TopElem.pub_date = elem.creation_date;
		docVacancy.TopElem.org_name = elem.vertical;
		if( elem.city != "" )
		{
			region = ArrayOptFirstElem( XQuery( "for $i in regions where $i/name = '" + elem.city + "' return $i" ) );
			if( region == undefined )
			{
				docRegion = tools.obtain_doc_by_key( "region", "name", String( elem.city ) );
				docRegion.TopElem.name = elem.city;
				docRegion.Save();
				docVacancy.TopElem.region_id = docRegion.DocID;
			}
			else
				docVacancy.TopElem.region_id = region.id;
		}
		else
			docVacancy.TopElem.region_id.Clear();
		docVacancy.TopElem.url = elem.desc;
		docVacancy.TopElem.doc_info.creation.app_instance_id = elem.is_digital;
		docVacancy.TopElem.custom_elems.ObtainChildByKey( "friends" ).value = elem.friends;
		docVacancy.TopElem.custom_elems.ObtainChildByKey( "open" ).value = elem.open;
		docVacancy.TopElem.sub_name = elem.code;
		docVacancy.Save();
	}
	catch( err ){ alert( err ) }


alert( "�������� �������� finish" );