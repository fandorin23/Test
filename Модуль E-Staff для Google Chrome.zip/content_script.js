"use strict";

//alert( 'content_script.js' );
//alert( document.body.outerHTML );
//alert( window.location.href );

var			info;
var			selection;
var			range;
var			divElem;

info = new Object;
info.url = window.location.href;

selection = window.getSelection();
info.selHtml = selection.toString();

if ( info.selHtml != '' )
{
	range = selection.getRangeAt(0);
	divElem = document.createElement( 'div' );
	divElem.appendChild( range.cloneContents() );
	info.selHtml = divElem.innerHTML;

	info.html = '';
}
else
{
	info.html = document.body.outerHTML;
}

chrome.runtime.connect().postMessage( info );

