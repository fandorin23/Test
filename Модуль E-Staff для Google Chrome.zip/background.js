"use strict";


function OnConnect( info )
{
	var		reqObj;
	
	reqObj = new Object;
	reqObj.actionID = 'LoadResume';
	reqObj.html = info.html;
	reqObj.selHtml = info.selHtml;
	reqObj.url = info.url;

	chrome.runtime.sendNativeMessage( 'estaff', reqObj, OnNativeMessageCallback );
}


function OnNativeMessageCallback( response )
{
	if ( response == undefined )
	{
		alert( chrome.i18n.getMessage( 'unable_to_connect_to_native_host' ) + ':\r\n' + chrome.runtime.lastError.message );
		return;
	}

	//alert( response.text );
	//console.log("Received " + response);
}


chrome.runtime.onConnect.addListener(function(port) {
	var tab = port.sender.tab;

	port.onMessage.addListener( OnConnect );
});


chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.tabs.executeScript( null, {file: "content_script.js"} );
});
