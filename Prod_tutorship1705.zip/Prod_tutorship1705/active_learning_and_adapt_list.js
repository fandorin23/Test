//������ �������� ������ � ���������

/*global
catalog_name,
filters
*/

/*
	<wvars>
		<wvar>
			<name>catalog_name</name>
			<type>string</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>filters</name>
			<type>string</type>
			<position>2</position>
		</wvar>
	</wvars>
*/

var oCollectionParam = tools.wvars_to_object( TopElem.wvars );
var _query = "$elem/person_id = " + curUserID;
var adaptation_array = XQuery( "for $elem in career_reserves where " + _query + " and ($elem/status='plan' or $elem/status='active') return $elem" );
var learnings_array  = [];

if ( catalog_name != '' )
	learnings_array = XQuery( "for $elem in " + catalog_name + "s where " + _query + " return $elem" );

var custom_data_type = ArraySelectAll( XQuery( "for $elem in object_data_types where $elem/code='activation_source_learnings' return $elem" ) );
var aRes = [];

function sync_adapt_status( adaptStatus )
{
	var result;
	
	if ( adaptStatus == 'active' || adaptStatus == 'plan' )
		result = '� ��������'//1;
	else if ( adaptStatus == 'passed' )
		result = '�������';//2;
	else if ( adaptStatus == 'failed' )
		result = '�� �������';//4;
	
	return result;
	
}
function sync_adapt_status_id( adaptStatus )
{
	var result;
	
	if ( adaptStatus == 'active' || adaptStatus == 'plan' )
		result = 1;
	else if ( adaptStatus == 'passed' )
		result = 2;
	else if ( adaptStatus == 'failed' )
		result = 4;
	
	return result;
	
}

function formALobject( courseLearningElemParam )
{
	var _object_id = catalog_name == 'active_learning' ? courseLearningElemParam.course_id : courseLearningElemParam.assessment_id;
	var _teObject = tools.open_doc( _object_id ).TopElem;
	var _object_name = tools.get_disp_name_value( _teObject );
	var _url = catalog_name == 'active_learning' ? '/view_doc.html?mode=course&object_id=' : '/view_doc.html?mode=assessment&object_id=';

	var objResult = {};
	objResult.id = OptInt( courseLearningElemParam.id );
	objResult.title = String( _object_name );
	objResult.start_usage_date = OptDate( courseLearningElemParam.start_usage_date ) != undefined ? OptDate( courseLearningElemParam.start_usage_date ) : '';
	objResult.start_learning_date = OptDate( courseLearningElemParam.start_learning_date ) != undefined ? OptDate( courseLearningElemParam.start_learning_date ) : '';
	objResult.max_end_date = OptDate( courseLearningElemParam.max_end_date ) != undefined ? OptDate( courseLearningElemParam.max_end_date ) : '';
	objResult.last_usage_date = OptDate( courseLearningElemParam.modification_date ) != undefined ?  OptDate( courseLearningElemParam.modification_date ) : '';
	objResult.score = StrReal( courseLearningElemParam.score );
	objResult.state_name =  String( courseLearningElemParam.state_id.ForeignElem.name );
	objResult.state_id = OptInt( courseLearningElemParam.state_id );
	objResult.redirectUrl = String( _url + '' + _object_id );
	objResult.sort_index = OptInt( 1 );

	return objResult;
}

var _assing_source_elem;
var _obj;
var courseLearningElem;
for( courseLearningElem in learnings_array )
{	
	_assing_source_elem = [];
	if ( ArrayCount( custom_data_type ) > 0 )
	{
		_assing_source_elem = ArraySelectAll( 
			XQuery( "for $elem in object_datas where $elem/object_data_type_id=" + custom_data_type[0].id + " and $elem/object_id=" + courseLearningElem.id + " return $elem" ) 
		);
	}
	/* 		else
		//alert('data type was not found');
			
		if ( ArrayCount( _assing_source_elem ) > 0 )
		//alert('assigned with AP');
		//else
		//alert(custom_data_type[0].id); */
			
	if ( ArrayCount( _assing_source_elem ) > 0 )
	{
		continue;
	}

	try
	{
		_obj = formALobject( courseLearningElem );
		aRes.push( _obj );
	}
	catch( err )
	{
		alert( "active_learning_and_adapt_list err " + err + " course id " + courseLearningElem.id );
	}
}

//alert( "active_learning_and_adapt_list adaptation_array" + ArrayCount ( adaptation_array ) );

for( elem in adaptation_array )
{
	_typDevProg = null;

	try
	{
		_adaptDoc = tools.open_doc( elem.id );
		if ( _adaptDoc != undefined )
		{
			_typ_dev_prog = ArrayOptFind( _adaptDoc.TopElem.tasks, 'OptInt(This.typical_development_program_id) != undefined' );
			if ( _typ_dev_prog != undefined )
			{
				_typDevProg = ArrayOptFirstElem( XQuery( "for $elem in typical_development_programs where $elem/id=" + _typ_dev_prog.typical_development_program_id + " return $elem" ) );
				if ( _typDevProg != undefined )
				{
					if ( !StrContains( _typDevProg.code,'Retail_show',true ) )
						continue;
				}
			}
		}
	}
	catch( err )
	{
		//alert(err);
		continue;
	}

	if ( _typDevProg == undefined || _typDevProg == null )
	{
		continue;
	}

	_obj = {};
	_obj.id = OptInt( elem.id );
	_obj.title = String( '���� ���� �������� � ��������� - ' + _typDevProg.name );
	_obj.start_usage_date = OptDate( elem.start_date ) != undefined ? OptDate( elem.start_date ) :  '';
	_obj.start_learning_date = OptDate( elem.start_date ) != undefined ? OptDate( elem.start_date ) : '';
	_obj.max_end_date = OptDate( elem.plan_readiness_date ) != undefined ? OptDate( elem.plan_readiness_date ) : '';
	_obj.last_usage_date = OptDate( elem.modification_date ) != undefined ? OptDate( elem.modification_date ) : '';
	_obj.score = StrReal( elem.readiness_percent );
	_obj.state_name = sync_adapt_status( String( elem.status ) )//String(elem.status.ForeignElem.name);
	_obj.state_id = sync_adapt_status_id( String( elem.status ) )//String(elem.status.ForeignElem.name);
	_obj.redirectUrl = String( '/view_doc.html?mode=career_todo&object_id=' + elem.id );
	_obj.sort_index = OptInt( 0 );
	aRes.push( _obj );
	
	   
}

if ( filters != "" )
{
	var aFilters = UrlQuery( "?" + filters );
	//alert(tools.object_to_text(aFilters,'json'));
	for ( prop in aFilters )
	{
		val = aFilters.GetProperty( prop );
		//alert(prop + ': ' + val);
		if ( val != "" )
			switch( prop )
			{			
			case "search":
				aRes = ArraySelect( aRes,"StrContains(This.title,'" + String( val ) + "',true)" );
				//alert(prop + ': ' + ArrayCount(aRes)); 
				break;
			case "state_id":
				if ( OptInt( val ) != undefined )
					aRes = ArraySelect( aRes,"StrContains(This.state_id,'" + String( val ) + "',true)" );
				//alert(prop + ': ' + ArrayCount(aRes));
				break;
			}
	}
}


PAGING.MANUAL = false;
PAGING.SIZE = 7;
PAGING.TOTAL = ArrayCount( aRes );
SORT.FIELD;
RESULT = ArraySort( aRes, "This.sort_index","+", SORT.FIELD, ( ( SORT.DIRECTION == "DESC" ) ? "-" : "+" ) );

COLUMNS = 
[
	{"data": "sort_index","title":"","type":"int", "sortable": true,"hidden":true,"ghost":false},
	{"data": "id","title":"","type":"int","sortable": true,"hidden":true,"ghost":false},
	{"data": "title","title":"����������� ����","type":"link", "sortable": true,"hidden":false,"ghost":true,"width":400,"click":"OPENWINDOW={redirectUrl}"},
	{"data": "start_usage_date","title":"���� ���������","type":"date","sortable": true,"ghost":false,"width":100},
	{"data":"start_learning_date","title":"���� ������", "type":"date", "sortable": true,"ghost":false,"width":120},
	{"data":"last_usage_date","title":"���� ���������� ���������", "type":"date", "sortable": true,"ghost":false,"width":120},
	{"data": "score","title":"�����","type":"string", "sortable": false,"hidden":false,"ghost":false},
	{"data": "state_id","title":"������","type":"string", "sortable": true,"hidden":true,"ghost":false},
	{"data": "state_name","title":"������","type":"string", "sortable": true,"hidden":false,"ghost":false},

]