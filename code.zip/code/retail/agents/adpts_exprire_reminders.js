var beforeSevenDays = DateNewTime( tools.AdjustDate( Date(),7 ),0,0 );
var afterSevenDays = DateNewTime( tools.AdjustDate( Date(),-7 ),0,0 );
var monthAfter = DateNewTime( tools.AdjustDate( Date(), -30 ),0,0 );

var xarrCareerReserves = XQuery( "for $elem in career_reserves where $elem/plan_readiness_date != '' " + 
																	" and ($elem/status='active' or $elem/status='plan') return $elem" );

var arrSevenDaysBeforeCRs = ArraySelect( xarrCareerReserves, "ParseDate(This.plan_readiness_date,false,false)==ParseDate('" + ParseDate( beforeSevenDays,false,false ) + "',false,false)" );
var arrCurDayCRs = ArraySelect( xarrCareerReserves, "ParseDate(This.plan_readiness_date,false,false)==ParseDate('" + ParseDate( Date(),false,false ) + "',false,false)" );
var arrSevenDaysAfterCRs = ArraySelect( xarrCareerReserves, "ParseDate(This.plan_readiness_date,false,false)==ParseDate('" + ParseDate( afterSevenDays,false,false ) + "',false,false)" );
var arrMonthAfterCRs = ArraySelect( xarrCareerReserves, "ParseDate(This.plan_readiness_date,false,false)==ParseDate('" + ParseDate( monthAfter,false,false ) + "',false,false)" );

var boss_type = tools.get_doc_by_key( 'boss_type','code','career_reserve_rb_boss' );
//var fm_boss_type = tools.get_doc_by_key( 'boss_type','code','retail_func_manager' );

/**
 * �� ���������� ������ ���������� ���� ��������� ����� ������������ � ������� �� ��
 * @param {string} strCollTabNumParam 
 * @returns {string} ��������� ����� ������������
 */
function get_func_boss_code ( strCollTabNumParam )
{
	if ( strCollTabNumParam == undefined || Trim( strCollTabNumParam ) == "" )
	{
		throw "strCollTabNumParam is " + strCollTabNumParam;
	}
	
	var QueryStr = "sql:\
	DECLARE @person_tab_num VARCHAR(14) = '" + strCollTabNumParam + "';\
	\
	SELECt TOP 1\
	PERSON_ID,\
	ASSIGNMENT_NUMBER,\
	PRIMARY_FLAG,\
	JOB_NAME,\
	GROUP_NAME,\
	STARTDATE,\
	ENDDATE,\
	CHIEFTABN\
	FROM rb_boss_staff_managers_assignments boss_staff\
	WHERE CHIEFTABN is not null AND PRIMARY_FLAG = 'Y' AND\
	(GETDATE() BETWEEN STARTDATE and ENDDATE )\
	AND LEFT( ASSIGNMENT_NUMBER , LEN(ASSIGNMENT_NUMBER)-1 ) = @person_tab_num ;\
	";

	var query_res_obj =  ArrayOptFirstElem( XQuery( QueryStr ) );

	if( query_res_obj != undefined )
	{
		return query_res_obj.CHIEFTABN;
	} 
	else 
	{
		return;
	}
}


alert( "seven_days_before_cr_arr " + ArrayCount( arrSevenDaysBeforeCRs ) );
var cr;
var url;
for ( cr in arrSevenDaysBeforeCRs )
{
	
	url = UrlAppendPath( global_settings.settings.portal_base_url,'/view_doc.html?mode=career_todo&object_id=' + cr.id + '' );
	alert( 'before seven days: ' + cr.person_id.ForeignElem.fullname + '\n' + url );
	tools.create_notification( 'adpts_reminder_1', OptInt( cr.person_id.ForeignElem.id ), String( url ) );
}

for ( cr in arrCurDayCRs )
{
	
	url = UrlAppendPath( global_settings.settings.portal_base_url,'/view_doc.html?mode=career_todo&object_id=' + cr.id + '' );
	alert( 'cur day: ' + cr.person_id.ForeignElem.fullname + '\n' + url );
	tools.create_notification( 'adpts_reminder_2', OptInt( cr.person_id.ForeignElem.id ), String( url ) );		
}

for ( cr in arrSevenDaysAfterCRs )
{
	
	url = UrlAppendPath( global_settings.settings.portal_base_url,'/view_doc.html?mode=career_todo&object_id=' + cr.id + '' );
	alert( 'after seven days: ' + cr.person_id.ForeignElem.fullname + '\n' + url );
	tools.create_notification( 'adpts_reminder_3', OptInt( cr.person_id.ForeignElem.id ), String( url ) );		
}

function sendMailReminderToAdptBoss( crElemParam )
{
	if ( crElemParam == undefined )
	{
		throw "crElemParam is " + crElemParam;
	}

	var adaptDoc = tools.open_doc( crElemParam.id );
	if ( adaptDoc == undefined )
		throw "cant open adaptation with id: " + crElemParam.id;

	var boss_name = '';
	
	var teAdapt = adaptDoc.TopElem;
	var _curColElem = crElemParam.person_id.ForeignElem;

	var boss = ArrayOptFind( teAdapt.tutors, 'String(This.boss_type_id)==String(' + OptInt( boss_type.DocID ) + ')' );
	var persDoc = tools.open_doc( OptInt( crElemParam.person_id ) );
	
	//���� ������������ ��������� �������� �� �������, �� ���� ��������������� ��� ����������������� 
	if ( boss == undefined )
	{
		var _cur_boss_code = get_func_boss_code( _curColElem.code );
		//alert("_cur_boss_code " + tools.object_to_text(_cur_boss_code,"json"));

		if( _cur_boss_code != undefined )
		{
			var _cur_boss = ArrayOptFirstElem( XQuery( "for $elem in collaborators where $elem/code='" + _cur_boss_code + "' return $elem" ) );
			if( _cur_boss != undefined )
			{
				boss_name = _cur_boss.fullname;
				//alert('after month: ' + _curColTE.fullname + '\n'+boss_name);
				
				tools.create_notification( 'adpts_boss_reminder', _cur_boss.id, boss_name, crElemParam.person_id, '', persDoc.TopElem );
			}
		}
	}

	if ( boss != undefined )
	{
		boss_name = boss.person_fullname;
		//alert('after month: ' + _curColTE.fullname + '\n'+boss_name);
		tools.create_notification( 'adpts_boss_reminder', boss.person_id, boss_name, crElemParam.person_id,'', persDoc.TopElem );
	}
}

alert( "count month_after_cr_arr " + ArrayCount( arrMonthAfterCRs ) );
for ( cr in arrMonthAfterCRs )
{	
	if ( boss_type == undefined )
		continue;	
	
	sendMailReminderToAdptBoss( cr );
}