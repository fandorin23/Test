/* global
Param
*/
//����� ����� ���������� �������� ���������

alert( "start" );

var _code_group = 'Retail_adapt';
var debugMode = false;
var LOGNAME = 'adaptation-assignement-agent';
EnableLog( LOGNAME );
var created_new_programs_count = 0;
var canceled_programs_count = 0;
var custom_data_type_test_learning = ArrayOptFirstElem( XQuery( "for $elem in object_data_types where $elem/code='activation_source_test_learnings' return $elem" ) );
var intDismissedDaysAllowed = 90;
var xarrGroups = XQuery( 'for $elem in groups where contains($elem/code, "' + _code_group + '") and $elem/is_educ=true() return $elem' );
var _position_list = String( Param.Position_list );
var _text_message = '����� �������: ' + debugMode + " \n ";
var _admin_address = '';

/**
 * @typedef Stag
 * @property {boolean} is_old_coll
 * @property {number} APPOINT_DAYS
 * @property {string} EMPLOYEE_NUMBER
 * @property {string} JOB_NAME
 * @property {Date} MIN_DATE_START
 */

/**
 * ���� �� ���������� ������ ����������
 * @param {string} collTabNum 
 */
function getCollStagByTabNum( collTabNum )
{
	if ( collTabNum == undefined || collTabNum == null )
	{
		return;
	}

	/**
	 * @type {Stag}
	 */
	var result = ArrayOptFirstElem(
		XQuery( "sql:\
		WITH last_persons_appoint as (\
			SELECT\
			a.PERSON_ID ,\
			MAX(a.APPOINT_ID) APPOINT_ID\
			FROM rb_boss_assignments a\
			INNER JOIN (\
			SELECT\
			PERSON_ID,\
			MAX(a_DATE_START) as max_date_start\
			FROM rb_boss_assignments\
			WHERE a_DATE_END is null OR (GETDATE() BETWEEN a_DATE_START and a_DATE_END)\
			GROUP BY PERSON_ID\
			) person_app_max_date_end\
			ON person_app_max_date_end.PERSON_ID = a.PERSON_ID \
				AND person_app_max_date_end.max_date_start = a.a_DATE_START\
			GROUP BY a.PERSON_ID\
			),\
			\
			persons_app_days_diff as (\
			SELECT\
			a.PERSON_ID,\
			a.EMPLOYEE_NUMBER,\
			a.LAST_NAME + ' ' + a.FIRST_NAME + ' ' + a.MIDDLE_NAMES  as p_fullname,\
			a.APPOINT_ID,\
			a.JOB_NAME,\
			a.A_DATE_START,\
			A.A_DATE_END,\
			LEAD(A.A_DATE_END,1,null)  OVER (PARTITION BY a.person_id ORDER BY A_DATE_START DESC) AS prev_A_DATE_END,\
			\
			(CASE \
				WHEN DATEDIFF ( DAY ,  LEAD(A.A_DATE_END,1,null)  OVER (PARTITION BY a.person_id ORDER BY A_DATE_START DESC), a.A_DATE_START ) > 3\
				THEN a.A_DATE_START\
				ELSE NULL\
				END) as A_DATE_START_3,\
			\
			DATEDIFF ( DAY ,  LEAD(A.A_DATE_END,1,null)  OVER (PARTITION BY a.person_id ORDER BY A_DATE_START DESC), a.A_DATE_START )   as DAYS_DIFF\
			\
			FROM  rb_boss_assignments a\
			INNER JOIN last_persons_appoint la \
				ON la.PERSON_ID = a.PERSON_ID\
				AND la.APPOINT_ID = a.APPOINT_ID\
			),\
			\
			persons_app as(\
			SELECT \
			PERSON_ID,\
			APPOINT_ID,\
			MAX(EMPLOYEE_NUMBER) as EMPLOYEE_NUMBER,\
			MAX(p_fullname) as p_fullname,\
			MAX(JOB_NAME) as JOB_NAME,\
			(CASE\
				WHEN MAX(DAYS_DIFF) > 3\
				THEN MAX(A_DATE_START_3)\
				ELSE MIN(A_DATE_START)\
			END) as MIN_DATE_START,\
			\
			(CASE\
				WHEN MAX(CASE WHEN A_DATE_END IS NULL THEN 1 ELSE 0 END) = 1 OR MAX(A_DATE_END) > '2099-12-01'\
				THEN GETDATE()\
				ELSE MAX(A_DATE_END)\
			END) as MAX_DATE_END\
			\
			FROM persons_app_days_diff pdf\
			\
			GROUP BY PERSON_ID, APPOINT_ID\
			),\
			\
			old_colls as (\
			SELECT \
			PERSON_ID,\
			--MAX(EMPLOYEE_NUMBER) as EMPLOYEE_NUMBER,\
			Max(A_DATE_START) as  MAX_A_DATE_START,\
			MIN(P_DATE_START) as MIN_P_DATE_START,\
			(case when DATEADD(DAY, 5, MIN(P_DATE_START))  <= Max(A_DATE_START) then 1 else 0 end) is_old_coll\
			FROM rb_boss_assignments\
			WHERE (TECH_FIRE_FLAG is null OR TECH_FIRE_FLAG != 'Y')\
			GROUP BY PERSON_ID\
			)\
			\
			SELECT\
			persons_app.*,\
			DATEDIFF ( DAY ,MIN_DATE_START, ( case when MAX_DATE_END > MIN_DATE_START then MAX_DATE_END else GETDATE() end ) ) as APPOINT_DAYS,\
			old_colls.is_old_coll\
			FROM persons_app\
			LEFT JOIN old_colls ON old_colls.PERSON_ID = persons_app.PERSON_ID\
			\
			WHERE EMPLOYEE_NUMBER = '" + collTabNum + "'\
			order by DATEDIFF ( DAY ,MIN_DATE_START, MAX_DATE_END) asc\
		" )
		
	);

	return result;
}

/**
 * ������� �� ���������� ���-�� ���� ����� ����������� � ��������� �������
 * @param {any} colElemParam ���������� 
 */
function getCollFireDays( colElemParam )
{
	if( OptInt( colElemParam == undefined ) )
	{
		return ;
	}

	var defaultRez;

	if( _colElem.is_candidate == true )
	{
		return defaultRez = {
			EMPLOYEE_NUMBER: "",
			last_DATE_START : Date(),
			DATE_FIRE: Date(),
			DAYS_FIRE: 0
		};
	}
	else
	{
		defaultRez = null;
	}

	var xarrRez = defaultRez;
	xarrRez = ArrayOptFirstElem(
		XQuery( "sql:\
		DECLARE @coll_code AS varchar(20) = '" +  colElemParam.code + "';\
		SELECT\
		ass.EMPLOYEE_NUMBER,\
		ass_current.*,\
		ass.P_DATE_START as last_DATE_START,\
		ass.P_DATE_END,\
		fire.max_P_DATE_END as DATE_FIRE,\
		DATEDIFF ( DAY , ass_current.max_A_DATE_START , fire.max_P_DATE_END) as DAYS_FIRE\
		FROM (\
			SELECT\
			PERSON_ID,\
			MAX(A_DATE_START) max_A_DATE_START\
			FROM rb_boss_assignments\
			WHERE P_DATE_END is null OR (GETDATE() BETWEEN A_DATE_START and P_DATE_END)\
			GROUP BY PERSON_ID\
		) ass_current\
		\
		LEFT JOIN rb_boss_assignments ass \
			ON ass.PERSON_ID = ass_current.PERSON_ID\
			AND ass_current.max_A_DATE_START = ass.A_DATE_START\
		\
		LEFT JOIN (\
			SELECT\
			ass.PERSON_ID,\
			MAX(ass.P_DATE_START) max_P_DATE_START,\
			MAX(ass.P_DATE_END) max_P_DATE_END\
			FROM rb_boss_assignments ass\
			WHERE ass.TECH_FIRE_FLAG = 'N'\
			GROUP BY ass.PERSON_ID \
		) fire ON fire.PERSON_ID = ass_current.PERSON_ID\
		\
		WHERE ass.EMPLOYEE_NUMBER = @coll_code\
	" )
	);

	if ( xarrRez == undefined || xarrRez == null )
	{
		throw "cant find getCollFireDays for col:" + colElemParam.id ;
	}

	return xarrRez;
}


// ������� �������� �����. ��������� ��� ������.
/*ifunction send_alert(msg, _txt_msg) 
{
	_txt_msg += msg + " \n ";
	f (debugMode==true)
		LogEvent(LOGNAME,msg);
	if (!LdsIsServer)
		alert('adaptation-assignement-agent:\n' + msg);
}*/


//������� �� ������ ������������� �������������. ��������� ������ �� ��������.
function find_parent( _elem )
{
	var _temp = undefined;
	var _bool_temp = OptInt( _elem.TopElem.parent_object_id );
	if( _bool_temp != undefined )
	{
		var parentDoc = tools.open_doc( _elem.TopElem.parent_object_id );
		if( parentDoc != undefined )
		{
			_temp = find_parent( parentDoc );
		}
		else alert( '������ � ������� find_parent. �� ������ ������ � id ' + _elem.TopElem.parent_object_id );
	}
	else _temp = _elem;
	return _temp;
}

/**
 * ������� �������� ��������� ���������.
 * @param {*} personElemParam  ���������
 * @param {XmlDoc} docTypicalDevProgramParam doc ������� ���������
 * @param {XmlElem} groupTEparam  TopElem ������� ������
 * @param {*} arrAllPersonTasksFromAllCRsParam ������ �� ������ �����
 * @param {boolean} ignore_passed_tasks_flag ����
 * @param {string} _pos_list ������ ���������� �� ����������
 * @returns 
 */
function createAdaptation( personElemParam, docTypicalDevProgramParam, groupTEparam, arrAllPersonTasksFromAllCRsParam, ignore_passed_tasks_flag, _pos_list )
{
	if ( personElemParam == undefined || personElemParam == null )
	{
		throw "error personElemParam is undefined";
	}

	if ( docTypicalDevProgramParam == undefined )
	{
		throw "error docTypicalDevProgramParam is undefined";
	}

	//alert( personElemParam.fullname + " ��������:" + personElemParam.is_candidate );

	var teTypicalDevProgramParam = docTypicalDevProgramParam.TopElem;
	var intPersonPositionExpDays = getPersonPositionExpDays( personElemParam );

	if ( OptInt( intPersonPositionExpDays ) == undefined )
	{
		throw "error getPersonPositionExpDays not defined for col : " + personElemParam.fullname ;
	}
	
	var intExperienceDaysInPostionForTDprogramStart = teTypicalDevProgramParam.custom_elems.ObtainChildByKey( 'experience' ).value;
	
	if( OptInt( intPersonPositionExpDays ) <= OptInt( intExperienceDaysInPostionForTDprogramStart ) && personElemParam.is_candidate == false )
	{
		throw "info � ���������� : " + personElemParam.fullname + " ( ���� " + intPersonPositionExpDays + ") "  + 
		" ������������ ����� ��� ��������� " + teTypicalDevProgramParam.name + " ���� ������ ���� ������:" + intExperienceDaysInPostionForTDprogramStart;
	}

	var newCRdoc = tools.new_doc_by_name( "career_reserve" );
	newCRdoc.BindToDb( DefaultDb );
	newCRdoc.TopElem.status = 'plan';
	newCRdoc.TopElem.code = 'adpt_new';
	newCRdoc.TopElem.person_id = personElemParam.id;
	newCRdoc.TopElem.position_type = "adaptation";
	newCRdoc.TopElem.start_date = Date();

	if ( ArrayCount( teTypicalDevProgramParam.tasks ) > 0 )
	{
		newCRdoc.TopElem.plan_readiness_date = tools.AdjustDate( Date(), OptInt( ArrayMax( teTypicalDevProgramParam.tasks, "OptInt(This.due_date,0)" ).due_date, 0 ) );
	}

	debugMode == false && newCRdoc.Save();

	var _task;
	var _my_task_id;
	for ( _task in teTypicalDevProgramParam.tasks ) 
	{
		try
		{
			_my_task_id = customSetTask( _task, docTypicalDevProgramParam.DocID , newCRdoc, arrAllPersonTasksFromAllCRsParam, ignore_passed_tasks_flag ); 
		}
		catch ( error )
		{
			alert( "custom_set_task error: " + error );
			continue;
		}
	}

	newCRdoc.TopElem.status = 'active';
	newCRdoc.TopElem.custom_elems.ObtainChildByKey( 'group_id' ).value = groupTEparam.id;
	newCRdoc.TopElem.custom_elems.ObtainChildByKey( 'is_reassigned' ).value = ignore_passed_tasks_flag;
	debugMode == false && newCRdoc.Save();

	created_new_programs_count += 1;

	_text_message += " \n " + '��� ���������� ' +  newCRdoc.TopElem.person_id.ForeignElem.fullname + 
						' ���� ������� ����� ��������� ��������� �� ������� ��������� �������� ' + teTypicalDevProgramParam.name ;
	
	var _min_exp = groupTEparam.typical_development_programs[0];
	var _groupTDP;
	var _groupTdpDoc;
	var _min_expDoc;
	for( _groupTDP in groupTEparam.typical_development_programs )
	{
		_groupTdpDoc = tools.open_doc( _groupTDP.typical_development_program_id );
		_min_expDoc = tools.open_doc( _min_exp.typical_development_program_id );
		if( _groupTdpDoc != undefined && _min_expDoc != undefined )
		{
			if( _groupTdpDoc.TopElem.custom_elems.ObtainChildByKey( 'experience' ).value < _min_expDoc.TopElem.custom_elems.ObtainChildByKey( 'experience' ).value )
				_min_exp = _groupTDP;
		}
		else alert( "Error adpts_new_assign: Can't open XmlElem of Typical Development Program in CreateProgram function" );
	}

	if( docTypicalDevProgramParam.DocID == _min_exp.typical_development_program_id &&
		personElemParam != undefined &&
			StrContains( _pos_list, personElemParam.position_name )
	)
	{
		var _pos_parentDoc = tools.open_doc( personElemParam.position_parent_id );
		if( _pos_parentDoc != undefined )
		{
			var _cur_col_sub = find_parent( _pos_parentDoc );
			var arrManagers = _cur_col_sub.TopElem.func_managers;
			var _mngr;
			for( _mngr in arrManagers )
			{
				if( _mngr.boss_type_id == 6214049291357596003 )
				{
					debugMode == false && tools.create_notification( 'adapt_new_trainee', OptInt( _mngr.person_id ), '', OptInt( newCRdoc.DocID ) );
				}
			}
		}
	}

	debugMode == false && tools.create_notification( 'adpts_new_collaborator', personElemParam.id, '', OptInt( newCRdoc.DocID ) );
	return newCRdoc;
}

function customSetTaskLearning( _task, _pdoc, newTaskParam, personId ,ignore_passed_tasks_flag )
{
	var _course_learning;
	var _temp_task = ArrayOptFirstElem(
		XQuery( "for $ctask in learnings where $ctask/person_id=" + personId + 
						" and $ctask/course_id=" + String( _task.object_id ) + " order by $ctask/start_usage_date descending return $ctask" ) 
	);

	var custom_data_type_learning = ArrayOptFirstElem( XQuery( "for $elem in object_data_types where $elem/code='activation_source_learnings' return $elem" ) );

	if ( _temp_task == undefined || 
		( _temp_task != undefined && _temp_task.state_id != 4 && _temp_task.state_id != 2 ) || 
		ignore_passed_tasks_flag == true 
	)
	{
		try
		{
			if ( debugMode == false )
			{
				_course_learning = tools.activate_course_to_person(
					personId,
					newTaskParam.object_id,
					null,
					null,
					null
				);
			}

			if ( custom_data_type_learning != undefined )
			{
				var _tdata = OpenNewDoc( "x-local://wtv/wtv_object_data.xmd" );
				_tdata.TopElem.object_type = 'active_learning';
				_tdata.TopElem.object_data_type_id = custom_data_type_learning.id;
				_tdata.TopElem.code = 'adapt_' + _pdoc.TopElem.code + '_' + _task.id;

				var findActiveLearningElem =  ArrayOptFirstElem( 
					XQuery( 'for $elem in active_learnings where $elem/course_id=' + String( _task.object_id ) + ' and $elem/person_id=' + personId + ' return $elem' ) 
				);

				if ( findActiveLearningElem != undefined )
				{
					_tdata.TopElem.object_id = findActiveLearningElem.id;
				}

				_tdata.TopElem.object_name = newTaskParam.object_id.ForeignElem.name;
				_tdata.BindToDb();
				debugMode == false && _tdata.Save();
				debugMode == true && (
					_text_message += ( " \n " + '���������� ' + _pdoc.TopElem.person_id.ForeignElem.fullname + ' ��� �������� ����� ����, �������� ������: ' + _task.name  )
				);
			}
			else
			{
				//send_alert('������. ��� ������ �������� � ����� "activation_source_learnings" �� ������', _text_message);
				//_text_message += ( '������. ��� ������ �������� � ����� "activation_source_learnings" �� ������ \n' );
			}
		}
		catch( err )
		{
			
		}
	}
	else
	{				
		if ( _temp_task.state_id == 4 || _temp_task.state_id == 2 )
		{
			newTaskParam.status = 'passed';
			debugMode == true && (
				_text_message += ( "\n" + ( '���������� ' + _pdoc.TopElem.person_id.ForeignElem.fullname + ' ��� ��� �������� ���� ' + newTaskParam.object_id.ForeignElem.name + ' �����. ������ ������ ������� �� ' + newTaskParam.status ) )
			);
		}
		else
		{
			newTaskParam.status = 'failed';
			debugMode == true && (
				_text_message += ( "\n" + ( '���������� ' + _pdoc.TopElem.person_id.ForeignElem.fullname + ' ��� ��� �������� ���� ' + newTaskParam.object_id.ForeignElem.name + ' �����. ������ ������ ������� �� ' + newTaskParam.status ) )
			);
		}
	}

	try 
	{
		if ( _course_learning != undefined )
			newTaskParam.active_learning_id = _course_learning.TopElem.Doc.DocID;
	}
	catch ( err ) 
	{
		if ( _course_learning != undefined )
			newTaskParam.active_learning_id = _course_learning;								
	}	
}

function customSetTaskTestLearning( _task, _pdoc, _child, personId , ignore_passed_tasks_flag )
{
	var _test_learning;
	var _temp_task = ArrayOptFirstElem( 
		XQuery( "for $tests in test_learnings where $tests/person_id=" + personId + 
					" and $tests/assessment_id=" + String( _task.object_id ) + " order by $tests/start_usage_date descending return $tests" ) 
	);

	if ( _temp_task == undefined || 
		( _temp_task != undefined && _temp_task.state_id != 4 && _temp_task.state_id != 2 ) || 
		ignore_passed_tasks_flag == true 
	)
	{
		try
		{
			if ( debugMode == false )
			{
				_test_learning = tools.activate_test_to_person(
					personId,	
					_child.object_id,
					null,	
					null,
					null,
					null
				);
			}

			if ( custom_data_type_test_learning != undefined )
			{
				var _tdata = OpenNewDoc( "x-local://wtv/wtv_object_data.xmd" );
				_tdata.TopElem.object_type = 'active_test_learning';
				_tdata.TopElem.object_data_type_id = custom_data_type_test_learning.id;
				_tdata.TopElem.code = 'adapt_' + _pdoc.TopElem.code + '_' + _task.id;
				
				var findActiveTestLearningElem =  ArrayOptFirstElem( 
					XQuery( 'for $elem in active_test_learnings where $elem/assessment_id=' + String( _task.object_id ) + ' and $elem/person_id=' + personId + ' return $elem' ) 
				);

				if ( findActiveTestLearningElem != undefined )
				{
					_tdata.TopElem.object_id = findActiveTestLearningElem.id;
				}

				_tdata.TopElem.object_name = _child.object_id.ForeignElem.title;
				_tdata.BindToDb();
				debugMode == false && _tdata.Save();
				debugMode == true && (
					_text_message += ( " \n " + '���������� ' + _pdoc.TopElem.person_id.ForeignElem.fullname + ' ��� �������� ����� ����, �������� ������: ' + _task.name  )
				);
			}
			else
			{
				//send_alert('������. ��� ������ �������� � ����� "activation_source_test_learnings" �� ������', _text_message);
			}
		}
		catch( err )
		{

		}
	}
	else
	{
		if ( _temp_task.state_id == 4 || _temp_task.state_id == 2 )
		{
			_child.status = 'passed';
			//send_alert('����������� ' + _pdoc.TopElem.person_id.ForeignElem.fullname + ' ��� ��� �������� ���� "' +_child.object_id.ForeignElem.title+'" �����. ������ ������ ������� �� ' + _child.status, _text_message);
		}
		else
		{
			_child.status = 'failed';
			//send_alert('���������� ' + _pdoc.TopElem.person_id.ForeignElem.fullname + ' ��� ��� �������� ���� "' +_child.object_id.ForeignElem.title+'" �����. ������ ������ ������� �� ' + _child.status, _text_message);
		}
	}

	try 
	{
		if ( _test_learning != undefined )
			_child.active_test_learning_id = _test_learning.TopElem.Doc.DocID;
	}
	catch ( err ) 
	{
		if ( _test_learning != undefined )
			_child.active_test_learning_id = _test_learning;
	}
}

function customSetTask( taskTypicalDevProgParam, idTypicalDevProg, newCRdocParam, _all_user_tasks, ignore_passed_tasks_flag ) 
{
	if (  taskTypicalDevProgParam == undefined )
	{
		throw "taskTypicalDevProgParam is undefined";
	}

	if (  idTypicalDevProg == undefined )
	{
		throw "idTypicalDevProg is undefined";
	}

	if (  newCRdocParam == undefined )
	{
		throw "newCRdocParam is undefined";
	}


	var personId = newCRdocParam.TopElem.person_id;
	var newTask = newCRdocParam.TopElem.tasks.AddChild();
	newTask.AssignElem( taskTypicalDevProgParam );

	if ( taskTypicalDevProgParam.parent_task_id != undefined )
	{
		newTask.parent_task_id = taskTypicalDevProgParam.parent_task_id;	
	}		
	else 
	{
		newTask.parent_task_id.Clear();
	}

	newTask.typical_development_program_id = Int( idTypicalDevProg );
	if ( ArrayOptFirstElem( newCRdocParam.TopElem.tutors ) != undefined )
		newTask.tutor_id = ArrayFirstElem( newCRdocParam.TopElem.tutors ).person_id;

	if ( taskTypicalDevProgParam.due_date.HasValue )
		newTask.start_date = DateOffset( newCRdocParam.TopElem.start_date, taskTypicalDevProgParam.due_date * 86400 );

	if ( taskTypicalDevProgParam.duration_days.HasValue )
	{
		if ( newTask.start_date.HasValue )
			newTask.plan_date = DateOffset( newTask.start_date, taskTypicalDevProgParam.duration_days * 86400 );
		else
			newTask.plan_date = DateOffset( newCRdocParam.TopElem.start_date, taskTypicalDevProgParam.duration_days * 86400 );
	}

	if ( taskTypicalDevProgParam.start_edit_days.HasValue )
		newTask.start_edit_date = DateOffset( start_date, taskTypicalDevProgParam.start_edit_days * 86400 );

	var finished_task = ArrayOptFind( 
		_all_user_tasks, 'This.status=="passed" && (Base64Encode(String(This.task_name))=="' + Base64Encode( String( taskTypicalDevProgParam.name ) ) + 
		'" && This.type=="document_learning" && "' + 
		taskTypicalDevProgParam.type + '"=="document_learning" && OptInt(This.object_id)==' + OptInt( taskTypicalDevProgParam.object_id ) + ')'
	); 

	if ( finished_task != undefined )
	{
		if ( ignore_passed_tasks_flag == false )
		{
			newTask.status = finished_task.status;
			debugMode == true && (
				_text_message += ( " \n " + '��������� ' + newCRdocParam.TopElem.person_id.ForeignElem.fullname + ' ��� �������� ������ ' + newTask.name + ' �� ������� ��������� �������� ' + idTypicalDevProg + ' ����� '  )
			);				
		}
	}
	
	
	if ( taskTypicalDevProgParam.auto_appoint_learning )
	{		
		if ( taskTypicalDevProgParam.type == 'learning' )
		{
			customSetTaskLearning( taskTypicalDevProgParam, newCRdocParam, newTask, personId ,ignore_passed_tasks_flag );		
		}		

		if ( taskTypicalDevProgParam.type == 'test_learning' )								//���� ��� ������ - ����
		{
			customSetTaskTestLearning( taskTypicalDevProgParam, newCRdocParam, newTask, personId ,ignore_passed_tasks_flag );
		}
		
	}
	return newTask.id;
}

// ������� ������ ����������
function cancel_adaptation_program( _programDoc )
{
	if ( _programDoc == undefined )
	{
		throw "_programDoc is undefined";
	}

	try
	{
		//alert(_programDoc.TopElem.status + ' status is ' + _programDoc.DocID);
		if ( _programDoc.TopElem.status != 'cancel' && _programDoc.TopElem.status != 'passed' )
		{
			_programDoc.TopElem.status = 'cancel';
			_programDoc.TopElem.custom_elems.ObtainChildByKey( 'extra_status' ).value = 'closed';

			var _cur_tasks = _programDoc.TopElem.tasks;
			var _cur_program_task;
			var _closed_learning;
			var _closed_learningDoc;
			var _closed_test_learning;
			var _closed_test_learningDoc;
			for( _cur_program_task in _cur_tasks )
			{
				try
				{
					if( _cur_program_task.status == 'plan' || _cur_program_task.status == 'active' )
					{
						switch( _cur_program_task.type )
						{
						case 'learning':
							_cur_program_task.status = 'cancel';
							if( OptInt( _cur_program_task.active_learning_id ) != undefined )
							{
								_closed_learning = tools.active_learning_finish( _cur_program_task.active_learning_id );
								if( OptInt( _closed_learning ) != undefined )
								{
									_closed_learningDoc = tools.open_doc( _closed_learning );
									_closed_learningDoc.TopElem.custom_elems.ObtainChildByKey( 'extra_status' ).value = 'closed';
									_closed_learningDoc.TopElem.state_id = 3;
									debugMode == false && _closed_learningDoc.Save();
								}
							}
							break;   
						case 'test_learning': 
							_cur_program_task.status = 'cancel';
							if( OptInt( _cur_program_task.active_test_learning_id ) != undefined )
							{
								_closed_test_learning = tools.active_test_learning_finish( _cur_program_task.active_test_learning_id );
								if( _closed_test_learning != undefined )
								{
									_closed_test_learningDoc = _closed_test_learning;
									_closed_test_learningDoc.TopElem.custom_elems.ObtainChildByKey( 'extra_status' ).value = 'closed';
									_closed_test_learningDoc.TopElem.state_id = 3;
									debugMode == false && _closed_test_learningDoc.Save();
										
									debugMode == false && DeleteDoc ( UrlFromDocID ( OptInt( _cur_program_task.active_test_learning_id ) ), true );
								}
							}
							break;
						case 'document_learning':	
							_cur_program_task.status = 'cancel';
							break;
						default:
							_cur_program_task.status = 'cancel';
							continue;
						}
					}
				}
				catch( i )
				{}
			}
			debugMode == false && _programDoc.Save();
			canceled_programs_count += 1;
			_text_message += " \n " + '������ ��������� ���������: ' + _programDoc.DocID + " " + _programDoc.TopElem.person_id.OptForeignElem.fullname ;
		}
	}
	catch( err )
	{
		alert( 'Error in function cancel_adaptation_program: ' + err );
	}
}

/**
 * �� ���������� ������ ���������� ���� ��������� ����� ������������ � ������� �� ��
 * @param {string} strCollTabNumParam 
 * @returns {string} ��������� ����� ������������
 */
function get_func_boss_code ( strCollTabNumParam )
{
	if ( strCollTabNumParam == undefined || Trim( strCollTabNumParam ) == "" )
	{
		throw "strCollTabNumParam is " + strCollTabNumParam;
	}
	
	var QueryStr = "sql:\
	DECLARE @person_tab_num VARCHAR(14) = '" + strCollTabNumParam + "';\
	\
	SELECt TOP 1\
	PERSON_ID,\
	ASSIGNMENT_NUMBER,\
	PRIMARY_FLAG,\
	JOB_NAME,\
	GROUP_NAME,\
	STARTDATE,\
	ENDDATE,\
	LEFT( CHIEFTABN , LEN(CHIEFTABN)-1 ) as CHIEFTABN\
	FROM rb_boss_staff_managers_assignments boss_staff\
	WHERE CHIEFTABN is not null AND PRIMARY_FLAG = 'Y' AND\
	(GETDATE() BETWEEN STARTDATE and ENDDATE )\
	AND LEFT( ASSIGNMENT_NUMBER , LEN(ASSIGNMENT_NUMBER)-1 ) = @person_tab_num ;\
	";

	var query_res_obj =  ArrayOptFirstElem( XQuery( QueryStr ) );

	if( query_res_obj != undefined )
	{
		return query_res_obj.CHIEFTABN;
	} 
	else 
	{
		return;
	}
}

/**
 * @param {XmlDoc} crDocParam 
 */
function findCRTasks( crDocParam  )
{
	//alert( crElemParam.id );

	if ( crDocParam == undefined )
	{
		throw "crDocParam is undefined";
	}

	var arrResultAllCRTasks = [];
	
	var tasks = ArraySelect( crDocParam.TopElem.tasks, 'This.type=="document_learning" && This.status=="passed"' );//This.type == "task" || 

	if ( tasks == undefined )
	{
		throw "_tasks is undefined";
	}

	var _task;
	var _obj = {};
	var object_id;
	for ( _task in tasks )
	{
		if ( _task.type == "document_learning" )
			object_id = _task.object_id;
		else
			object_id = null;

		_obj = {
			task_id : String( _task.id ),
			task_name : String( _task.name ),
			status : String( _task.status ),
			type : String( _task.type ),
			typical_development_program_id : OptInt( _task.typical_development_program_id ),
			object_id : OptInt( object_id )
		};
		
		arrResultAllCRTasks.push( _obj );
	}

	return arrResultAllCRTasks;
}

/**
 * @param {XmlDoc} crDocParam 
 */
function formArrCRshort( crDocParam  )
{
	//alert( crElemParam.id );

	if ( crDocParam == undefined )
	{
		throw "crDocParam is undefined";
	}

	var arrResultCRshort = [];
	
	var taskDevProgDefined = ArrayOptFind( crDocParam.TopElem.tasks, 'OptInt(This.typical_development_program_id) != undefined' );
	var idTypicalDevProg;
	if( taskDevProgDefined != undefined )
	{
		idTypicalDevProg = taskDevProgDefined.typical_development_program_id;
	}

	var _new_obj = {
		id:OptInt( crDocParam.DocID ),
		start_date:OptDate( crDocParam.TopElem.start_date ),
		typical_development_program_id:OptInt( idTypicalDevProg ),
		status:String( crDocParam.TopElem.status )
	};

	arrResultCRshort.push( _new_obj );
	
	return arrResultCRshort;
}

function findActiveCRforPerson( idTypicalDevProgramParam, _user_cr_arr_short, oCollFireDaysParam )
{
	var ignore_passed_tasks_flag = false;
	var idFoundPersonsCR;
	var result = {
		idFoundPersonsCR: undefined ,
		ignore_passed_tasks_flag: ignore_passed_tasks_flag
	};

	if ( idTypicalDevProgramParam == undefined )
	{
		throw "idTypicalDevProgramParam is undefined";
	}

	if ( _user_cr_arr_short == undefined || _user_cr_arr_short == null )
	{
		return result;
	}

	if ( oCollFireDaysParam == undefined )
	{
		throw "oCollFireDaysParam is undefined";
	}

	var intPersonDaysFired = OptInt( oCollFireDaysParam.DAYS_FIRE );
	var datePersonHire = Date( oCollFireDaysParam.last_DATE_START );
	
	var userCareerReserves = ArraySelect( _user_cr_arr_short,'This.typical_development_program_id==' + idTypicalDevProgramParam + '' );
	var _cr;
	for( _cr in userCareerReserves )
	{
		if ( intPersonDaysFired <= intDismissedDaysAllowed )
		{
			idFoundPersonsCR = _cr.id ;
		}
		else
		{
			if ( ParseDate( _cr.start_date,false,false ) < ParseDate( datePersonHire,false,false ) )
			{
				if ( _cr.status == 'active' || _cr.status == 'plan' )
				{
					ignore_passed_tasks_flag = true;
					_text_message += " \n " + '� ������� ���������� ���������� ' + _cr.id + ' �� ���������� ������ ������ ������ ' + intDismissedDaysAllowed + 
					' ����, ��������� ����� ��������� ��������' ;
				}
			}
			else
			{
				idFoundPersonsCR = _cr.id ;
			}
		}		
	}

	result = {
		idFoundPersonsCR: OptInt ( idFoundPersonsCR ),
		ignore_passed_tasks_flag: ignore_passed_tasks_flag
	};

	return result;	
}

function getPersonPositionExpDays( colElemParam )
{
	if ( colElemParam == undefined )
	{
		throw "colElemParam is " + colElemParam;
	}

	var intResultPersonPositionExpDays;

	if ( colElemParam.is_candidate == true )
	{
		intResultPersonPositionExpDays = 0;
	}
	else
	{
		var oPersonStag = getCollStagByTabNum( colElemParam.code );
		if ( oPersonStag != undefined )
		{
			debugMode == true && (
				_text_message += ( "\n \n " + "stag " + tools.object_to_text( oPersonStag, "json" )  )
			);

			intResultPersonPositionExpDays = Int( oPersonStag.APPOINT_DAYS );
		}
		else
		{
			_text_message += ( "\n \n " + "���� �� �������� " +  intResultPersonPositionExpDays + " � ����������  " + colElemParam.fullname );
		}
	}

	return intResultPersonPositionExpDays;
}

function sendApproveBossNotif( personElemParam, docTypicalDevProgramParam )
{
	var teTypicalDevProgramParam = docTypicalDevProgramParam.TopElem;
	var intPersonPositionExpDays = getPersonPositionExpDays( personElemParam );

	if ( OptInt( intPersonPositionExpDays ) == undefined )
	{
		throw "error getPersonPositionExpDays not defined for col : " + personElemParam.fullname ;
	}
	
	var intExperienceDaysInPostionForTDprogramStart = teTypicalDevProgramParam.custom_elems.ObtainChildByKey( 'experience' ).value;
	
	if( OptInt( intPersonPositionExpDays ) <= OptInt( intExperienceDaysInPostionForTDprogramStart ) )
	{
		throw "info � ���������� : " + personElemParam.fullname + " ( ���� " + intPersonPositionExpDays + ") "  + " ������������ ����� ��� ��������� " + teTypicalDevProgramParam.name ;
	}

	var bossCode = get_func_boss_code( personElemParam.code );
	if ( bossCode == undefined )
	{
		throw "error cant find boss for collCode:" + personElemParam.code ;
	}

	var bossElem = ArrayOptFirstElem( XQuery( "for $elem in collaborators where $elem/code='" + bossCode + "' return $elem" ) );
	if ( bossElem == undefined )
	{
		throw "error cant find boss collaborator bossCode:" + bossCode;
	}

	var oNotifParams = {
		idPerson: Int( personElemParam.id ),
		strPersonFullname: String( personElemParam.fullname ),
		idTypicalDevProgram : Int( docTypicalDevProgramParam.DocID ) ,
		strTypicalDevProgname : String( teTypicalDevProgramParam.name ) ,
	};

	debugMode == false && tools.create_notification( "adpts_sendApproveBossNotif", bossElem.id, tools.object_to_text( oNotifParams, "json" ) );
}

function isCRforCancel( crDocParam , groupTEparam, oCollFireDaysParam )
{
	if ( crDocParam == undefined )
	{
		throw "crDocParam is undefined ";
	}

	if ( oCollFireDaysParam == undefined || oCollFireDaysParam == null )
	{
		throw "oCollFireDaysParam is undefined crId:" + crDocParam.DocID ;
	}

	if ( groupTEparam == undefined )
	{
		throw "groupTEparam is undefined crId:" + crDocParam.DocID ;
	}

	var taskDevProgDefined = ArrayOptFind( crDocParam.TopElem.tasks, 'OptInt(This.typical_development_program_id) != undefined' );
	
	if( taskDevProgDefined == undefined )
	{
		return;
	}

	var typicalDevProgramElem = taskDevProgDefined.typical_development_program_id.OptForeignElem;
	if ( typicalDevProgramElem == undefined || StrContains( typicalDevProgramElem.code,'Retail_show',true ) == false )
	{
		return;
	}

	if( 
		ArrayOptFind(
			groupTEparam.typical_development_programs,
			'This.typical_development_program_id==' + OptInt( taskDevProgDefined.typical_development_program_id ) + '' 
		) == undefined 
	)
	{
		return true;
	}

	var intPersonDaysFired = OptInt( oCollFireDaysParam.DAYS_FIRE );
	var datePersonHire = Date( oCollFireDaysParam.last_DATE_START );
	
	if ( intPersonDaysFired >= intDismissedDaysAllowed )
	{
		if ( ParseDate( crDocParam.TopElem.start_date,false,false ) < ParseDate( datePersonHire,false,false ) && 
												crDocParam.TopElem.status == 'active' || crDocParam.TopElem.status == 'plan'
		)
		{
			return true;
		}
	}

	return false;
}

/**
 * ���������� ������������ ����� retail adapt
 * @param {XQueryResult} xarrGroupsParam 
 */
function updateGroups( xarrGroupsParam )
{
	var _clear_list = true;
	var dynamyc_groupArray = xarrGroupsParam;

	var doc_group;
	for ( _groupElem in dynamyc_groupArray )
	{
		if( _groupElem.is_dynamic != true )
		{
			continue;
		}

		doc_group = OpenDoc( UrlFromDocID( _groupElem.PrimaryKey ) );
		doc_group.TopElem.dynamic_select_person( _clear_list );
		doc_group.Save();
	}
}

updateGroups( xarrGroups );

var _groupElem;
var _groupTE;
var _group_col;
var _xarrPersonCRs;
var _crElem;
var _colElem;
var _tdprogram;
var _resultformArrCRshort;
var _resultFindCRTasks;
var _oCollFireDays;
var _oResult;
var _newCR;
var _docTypicalDevProgram;
var _resultIsCRforCancel;
var _arrPersonsCRs = [];
var _arrAllPersonTasksFromAllCRs = [];
var _crDoc;
for( _groupElem in xarrGroups )
{
	_groupTE = tools.open_doc( _groupElem.id ).TopElem;
	_text_message += '������� ������: (' + _groupTE.code + ') ' +  _groupTE.name + " \n ";

	for( _group_col in _groupTE.collaborators )
	{
		
		if ( OptInt( _group_col.collaborator_id ) == undefined )
		{
			alert( "collaborator_id undefined " );
			continue;
		}

		_colElem = _group_col.collaborator_id.OptForeignElem;

		if ( _colElem == undefined || _colElem.is_dismiss == true )
		{
			alert( "collaborator is_dismissed " + _group_col.collaborator_id );
			continue;
		}

		_oCollFireDays = getCollFireDays( _colElem );

		_xarrPersonCRs = XQuery( "for $obj in career_reserves where $obj/person_id=" + _group_col.collaborator_id + " return $obj" );

		_arrPersonsCRs = [];
		_arrAllPersonTasksFromAllCRs = [];

		for( _crElem in _xarrPersonCRs )
		{
			_crDoc = tools.open_doc( _crElem.id );

			if ( _crDoc == undefined )
			{
				_text_message += "error: cant open _crDoc with crId: " + _crElem.id + " \n ";
				continue;
			}

			_resultFindCRTasks = findCRTasks( _crDoc );
			if ( _resultFindCRTasks != undefined && IsArray( _resultFindCRTasks ) == true )
			{
				_arrAllPersonTasksFromAllCRs = ArrayUnion( _arrAllPersonTasksFromAllCRs, _resultFindCRTasks );
			}

			_resultformArrCRshort = formArrCRshort( _crDoc );
			if ( _resultformArrCRshort != undefined && IsArray( _resultformArrCRshort ) == true )
			{
				_arrPersonsCRs = ArrayUnion( _arrPersonsCRs, _resultformArrCRshort );
			}

			_resultIsCRforCancel = false;
			_resultIsCRforCancel = isCRforCancel( _crDoc, _groupTE,  _oCollFireDays );
			if ( _resultIsCRforCancel == true )
			{
				cancel_adaptation_program( _crDoc );
			}
		}

		//alert( "_all_user_tasks " + _colElem.fullname + " " + tools.array_to_text( _arrAllPersonTasksFromAllCRs, "json" ) );

		for( _tdprogram in _groupTE.typical_development_programs )
		{
			try
			{
				_oResult = findActiveCRforPerson( _tdprogram.typical_development_program_id , _arrPersonsCRs, _oCollFireDays );				
			}
			catch ( error )
			{
				throw "findActiveCRforPerson error for coll: " + _colElem.id + " \n " + error;
			}

			if ( _oResult.idFoundPersonsCR == undefined || _oResult.idFoundPersonsCR == null )
			{
				_docTypicalDevProgram = tools.open_doc( _tdprogram.typical_development_program_id );

				if ( _docTypicalDevProgram.TopElem.custom_elems.ObtainChildByKey( 'is_boss_approve' ).value == "true" )
				{
					try
					{						
						sendApproveBossNotif( _colElem, _docTypicalDevProgram );
					}
					catch ( error )
					{
						_text_message += " \n sendApproveBossNotif : " + error ;
					}	
				}
				else
				{
					try
					{
						_newCR = createAdaptation( 
							_colElem,
							_docTypicalDevProgram,
							_groupTE, 
							_arrAllPersonTasksFromAllCRs, 
							_oResult.ignore_passed_tasks_flag, 
							_position_list 
						);
					}
					catch ( error )
					{
						_text_message += " \n createAdaptation : " + error + " \n  "; 
					}
				}
			}
			else
			{
				//alert( "else " + _colElem.fullname );
			}
		}
	}
	_text_message += '\n������� ������ �����������. \n--------------------------------------------------\n';
}

//������ �������� ���������

var xarrAdaptsOfDismissedColls = XQuery( 'for $c in collaborators, $c_r in career_reserves where $c/id=$c_r/person_id and $c/is_dismiss=true() and ($c_r/status="plan" or $c_r/status="active") return $c_r' );
var _carResDoc;
var _adaptOfDismissedCollElem;
var _typ_dev_prog;
//var _idTypicalDevProg;
var _typicalDevProgramElem;
for( _adaptOfDismissedCollElem in xarrAdaptsOfDismissedColls )
{
	_carResDoc = tools.open_doc( _adaptOfDismissedCollElem.id );
	if ( _carResDoc == undefined )
		continue;

	_typ_dev_prog = ArrayOptFind( _carResDoc.TopElem.tasks, 'OptInt(This.typical_development_program_id) != undefined' );
	//_idTypicalDevProg = '';
	if( _typ_dev_prog == undefined )
	{		
		_text_message += "_typ_dev_prog is undefined " + 
						" for adaptation " + _adaptOfDismissedCollElem.id + _adaptOfDismissedCollElem.person_fullname;
		continue;
	}

	_typicalDevProgramElem = _typ_dev_prog.typical_development_program_id.OptForeignElem;
	if ( _typicalDevProgramElem == undefined )
	{
		_text_message += "_typicalDevProgramElem is undefined " + 
								" for adaptation " + _adaptOfDismissedCollElem.id + _adaptOfDismissedCollElem.person_fullname;
		continue;
	}

	//_idTypicalDevProg = _typ_dev_prog.typical_development_program_id;
	if ( StrContains( _typicalDevProgramElem.code,'Retail_show',true ) )
	{
		cancel_adaptation_program( _carResDoc );	
	}
}

if ( canceled_programs_count > 0 )
{
	//send_alert('�������� �������� � ����� � �����������: ' + canceled_programs_count, _text_message + " \n ", _text_message);
	_text_message += '�������� �������� � ����� � �����������: ' + canceled_programs_count + " \n ";
}

if ( created_new_programs_count > 0 )
{
	//send_alert('������� ����� ��������: ' + created_new_programs_count + '-----------------------------\n', _text_message);
	_text_message += '������� ����� ��������: ' + created_new_programs_count + " \n ";
}

var _is_finished_agnt = tools.start_agent( 6909451324072487056 );

var _admin_group = tools.get_doc_by_key( 'group', 'code', 'Retail_saless_Admin_Test' );
var _admin;
var t;
if( _admin_group != null )
{
	var _admin_groupTE = _admin_group.TopElem;
	var newNotification = OpenNewDoc( "x-local://wtv/wtv_active_notification.xmd" );
	var newNotificationTE = newNotification.TopElem;
	newNotificationTE.is_custom = '1';
	newNotificationTE.status = 'active';
	newNotificationTE.sender.address = 'testMSG@rosbank.ru';
	newNotificationTE.subject = '����� � ���������� ��������� �����������';
	newNotificationTE.body = String( _text_message );
	newNotificationTE.body_type = 'plane';
	
	for( _admin in _admin_groupTE.collaborators )
	{
		_admin_address = _admin.collaborator_id.ForeignElem.email;
		t = newNotificationTE.recipients.AddChild( "recipient" );
		t.address = String( _admin_address );
	}

	newNotificationTE.send_date = Date();
	newNotification.BindToDb();
	newNotification.Save();
}

alert( "fin" );