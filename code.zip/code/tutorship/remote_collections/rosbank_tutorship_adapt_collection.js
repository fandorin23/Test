//�������������� - ���������
/*global
curUserID,
ms_tools,
common,
branch_office_id,
to_id,
oc_id,
dateFrom.
dateTo,
mode,
responseCode,
bShowRights,
doc_id,
bEditableColumns,
COLUMNS
*/

/*
	<wvars>
		<wvar>
			<name>branch_office_id</name>
			<type>integer</type>
			<position>1</position>
		</wvar>
		<wvar>
			<name>to_id</name>
			<type>integer</type>
			<position>2</position>
		</wvar>
		<wvar>
			<name>oc_id</name>
			<type>integer</type>
			<position>3</position>
		</wvar>
		<wvar>
			<name>status</name>
			<type>string</type>
			<position>4</position>
		</wvar>
		<wvar>
			<name>dateFrom</name>
			<type>date</type>
			<position>5</position>
		</wvar>
		<wvar>
			<name>dateTo</name>
			<type>date</type>
			<position>6</position>
		</wvar>
		<wvar>
			<name>mode</name>
			<type>string</type>
			<position>7</position>
		</wvar>
		<wvar>
			<name>responseCode</name>
			<type>string</type>
			<position>8</position>
		</wvar>
		<wvar>
			<name>bShowRights</name>
			<type>bool</type>
			<position>9</position>
		</wvar>
		<wvar>
			<name>doc_id</name>
			<type>integer</type>
			<position>10</position>
		</wvar>
		<wvar>
			<name>bEditableColumns</name>
			<type>bool</type>
			<position>11</position>
		</wvar>
	</wvars>
*/

var COLOR_ALLOWED = "#96ff73";
var COLOR_FORBIDDEN = "#bfbfff";

var docResponseType_TraineeForTutor = tools.get_doc_by_key( "response_type", "code", responseCode );

var exec_time = GetCurTicks();

function fnBuildPRObject( fldPersonnelReserveParam,fldPersonParam )
{
	if ( fldPersonnelReserveParam == undefined )
	{
		throw "fldPersonnelReserveParam is undefined";
	}

	if ( fldPersonParam == undefined )
	{
		throw "fldPersonParam is undefined";
	}

	var oNewElem = {
		'id':fldPersonnelReserveParam.id.Value,
		'person_id':fldPersonParam.id.Value,
		'personnel_id':'',
		'fullname':fldPersonParam.fullname.Value,
		'position_name':fldPersonParam.position_name.Value,
		'position_parent_id':fldPersonParam.position_parent_id.Value,
		'position_parent_name':fldPersonParam.position_parent_name.Value,
		'org_name':fldPersonParam.org_name.Value,
		'status':fldPersonnelReserveParam.status.Value,
		'include_reserve_date':StrDate( fldPersonnelReserveParam.include_reserve_date.Value,false,false ),
		'career_reserve_type_name':'',
		'target_name':'',
		'nomination':'',
		'exclusion_reason':'',
		'obj_name':'pr',
		'obj_type':'personnel_reserve',
		'arrCR':[],
		'iCRCounter':0
	};

	var fldCareerReserveType = fldPersonnelReserveParam.career_reserve_type_id.OptForeignElem;
	if ( fldCareerReserveType != undefined )
	{
		if ( iCareerReserveType != null && iCareerReserveType != fldCareerReserveType.id )
		{
			return null;
		}
		oNewElem.SetProperty( 'career_reserve_type_name',fldCareerReserveType.name.Value );
	}
	else if ( iCareerReserveType != null )
	{
		return null;
	}

	var fldNomination = fldPersonnelReserveParam.nomination_id.OptForeignElem;
	if ( fldNomination != undefined )
	{
		oNewElem.SetProperty( 'nomination',fldNomination.name.Value );
	}

	var fldExclusionReason = fldPersonnelReserveParam.exclusion_reason_id.OptForeignElem;
	if ( fldExclusionReason != undefined )
	{
		oNewElem.SetProperty( 'exclusion_reason',fldExclusionReason.name.Value );
	}
	return oNewElem;
}

function GetTalentPoolObjectsList( iPersonIDParam, bAddFuncSubordinatesParam, bHideDissmissedParam, vBossTypeParam, strCatalogNamesParam, iCareerReserveTypeParam )
{
	var arrResult = [];
	var strWhere = '';
	var iBossTypeID = null;
	var arrCatalogs;
	try
	{
		if ( strCatalogNamesParam != null && strCatalogNamesParam != undefined )
		{
			arrCatalogs = String( strCatalogNamesParam ).split( ';' );
		}
		else
		{
			throw 'no param';
		}
	}
	catch( ex )
	{
		arrCatalogs = String( 'career_reserve;personnel_reserve' ).split( ';' );
	}

	try
	{
		switch ( vBossTypeParam )
		{
		case false:
			strWhere = ' and $elem/is_native=false()';
			break;
		case true:
			strWhere = ' and $elem/is_native=true()';
			break;
		default:
			vBossTypeParam = OptInt( vBossTypeParam,null );
			if ( vBossTypeParam != undefined && vBossTypeParam != null )
			{
				strWhere = ' and $elem/boss_type_id=' + vBossTypeParam;
			}
			else
			{
				if ( Trim( vBossTypeParam ) != '' && vBossTypeParam != null && vBossTypeParam != undefined )
				{
					var fldBossType = ArrayOptFirstElem( XQuery( 'for $elem in boss_types where $elem/code=\'' + vBossTypeParam + '\' return $elem' ) );
					if ( fldBossType != undefined )
					{
						strWhere = ' and $elem/boss_type_id=' + fldBossType.id;
					}
					else
					{
						return [];
					}
				}
			}
		}
	}
	catch( ex )
	{
		vBossTypeParam = null;
	}

	var iCareerReserveType;
	try
	{
		if ( iCareerReserveTypeParam != null && iCareerReserveTypeParam != undefined )
		{
			iCareerReserveType = OptInt( iCareerReserveTypeParam,null );
		}
		else
		{
			throw 'no param';
		}
	}
	catch( ex )
	{
		iCareerReserveType = null;
	}

	var arrSubObjects = XQuery( 'for $elem in talent_pool_func_managers where $elem/person_id=' + iPersonIDParam + strWhere + ' return $elem' );

	if ( bAddFuncSubordinatesParam )
	{
		//bossOrgIDs = getOrgIDsOfBoss(iPersonIDParam);
		//isBossOfOrgs = ArrayCount(bossOrgIDs) > 0;
		
		//if (isBossOfOrgs)
		//	arrSubordinates = get_sub_persons_by_org_id(bossOrgIDs);
		//else
		var arrSubordinates = tools.get_sub_persons_by_func_manager_id( iPersonIDParam,null,vBossTypeParam );		
		
		if ( bHideDissmissedParam )
		{
			arrSubordinates = ArraySelect( arrSubordinates,'This.is_dismiss!=true' );
		}
	}

	var bNoPersonnelReserve = false;
	if ( ArrayOptFind( arrCatalogs,'This==\'personnel_reserve\'' ) == undefined )
	{
		bNoPersonnelReserve = true;
	}

	if ( bNoPersonnelReserve == false )
	{
		var arrPersonnelReserves = QueryCatalogByKeys( 'personnel_reserves','id',ArrayExtract( ArraySelect( arrSubObjects,'This.catalog==\'personnel_reserve\'' ),'object_id' ) );
		if ( bAddFuncSubordinatesParam )
		{
			arrPersonnelReserves = ArrayUnion( arrPersonnelReserves,QueryCatalogByKeys( 'personnel_reserves','person_id',ArrayExtract( arrSubordinates,'id' ) ) );
		}

		arrPersonnelReserves = ArrayUnion( arrPersonnelReserves,XQuery( 'for $elem in personnel_reserves where $elem/person_id=' + iPersonIDParam + ' return $elem' ) );

		if ( iCareerReserveType != null )
		{
			arrPersonnelReserves = ArraySelect( arrPersonnelReserves,'This.career_reserve_type_id==' + iCareerReserveType );
		}
		arrPersonnelReserves = ArraySelectDistinct( arrPersonnelReserves,'This.id' );
	}
	else
	{
		arrPersonnelReserves = [];
	}

	var arrCareerReserves = [];

	if ( ArrayOptFind( arrCatalogs,'This==\'career_reserve\'' ) != undefined )
	{
		arrCareerReserves = QueryCatalogByKeys( 'career_reserves','id',ArrayExtract( ArraySelect( arrSubObjects,'This.catalog==\'career_reserve\'' ),'object_id' ) );
		if ( bAddFuncSubordinatesParam )
		{
			arrCareerReserves = ArrayUnion( arrCareerReserves,QueryCatalogByKeys( 'career_reserves','person_id',ArrayExtract( arrSubordinates,'id' ) ) );
		}
		arrCareerReserves = ArrayUnion( arrCareerReserves,XQuery( 'for $elem in career_reserves where $elem/person_id=' + iPersonIDParam + ' return $elem' ) );
		arrCareerReserves = ArrayUnion( arrCareerReserves,QueryCatalogByKeys( 'career_reserves','id',ArrayExtract( XQuery( 'for $elem in career_reserve_tutors where $elem/tutor_id=' + iPersonIDParam + ' and $elem/tutor_type=\'commission_person\' return $elem' ),'career_reserve_id' ) ) );
		arrCareerReserves = ArraySelectDistinct( arrCareerReserves,'This.id' );
	}
	//alert( "test iPersonIDParam " + iPersonIDParam );
	//alert( "tset00 " + String( ArrayOptFind( arrCatalogs,'This==\'career_reserve\'' ) != undefined ) );
	//alert( "test o0" +  tools.array_to_text( arrCareerReserves, "json" ) );

	var fldPersonnelReserve;
	var fldPerson;
	var curResult;
	for ( fldPersonnelReserve in arrPersonnelReserves )
	{
		fldPerson = fldPersonnelReserve.person_id.OptForeignElem;
		if ( fldPerson == undefined )
		{
			continue;
		}
		
		if ( bHideDissmissedParam && fldPerson.is_dismiss )
		{
			continue;
		}

		curResult = fnBuildPRObject( fldPersonnelReserve, fldPerson );
		if ( curResult == null )
		{
			continue;
		}

		arrResult.push( curResult );		
	}

	/* 	var _arrCRtemp = [];
	var _arrCRIDs = ArrayExtract( ArraySelectDistinct( arrCareerReserves, 'This.person_id' ), 'This.person_id' );
	var _CRID;
	var _person_CR_arr;
	var _person_CR_arr_TEMP;
	var _person_CR;
	var _curDOCUMENT;
	var _tdp;
	var _tdpElem;
	var _minArr;
	for( _CRID in _arrCRIDs )
	{
		_person_CR_arr = ArraySelect( arrCareerReserves, 'This.person_id == ' + _CRID + '' );
		_person_CR_arr_TEMP = [];
		for( _person_CR in _person_CR_arr )
		{
			_curDOCUMENT = tools.open_doc( _person_CR.id );
			if( _curDOCUMENT == undefined )
			{
				continue;
			}

			_tdp = ArrayOptFind( _curDOCUMENT.TopElem.tasks, 'OptInt(This.typical_development_program_id) != undefined' );
			if( _tdp == undefined )
			{
				continue;
			}

			_tdpElem = _tdp.typical_development_program_id.OptForeignElem;
			if( _tdpElem == undefined )
			{
				continue;
			}

			if( !StrContains( _tdpElem.code, 'Retail_show', true ) )
				continue;
			else 
				_person_CR_arr_TEMP.push( _person_CR );			
		}

		_minArr = ArrayOptMin( _person_CR_arr_TEMP, 'This.start_date' );
		if( _minArr != undefined )
		{
			_arrCRtemp.push( _minArr );
		}
	}
	arrCareerReserves = _arrCRtemp; */
	
	var strDefStatus = 'candidate';

	//alert( tools.array_to_text( arrCareerReserves,"arrCareerReserves" ) );

	var fldCareerReserve;
	var oResult;
	for ( fldCareerReserve in arrCareerReserves )
	{
		try
		{
			fldPerson = fldCareerReserve.person_id.OptForeignElem;
			if ( fldPerson == undefined )
			{
				continue;
			}

			if ( bHideDissmissedParam && fldPerson.is_dismiss )
			{
				continue;
			}

			curResult = undefined;
			if ( fldCareerReserve.position_type != 'adaptation' && fldCareerReserve.personnel_reserve_id.HasValue && bNoPersonnelReserve == false )
			{
				fldPersonnelReserve = fldCareerReserve.personnel_reserve_id.OptForeignElem;
				if ( fldPersonnelReserve == undefined )
				{
					continue;
				}

				curResult = ArrayOptFind( arrResult,'This.id==' + fldPersonnelReserve.id.Value );
				if ( curResult == undefined )
				{
					curResult = fnBuildPRObject( fldPersonnelReserve,fldPerson );
					if ( curResult != null )
					{
						arrResult.push( curResult );
					}
					else
					{
						continue;
					}
				}
				
			}

			oResult = {
				'id':fldCareerReserve.id.Value,
				'person_id':fldPerson.id.Value,
				'personnel_id':( curResult == undefined ? '' : curResult.id ),
				'fullname':( curResult != undefined ? '' : fldPerson.fullname.Value ),
				'position_name':( curResult != undefined ? '' : fldPerson.position_name.Value ),
				'position_parent_id':( curResult != undefined ? '' : fldPerson.position_parent_id.Value ),
				'position_parent_name':( curResult != undefined ? '' : fldPerson.position_parent_name.Value ),
				'org_name':( curResult != undefined ? '' : fldPerson.org_name.Value ),
				'nomination':'',
				'exclusion_reason':'',
				'status':( fldCareerReserve.position_type != 'adaptation' ? ( curResult == undefined ? strDefStatus : curResult.status ) : fldCareerReserve.position_type.Value ),
				'stage_status':common.career_reserve_status_types.GetChildByKey( fldCareerReserve.status.Value ).name.Value,
				'include_reserve_date':'',
				'career_reserve_type_name':'',
				'obj_name':'cr',
				'obj_type':'career_reserve',
				'target_name':( fldCareerReserve.position_name.HasValue ? fldCareerReserve.position_name.Value : ms_tools.get_const( 'vaaeb_mess_no_name' ) ),
			};

			if( fldCareerReserve.position_type == 'adaptation' )
			{
				if ( fldCareerReserve.person_position.HasValue )
				{
					oResult.SetProperty( 'target_name',fldCareerReserve.person_position.Value );
				}
				else
				{
					oResult.SetProperty( 'target_name',ms_tools.get_const( 'vcrb_adaptation' ) );
				}
			}

			if ( curResult == undefined )
			{
				arrResult.push( oResult );
			}
			else
			{
				curResult.arrCR.push( oResult );
				curResult.SetProperty( 'iCRCounter',curResult.iCRCounter++ );
			}
			
		}
		catch( ex )
		{
			alert( ex );
		}
	}	
	return arrResult;
}

curUserID = Int( curUserID );
var docBossType_Tutor = tools.get_doc_by_key( "boss_type", "code", "talent_pool_tutor" );
var docBossType_TalentPoolBoss = tools.get_doc_by_key( "boss_type", "code", "career_reserve_rb_boss" );
	
	
function getSubHierarchyXQ( subdivID )
{
	var xSubdivs = XQuery( "for $elem in subdivisions where $elem/id = " + subdivID + " return $elem" );
	xSubdivs = ArrayUnion( xSubdivs, XQuery( "CatalogHierSubset('subdivisions', " + subdivID + ")" ) );
	return xSubdivs;
}

function get_sub_persons_by_org_id( _org_ids )
{
	return QueryCatalogByKeys( 'collaborators', 'org_id', _org_ids );
}
	
function getOrgIDsOfBoss( collID )
{
	var xFuncManagers = XQuery( "for $elem in func_managers where $elem/person_id = " + collID + " and $elem/catalog = 'org' return $elem" );
	if ( ArrayCount( xFuncManagers ) > 0 )
		return ArrayExtract( xFuncManagers, "This.object_id" );
	else
		return [];
}
		
function getCE( teObj, ceName )
{
	try
	{
		return '' + teObj.custom_elems.ObtainChildByKey( ceName ).value;
	}
	catch( e )
	{
		return undefined;
	}
}
	
function getDateOnly( dateStr )
{
	try 
	{
			
		return StrDate( Date( dateStr ), false );
	}
	catch( e ) 
	{
			
		return '';
	}
}
	
function subdivIsTO( subdivName )
{
	return ( StrContains( subdivName, '���������������', true ) && StrContains( subdivName, '����', true ) );
}

function subdivIsOC( subdivName )
{
	return (
		( StrContains( subdivName, '��������������', true ) && StrContains( subdivName, '����', true ) )
			|| (
				StrContains( subdivName, '������������', true )
				&& StrContains( subdivName, '����', true )
				&& !StrContains( subdivName, '������������ ���� "��������������� ����', true )
			)
			|| ( StrContains( subdivName, '�����', true ) && StrContains( subdivName, '������������', true ) )
	);
}
	
function getSubdivsListByPersonID( personID )
{
	try
	{
		var tePerson = OpenDoc( UrlFromDocID( Int( personID ) ) ).TopElem;
		return getAllParentSubdivNames( tePerson.position_parent_id );
	}
	catch( e )
	{
		alert( e );
		return [];
	}
}

function getAllParentSubdivNames( subdivID )
{	
	try
	{
		subdivID = Int( subdivID );
		var teSubdiv = OpenDoc( UrlFromDocID( subdivID ) ).TopElem;
			
		var result = [teSubdiv.name.Value];
		var parentObjectID;
			
		var virtualTO_ID = OptInt( teSubdiv.custom_elems.ObtainChildByKey( "parent_func_div" ).value );
			
		if ( virtualTO_ID != undefined )
			parentObjectID = virtualTO_ID;
		else
			parentObjectID = teSubdiv.parent_object_id;
			
		if ( parentObjectID > 0 )
			result = ArrayUnion( result, getAllParentSubdivNames( parentObjectID ) );
			
		return result;
	}
	catch( e )
	{
		alert( e );
		return [];
	}
}
	
function getTutorID( teReserve )
{
	var tutor = ArrayOptFirstElem( teReserve.tutors );
	if ( tutor == undefined )
		return 0;
			
	return tutor.person_id;
}
	
function removeColumn( columnData )
{
	COLUMNS = ArraySelect( COLUMNS, "This.data != columnData" );
	//setColumnParam(columnData, 'hidden', true);
}
	
function setColumnParam( columnData, paramName, newValue )
{
	var column = ArrayOptFind( COLUMNS, "This.data == columnData" );
	if ( column == undefined )
		return false;
			
	column[paramName] = newValue;
}
	
function collIsCandidate( collID )
{
	try
	{
		var teColl = OpenDoc( UrlFromDocID( Int( collID ) ) ).TopElem;
		return tools_web.is_true( teColl.is_candidate );
	}
	catch( e )
	{
		alert( e );
		return false;
	}
}
	
CACHED_REL_OPERATIONS = [];
function getCachedObjectRelativeOperations( userID, objectID )
{
	objectID = OptInt( objectID );
		
	if ( objectID == undefined )
		return [];

	var cachedData = ArrayOptFind( CACHED_REL_OPERATIONS, "This.object_id == " + objectID );
		
	if ( cachedData != undefined )
		return cachedData.operations;
		
	var operations = tools.get_object_relative_operations( userID, objectID );
		
	CACHED_REL_OPERATIONS.push( {
		object_id: objectID,
		operations: operations
	} );
		
	return operations;
}
	
function getOrgsWithsAllRights( collID )
{
	var xOrg_withAllRights = XQuery( " \
			for \
				$fm in func_managers, \
				$bt in boss_types \
			where \
				$fm/boss_type_id = $bt/id \
				and $fm/person_id = " + collID + " \
				and $fm/catalog = 'org' \
				and MatchSome($bt/code, ('career_reserve_rb_admin', 'career_reserve_rb_empl_mon_retail', 'career_reserve_rb_empl_oper_vertical')) \
			return $fm \
		" );
		
	return xOrg_withAllRights;
}

function formItem( itemTargetParam )
{
	var docColl = tools.open_doc( Int( itemTargetParam.person_id ) );
	if ( docColl == undefined )
	{
		throw "cant open coll :" + itemTargetParam.person_id;
	}
	var teColl = docColl.TopElem;

	var docCarReserve = tools.open_doc( Int( itemTargetParam.id ) );
	if ( docCarReserve == undefined )
	{
		throw "cant open carReserve id: " + itemTargetParam.id;
	}

	var teReserve = docCarReserve.TopElem;
	
	var docPosition = tools.open_doc( Int(  teColl.position_id ) );
	var tePosition;
	if ( docPosition == undefined )
	{
		tePosition = null;
	}
	else
	{
		tePosition = docPosition.TopElem;
	}	
	
	var isCandidate = tools_web.is_true( teColl.is_candidate );
	var isTrainee = !isCandidate;
	
	if ( docBossType_TalentPoolBoss != null )
	{
		var userBoss = ArrayOptFind( teReserve.tutors, "This.boss_type_id == docBossType_TalentPoolBoss.DocID" );	
	}

	/*
	� ������ ���.���������	career_reserve_rb_set_option_material_incentives
	��������� ����������	career_reserve_rb_set_breach_of_discipline
	������� ������������ ������	career_reserve_rb_set_operational_error_level
	KPI ����������	career_reserve_rb_set_kpi
	KPI �������	career_reserve_rb_set_kpi
	*/	
	var orgsWithsAllRights = getOrgsWithsAllRights( curUserID );

	if ( bEditableColumns )
	{	
		var xarrOperations;
		if ( ArrayOptFind( orgsWithsAllRights, "This.object_id == teColl.org_id" ) != undefined )
		{
			xarrOperations = getCachedObjectRelativeOperations( curUserID, teColl.org_id );
			//alert("xarrOperations: "+tools.object_to_text(xarrOperations, "json"));
		}
		else
		{
			xarrOperations = [];
			//xarrOperations = tools.get_object_relative_operations(curUserID, teColl.position_parent_id);
			xarrOperations = getCachedObjectRelativeOperations( curUserID, teColl.position_parent_id );
			
			// ���� ����� �� �� ����� ������.
			//xarrOperations = ArrayUnion(xarrOperations, tools.get_object_relative_operations(curUserID, OptInt(item.id)));
			
			
			
			/* ���������� ��������� � �������������, ���� ��� ������ �� �����.
			if (isCandidate && userBoss != undefined)
			{
				try
				{
					xarrOperations = ArrayUnion(xarrOperations, tools.get_object_relative_operations(curUserID, OptInt(userBoss.person_id)));
					xarrOperations = ArrayUnion(xarrOperations, tools.get_object_relative_operations(curUserID, OptInt(userBoss.person_id.ForeignElem.position_parent_id)));
				}
				catch(e)
				{
					alert(e);
				}
			}
			*/
		}

		var rightSetMaterialIncentives = ( ArrayOptFindByKey( xarrOperations, "career_reserve_rb_set_option_material_incentives", "code" ) != undefined );
		var rightSetBreachOfDiscipline = ( ArrayOptFindByKey( xarrOperations, "career_reserve_rb_set_breach_of_discipline", "code" ) != undefined );
		var rightSetOperationalErrorLevel = ( ArrayOptFindByKey( xarrOperations, "career_reserve_rb_set_operational_error_level", "code" ) != undefined );
		var rightSetKPI = ( ArrayOptFindByKey( xarrOperations, "career_reserve_rb_set_kpi", "code" ) != undefined );
		
		
		if ( rightSetMaterialIncentives ) generalRightSetMaterialIncentives = true;
		if ( rightSetBreachOfDiscipline ) generalRightSetBreachOfDiscipline = true;
		if ( rightSetOperationalErrorLevel ) generalRightSetOperationalErrorLevel = true;
		if ( rightSetKPI ) generalRightSetKPI = true;
		
	}
	else
	{
		rightSetMaterialIncentives = false;
		rightSetBreachOfDiscipline = false;
		rightSetOperationalErrorLevel = false;
		rightSetKPI = false;
	}
	
	
	//alert(item.id+" === "+curUserID);
	//alert("------------------Subdiv-------------"+teColl.fullname);
	//alert(tools.object_to_text(xarrOperations, "json"));
	
	//alert("------------------Reserve-------------"+teColl.fullname);
	//alert(tools.object_to_text(xarrOperations, "json"));
	
	
	/*_userID = 5951642534648687122;
	_subdivID = 5293675553778464388;
	_adaptID = 6330258930316232377;
	
	alert('----------------------------------------');
	alert('----'+teColl.fullname);
	alert(curUserID+" === "+teColl.position_parent_id+" === "+item.id);
	alert("rightSetMaterialIncentives: "+rightSetMaterialIncentives);
	alert("rightSetBreachOfDiscipline: "+rightSetBreachOfDiscipline);
	alert("rightSetOperationalErrorLevel: "+rightSetOperationalErrorLevel);
	alert("rightSetKPI: "+rightSetKPI);
	
	
	
	alert("curUserID: "+curUserID);
	alert("___UserID: "+_userID);
	alert("curUserID == _userID: "+(curUserID == _userID));
	alert("teColl.position_parent_id == _subdivID: "+(teColl.position_parent_id == _subdivID));
	alert("_adaptID == item.id: "+(_adaptID == item.id));*/
	
	/*xarrBossTypes = tools.get_object_relative_boss_types(curUserID, teColl.position_parent_id);
	alert("------------------Subdiv--"+teColl.fullname+"=="+teColl.position_parent_id);
	alert(tools.object_to_text(xarrBossTypes, "json"));
	
	xarrBossTypes = tools.get_object_relative_boss_types(curUserID, item.id);
	alert("------------------Reserve-------------"+teColl.fullname+"=="+item.id);
	alert(tools.object_to_text(xarrBossTypes, "json"));*/	
	
	itemTargetParam.tab_number = teColl.code.Value;

	try
	{
		itemTargetParam.probation_enddate = getDateOnly( getCE( tePosition, 'probation_enddate' ) );
		
		try 
		{
			itemTargetParam.probation_enddate_full = DateNewTime( ParseDate( getCE( tePosition, 'probation_enddate' ) ), 0, 0, 0 );
			//alert("item.probation_enddate_full: "+item.probation_enddate_full);
		}
		catch( e ) 
		{
			itemTargetParam.probation_enddate_full = null;
		}
	}
	catch( e ) 
	{
		alert( e );
	}		
	
	itemTargetParam.position_name = '';
	itemTargetParam.branch_office = '';
	itemTargetParam.to_name = '';
	itemTargetParam.oc_name = '';	
	
	itemTargetParam.boss_name = userBoss != undefined ? userBoss.person_fullname.Value : '';
	itemTargetParam.boss_code = userBoss != undefined ? userBoss.person_code.Value : '';

	if ( docBossType_Tutor != null )
		var userTutor = ArrayOptFind( teReserve.tutors, "This.boss_type_id == docBossType_Tutor.DocID" );
	
	itemTargetParam.tutor_name = userTutor != undefined ? userTutor.person_fullname.Value : '';
	itemTargetParam.tutor_code = userTutor != undefined ? userTutor.person_code.Value : '';
	
	itemTargetParam.option_material_incentives = ( getCE( teReserve, 'option_material_incentives' ) == '��' ? true : false );
	//item.option_material_incentives_color = (rightSetMaterialIncentives ? COLOR_ALLOWED : COLOR_FORBIDDEN);
	itemTargetParam.option_material_incentives_text = getCE( teReserve, 'option_material_incentives' );
	
	itemTargetParam.breach_of_discipline = ( getCE( teReserve, 'breach_of_discipline' ) == '��' ? true : false );
	//item.breach_of_discipline_color = (rightSetBreachOfDiscipline ? COLOR_ALLOWED : COLOR_FORBIDDEN);
	itemTargetParam.breach_of_discipline_text = getCE( teReserve, 'breach_of_discipline' );
	
	itemTargetParam.operational_error_level = ( getCE( teReserve, 'operational_error_level' ) == '��' ? true : false );
	//item.operational_error_level_color = (rightSetOperationalErrorLevel ? COLOR_ALLOWED : COLOR_FORBIDDEN);
	itemTargetParam.operational_error_level_text = getCE( teReserve, 'operational_error_level' );
	
	itemTargetParam.kpi_tutor = StrReplace( getCE( teReserve, 'kpi_tutor' ),".","," );
	//item.kpi_tutor_color = (rightSetKPI ? COLOR_ALLOWED : COLOR_FORBIDDEN);
	
	itemTargetParam.kpi_trainee = StrReplace( getCE( teReserve, 'kpi_trainee' ),".","," );
	//item.kpi_trainee_color = (rightSetKPI ? COLOR_ALLOWED : COLOR_FORBIDDEN);
	
	//item.linecolor = rightSetMaterialIncentives && rightSetBreachOfDiscipline && rightSetOperationalErrorLevel && rightSetKPI ? '' : COLOR_FORBIDDEN;
	
	itemTargetParam.rights = 
		( rightSetMaterialIncentives ? "�" : "-" )
		+ ( rightSetBreachOfDiscipline ? "�" : "-" )
		+ ( rightSetOperationalErrorLevel ? "�" : "-" )
		+ ( rightSetKPI ? "�" : "-" );	
	
	var collSubdivID = 0;	
	
	if ( isTrainee )
	{
		itemTargetParam.position_name = teColl.position_name.Value;
		
		//subdivsListStr = tools.person_list_staff_by_person_id(item.person_id, null, 100, 1, '>>>');
		//subdivsList = subdivsListStr.split('>>>');
		var subdivsList = getSubdivsListByPersonID( itemTargetParam.person_id );
		
		collSubdivID = teColl.position_parent_id;
	}
	else if ( isCandidate )
	{
		
		var commonPosition = getCE( teReserve, 'position_common' );
		if ( commonPosition == '���������� ��������' || commonPosition == '��������� ��������' )
			itemTargetParam.position_name = '��������: ' + commonPosition;
			
		var tutorID = 0;
		var teSubdiv_ofTutor = null;
		
		tutorID = getTutorID( teReserve );
		if ( tutorID == null && userBoss != undefined )
			tutorID = userBoss.person_id;
		
		
		if ( tutorID > 0 )
		{
			//subdivsListStr = tools.person_list_staff_by_person_id(tutorID, null, 100, 1, '>>>');
			//subdivsList = subdivsListStr.split('>>>');
			subdivsList = getSubdivsListByPersonID( tutorID );
			
			try
			{
				var teColl_Tutor = OpenDoc( UrlFromDocID( Int( tutorID ) ) ).TopElem;
				var collSubdivID = teColl_Tutor.position_parent_id;
			}
			catch( e ) 
			{}
		}
		else
		{
			subdivsList = [];
		}
	}	
	
	itemTargetParam.branch_office = ArrayOptFind( subdivsList, "StrContains(This, '������', true)" );
	if ( itemTargetParam.branch_office == undefined )
		itemTargetParam.branch_office = '';
	
	

	itemTargetParam.to_name = ArrayOptFind( subdivsList, "subdivIsTO(This)" );
	if ( itemTargetParam.to_name == undefined )
		itemTargetParam.to_name = '';

	
		
	itemTargetParam.oc_name = ArrayOptFind( subdivsList, "subdivIsOC(This)" );
	if ( itemTargetParam.oc_name == undefined )
		itemTargetParam.oc_name = '';
}

try
{
	modeExcel = ( mode == 'excel' );
	
	bHideDismissed = true;
	bAddFuncSubordinates = true;
	
	try 
	{
			
		bCacheObjects;
	}
	catch( e ) 
	{
			
		bCacheObjects = false;
	}

	var sPrimaryKey = "talent_pool_" + Request.Session.sid;
	var bBuildAgain = false;

	if ( false && bCacheObjects )
	{
		try
		{
			
			arrResult = tools_web.get_user_data( sPrimaryKey ).arrResult;
		}
		catch( ex )
		{
			
			bBuildAgain = true;
		}
	}
	else
	{
		bBuildAgain = true;
	}
	
	var arrResult = [];
	if ( true || bBuildAgain )
	{
		arrResult = GetTalentPoolObjectsList( curUserID, tools_web.is_true( bAddFuncSubordinates ), tools_web.is_true( bHideDismissed ) );
		//alert( "test o " + tools.array_to_text( arrResult, "json" ) );
		//alert("#1 :"+Real(GetCurTicks() - exec_time))

		/* ���������� ��������� � �������������, ���� ��� ������ �� �����.
		subCollIDs = tools.get_sub_person_ids_by_func_manager_id( curUserID );
		XQString = "for $elem in talent_pool_func_managers where $elem/boss_type_id = "+docBossType_TalentPoolBoss.DocID+" and MatchSome($elem/person_id, ("+subCollIDs.join(",")+")) return $elem";

		xTPFuncManagers_TalentPoolBosses = XQuery(XQString);
		
		arrCanidateAdapts = [];
		
		for (xTPFuncManager_TalentPoolBoss in xTPFuncManagers_TalentPoolBosses)
		{
			arrCanidateAdapts = ArrayUnion(arrCanidateAdapts, GetTalentPoolObjectsList(xTPFuncManager_TalentPoolBoss.person_id, false, tools_web.is_true(bHideDismissed), docBossType_TalentPoolBoss.DocID));
		}
		
		arrCanidateAdapts = ArraySelect(arrCanidateAdapts, "collIsCandidate(This.person_id)");
		
		arrResult = ArrayUnion(arrResult, arrCanidateAdapts);
	*/
		//alert("#2 :"+Real(GetCurTicks() - exec_time))				
		
		if ( docResponseType_TraineeForTutor != null )
		{
			var ownAdapts = ArraySelect( arrResult, "OptInt(This.person_id) == OptInt(curUserID)" );
			//alert( "test o111 " + tools.array_to_text( arrResult, "json" ) );

			//alert( "for $elem in responses where $elem/response_type_id = " + docResponseType_TraineeForTutor.DocID + " and MatchSome($elem/object_id, (" + ArrayMerge( ownAdapts, "This.id", "," ) + ")) return $elem" );
			//var xResponses = XQuery( "for $elem in responses where $elem/response_type_id = " + docResponseType_TraineeForTutor.DocID + " and MatchSome($elem/object_id, (" + ArrayMerge( ownAdapts, "This.id", "," ) + ")) return $elem" );
			//arrResult = ArraySelect( arrResult, "ArrayOptFind(xResponses, 'This.object_id == '+This.id) == undefined" );
			//alert( "test o112 " + tools.array_to_text( arrResult, "json" ) );		
		}
	}

	//alert( "arrResult find 11:" + ArrayCount( ArrayOptFind( arrResult, "This.person_id == 6954080162331900862" ) ) );	
	arrResult = ArraySelect( arrResult,"This.status=='adaptation'" );
	arrResult = ArraySelectDistinct( arrResult, "This.id" );
	arrResult = ArraySelect( arrResult,"OptInt(This.person_id) != OptInt(curUserID) || (This.stage_status == '�����������' || This.stage_status == '� ������')" );
	//alert( "arrResult find 22" + ArrayOptFind( arrResult, "This.person_id == 6954080162331900862" ) );

	var filterSubdivID = 0;
	
	if ( oc_id != null )
		filterSubdivID = oc_id;
	else if ( to_id != null )
		filterSubdivID = to_id;
	else if ( branch_office_id != null )
		filterSubdivID = branch_office_id;


	if ( filterSubdivID != 0 )
	{	
		//var xSubdivs = tools.get_sub_hierarchy(filterSubdivID, 'subdivision', 'parent_object_id');
		//alert( "filterSubdivID " + filterSubdivID );
		var xSubdivs = getSubHierarchyXQ( filterSubdivID );

		if ( to_id != null && oc_id == null )
		{
			//var allVirtualOCs = ArrayDirect(XQuery("for $elem in subdivisions where doc-contains($elem/id,'wt_data','[parent_func_div>0~string]') return $elem"));
			//xSubdivs = ArraySelect(xSubdivs, "ArrayOptFind(allVirtualOCs, 'This.id == '+CodeLiteral(This.id)) == undefined");
	
			var curVirtualOCs = XQuery( "for $elem in subdivisions where doc-contains($elem/id,'wt_data','[parent_func_div=" + filterSubdivID + "~string]') return $elem" );
			var _cr;
			var tmp_sub;
			for ( _cr in curVirtualOCs )
			{
				tmp_sub = getSubHierarchyXQ( _cr.id );
				if ( ArrayOptFirstElem( tmp_sub ) != undefined )
				{
					xSubdivs = ArrayUnion( xSubdivs, tmp_sub );
				}
			}
			//alert( "xSubdivs" + tools.array_to_text( xSubdivs , "json" ) );
			//xSubdivs = ArrayUnion(xSubdivs, curVirtualOCs);
		}
		//alert( "arrResult find 0:" + ArrayOptFind( arrResult, "This.person_id == 6954080162331900862" ) );			
		
		arrResult = ArraySelect( arrResult,"ArrayOptFind(xSubdivs, 'This.id == '+CodeLiteral(This.position_parent_id)) != undefined" );
	}
	//alert( "arrResult find 1:" + ArrayOptFind( arrResult, "This.person_id == 6954080162331900862" ) );

	if ( status != '' ) 
	{	
		if( status == 'no_canceled' )
		{
			//alert('���, ����� �������');
			arrResult = ArraySelect( arrResult,"This.stage_status != '�������'" );
		}
		else if( status == 'ended' )
		{
			//alert('������������');
			arrResult = ArraySelect( arrResult,"This.stage_status == '�������� �������' || This.stage_status == '�������� ���������'" );
		}
		else 
		{
			arrResult = ArraySelect( arrResult,"This.stage_status == status" );
		}
	}
	//alert("#4 :"+Real(GetCurTicks() - exec_time))		
	//alert( "arrResult find 23" + ArrayOptFind( arrResult, "This.person_id == 6954080162331900862" ) );
	
	COLUMNS = [{
		title: 'ID',
		data: 'id',
		type: 'string',
		hidden: true,
		ghost: false
	},{
		title: 'obj_type',
		data: 'obj_type',
		type: 'string',
		hidden: true,
		ghost: false
	},{
		title: 'personnel_id',
		data: 'personnel_id',
		type: 'string',
		hidden: true,
		ghost: true
	},{
		title: 'PersonID',
		data: 'person_id',
		type: 'string',
		hidden: true,
		ghost: false
	},{
		title: '�����',
		data: 'rights',
		width: '70',
		type: 'string',
		sortable: true,
		hidden: ( !bShowRights || !bEditableColumns ),
		colorsource: 'linecolor'
	},{
		title: '���.\n�����',
		data: 'tab_number',
		width: '60',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '���',
		data: 'fullname',
		width: '150',
		type: 'link',
		sortable: true,
		colorsource: 'linecolor',
		click: 'OPENWINDOW=view_doc.html?mode=talent_pool_cr_card&doc_id=' + doc_id + '&object_id={id}'
	},{
		title: '� ������\n���.���������',
		data: 'option_material_incentives',
		width: '80',
		type: 'checkbox',
		sortable: true,
		editable: bEditableColumns,
		colorsource: 'linecolor'
	},{
		title: '���������\n����������',
		data: 'breach_of_discipline',
		width: '80',
		type: 'checkbox',
		sortable: true,
		editable: bEditableColumns,
		colorsource: 'linecolor'
	},{
		title: '������� ��-��\n����.������',
		data: 'operational_error_level',
		width: '80',
		type: 'checkbox',
		sortable: true,
		editable: bEditableColumns,
		colorsource: 'linecolor'
	},{
		title: '�������� ����',
		data: 'null',
		width: '150',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: 'KPI\n����������',
		data: 'kpi_tutor',
		width: '55',
		type: 'string',
		sortable: true,
		editable: bEditableColumns,
		colorsource: 'linecolor'
	},{
		title: 'KPI\n�������',
		data: 'kpi_trainee',
		width: '55',
		type: 'string',
		sortable: true,
		editable: bEditableColumns,
		colorsource: 'linecolor'
	},{
		title: '���������\n���. �����',
		data: 'probation_enddate',
		width: '90',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '���������',
		data: 'position_name',
		width: '150',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '������',
		data: 'branch_office',
		width: '150',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '��',
		data: 'to_name',
		width: '250',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '������������ �� (��/��/���)',
		data: 'oc_name',
		width: '250',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '������',
		data: 'stage_status',
		width: '150',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '��� � ������������',
		data: 'boss_code',
		width: '120',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '������������',
		data: 'boss_name',
		width: '150',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '��� � ����������',
		data: 'tutor_code',
		width: '120',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	},{
		title: '���������',
		data: 'tutor_name',
		width: '150',
		type: 'string',
		sortable: true,
		colorsource: 'linecolor'
	}];
	
	if ( filterSubdivID == 0 && false )
		throw '**���������� ������� ��/��/���, �� ��� ������';
	
	
	var generalRightSetMaterialIncentives = false;
	var generalRightSetBreachOfDiscipline = false;
	var generalRightSetOperationalErrorLevel = false;
	var generalRightSetKPI = false;	

	var item;
	for ( item in arrResult )
	{
		
		formItem( item );
	}
	
	if ( dateFrom != null )
	{
		dateFrom = DateNewTime( dateFrom, 0, 0, 0 );
		arrResult = ArraySelect( arrResult,"This.probation_enddate_full != null && dateFrom <= This.probation_enddate_full" );
	}

	if ( dateTo != null )
	{
		dateTo = DateNewTime( dateTo, 23, 59, 59 );
		arrResult = ArraySelect( arrResult,"This.probation_enddate_full != null && This.probation_enddate_full <= dateTo" );
	}
	
	isOwnerOfAllListedItems = ArrayOptFind( arrResult, "OptInt(This.person_id) != OptInt(curUserID)" ) == undefined;
	hasAnyRights = generalRightSetMaterialIncentives || generalRightSetBreachOfDiscipline || generalRightSetOperationalErrorLevel || generalRightSetKPI;
	
	//alert("isOwnerOfAllListedItems: "+isOwnerOfAllListedItems);
	//alert("hasAnyRights: "+hasAnyRights);
	
	if ( isOwnerOfAllListedItems && !hasAnyRights )
	{
		removeColumn( 'option_material_incentives' );
		removeColumn( 'breach_of_discipline' );
		removeColumn( 'operational_error_level' );
		removeColumn( 'kpi_trainee' );
		removeColumn( 'kpi_tutor' );
	}
	else
	{
		if ( !generalRightSetMaterialIncentives || modeExcel )
		{
			setColumnParam( 'option_material_incentives', 'editable', false );
			setColumnParam( 'option_material_incentives', 'type', 'string' );
			setColumnParam( 'option_material_incentives', 'data', 'option_material_incentives_text' );
		}
			
		if ( !generalRightSetBreachOfDiscipline || modeExcel )
		{
			setColumnParam( 'breach_of_discipline', 'editable', false );
			setColumnParam( 'breach_of_discipline', 'type', 'string' );
			setColumnParam( 'breach_of_discipline', 'data', 'breach_of_discipline_text' );
		}
			
		if ( !generalRightSetOperationalErrorLevel || modeExcel )
		{
			setColumnParam( 'operational_error_level', 'editable', false );
			setColumnParam( 'operational_error_level', 'type', 'string' );
			setColumnParam( 'operational_error_level', 'data', 'operational_error_level_text' );
		}
			
		if ( !generalRightSetKPI )
		{
			setColumnParam( 'kpi_trainee', 'editable', false );
			setColumnParam( 'kpi_tutor', 'editable', false );
		}
	}
	
	
	if ( SORT.FIELD == null )
		SORT.FIELD = "fullname";
	/*  	if(Position_list != '' || Position_list != undefined)
		arrResult = ArraySelect(arrResult, "StrContains('"+ String(Position_list) +"' ,This.position_name)");	 */
	RESULT = ArraySort( arrResult, SORT.FIELD, ( ( SORT.DIRECTION == "DESC" ) ? "-" : "+" ) );

//alert("#7 :"+Real(GetCurTicks() - exec_time))		
}
catch( e )
{
	if ( StrBegins( e.message, "**" ) )
		errorMsg = StrRightRangePos( e.message, 2 );
	else
		alert( e );
	
	RESULT = [];
}