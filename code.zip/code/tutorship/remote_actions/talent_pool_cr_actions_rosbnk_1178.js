//talent_pool_cr_actions_rosbnk_1178
//�������� ����� �������� ������� / �������� (rosbnk)
/*global
iObjectId,
sAction,
sSelectedObjects,
sNeedUpdateList,
act_1,
act_2,
act_3,
RESULT,
MESSAGE:writable,
ERROR:writable,
CONTEXT
*/

/*
<wvars>
<wvar>
	<name>iObjectId</name>
	<type>integer</type>
	<position>1</position>
</wvar>
<wvar>
	<name>sAction</name>
	<type>string</type>
	<position>2</position>
</wvar>
<wvar>
	<name>sSelectedObjects</name>
	<type>string</type>
	<position>3</position>
</wvar>
<wvar>
	<name>sNeedUpdateList</name>
	<type>string</type>
	<position>4</position>
</wvar>
<wvar>
	<name>sSetSelectedObjects</name>
	<type>string</type>
	<position>5</position>
</wvar>
<wvar>
	<name>act_1</name>
	<type>string</type>
	<position>6</position>
</wvar>
<wvar>
	<name>act_2</name>
	<type>string</type>
	<position>7</position>
</wvar>
<wvar>
	<name>act_3</name>
	<type>string</type>
	<position>8</position>
</wvar>
</wvars>
*/

var docBossType_Tutor = tools.get_doc_by_key( "boss_type", "code", "talent_pool_tutor" );
var docBossType_TalentPoolBoss = tools.get_doc_by_key( "boss_type", "code", "career_reserve_rb_boss" );

function check_type_boss( str_type_code ) 
{
	var type_elem = ArrayOptFirstElem(
		XQuery(
			"for $elem in boss_types where $elem/code = '" +
        str_type_code +
        "' return $elem"
		)
	);
	
	if ( type_elem != undefined ) 
	{
		return type_elem.id;
	}
	return "0";
}

/**
 * ���������� ��� ��������� ����������
 * @param {string} _positionName
 */
function checkPersonPositionType( _positionName )
{
	_positionName = StrLowerCase( _positionName );
	if(
		( _positionName == "������� ��������� ��������" ||
			_positionName == "������� ��������� ��������" ||
			_positionName == "��������� ��������" 
		) || 
		( _positionName == "������� ���������� ��������" ||
			_positionName == "������� ���������� ��������" ||
			_positionName == "���������� ��������" 
		) ||
		( _positionName == "��������: ���������� ��������" || _positionName == "��������:���������� ��������" )
		||
		( _positionName == "���������� ��������" || 
		_positionName == "������� ���������� ��������" || 
		_positionName == "������� ���������� ��������" 
		)
	)
	{
		return "clientOrCreditManager";
	}
 
	return "otherPosition";
}

function who_is( str_ids ) 
{
	var fn_elem = ArrayOptFirstElem(
		XQuery(
			"for $elem in collaborators where $elem/id = " + str_ids + " return $elem"
		)
	);

	if ( fn_elem != undefined ) 
	{
		return fn_elem.code + ";" + fn_elem.fullname;
	}

	return "";
}

function getRegionID( teCareerReserve )
{
	try
	{
		var regionID = 0;
		var positionID = 0;
		var collID = teCareerReserve.person_id;
		
		var teColl = OpenDoc( UrlFromDocID( Int( collID ) ) ).TopElem;
		
		if ( tools_web.is_true( teColl.is_candidate ) )
		{
			var tpBoss = ArrayOptFind( teCareerReserve.tutors, "This.boss_type_id == docBossType_TalentPoolBoss.DocID" );
			if ( tpBoss != undefined )
			{
				var teColl_tpBoss = OpenDoc( UrlFromDocID( Int( tpBoss.person_id ) ) ).TopElem;
				positionID = teColl_tpBoss.position_id;
			}	
		}
		else
		{
			positionID = teColl.position_id;
		}
		
		var tePosition = OpenDoc( UrlFromDocID( Int( positionID ) ) ).TopElem;
			
		regionID = OptInt( tePosition.custom_elems.ObtainChildByKey( "region" ).value );
		
		if ( regionID == undefined )
			regionID = 0;
		
		return regionID;
	}
	catch( e )
	{
		return 0;
	}
}


function assignTypicalProgram( docCareerReserve, typicalProgramID )
{
	var teCareerReserve  = docCareerReserve.TopElem;
	try
	{	
		var docTypicalProgram = OpenDoc( UrlFromDocID( Int( typicalProgramID ) ) );

		if ( OptInt( teCareerReserve.custom_elems.ObtainChildByKey( "typical_development_program" ).value ) == undefined )
		{
/* 			if( checkPersonPositionType( teCareerReserve.person_id.sd.position_name ) == "clientOrCreditManager" )
			{
				//tools.create_notification("adapt_new_tutor_to_trainee_for_clientOrCreditManager", teCareerReserve.person_id, "", docCareerReserve.DocID);
			}
			else 
			{     
				tools.create_notification( "adapt_new_tutor_to_trainee", teCareerReserve.person_id, "", docCareerReserve.DocID );
			} */

			tools.create_notification("adapt_new_tutor_newAdaptProc", teCareerReserve.person_id, "", docCareerReserve.DocID);
		}
		
		teCareerReserve.custom_elems.ObtainChildByKey( "typical_development_program" ).value = docTypicalProgram.DocID;
		teCareerReserve.custom_elems.ObtainChildByKey( "set_program_date" ).value = Date();
	}
	catch( e )
	{
		alert( e );
	}
}


function applyAssignedTypicalProgram( teCareerReserve )
{
	try
	{	
		var typicalProgramID = Int( teCareerReserve.custom_elems.ObtainChildByKey( "typical_development_program" ).value );
		var teTypicalProgram = OpenDoc( UrlFromDocID( typicalProgramID ) ).TopElem;
		var crTask;
		for ( crTask in teCareerReserve.tasks )
		{
			if ( crTask.PropertyExists( "active_learning_id" ) )
			{
				DeleteOptDoc( crTask.active_learning_id );
			}
			
			if ( crTask.PropertyExists( "active_test_learning_id" ) )
				DeleteOptDoc( crTask.active_test_learning_id );
		}
		
		teCareerReserve.tasks.Clear();
		
		teCareerReserve.start_date = Date();
		
		var regionID = getRegionID( teCareerReserve );
		
		var tpTask;		
		for ( tpTask in teTypicalProgram.tasks )
		{
			setTask( teCareerReserve, tpTask, typicalProgramID, regionID );
		}
		
		try
		{
			var lastTask = teCareerReserve.tasks[ ArrayCount( teCareerReserve.tasks ) - 1 ];
			teCareerReserve.plan_readiness_date = lastTask.plan_date;
		}
		catch( e )
		{
			alert( e );
		}
		
		if ( teCareerReserve.custom_elems.ObtainChildByKey( "products" ).value == "" )
			teCareerReserve.custom_elems.ObtainChildByKey( "products" ).value = teTypicalProgram.custom_elems.ObtainChildByKey( "products" ).value;

	}
	catch( e )
	{
		alert( e );
	}
}

function DeleteOptDoc( docID )
{
	try
	{
		DeleteDoc( UrlFromDocID( Int( docID ) ) );
		return true;
	}
	catch( e )
	{
		return false;
	}
}

function setTask( teCareerReserve, _task, _typical_program_id, regionID )
{
	try
	{	
		var _child = teCareerReserve.tasks.AddChild();
		_child.AssignElem( _task );
		_child.typical_development_program_id = Int( _typical_program_id );
		if ( ArrayCount( teCareerReserve.tutors ) > 0 )
		{
			var tutor = ArrayOptFind( teCareerReserve.tutors, "This.boss_type_id == docBossType_Tutor.DocID" );
			if ( tutor == undefined )
				tutor = ArrayOptFind( teCareerReserve.tutors, "This.boss_type_id == docBossType_TalentPoolBoss.DocID" );
			
			if ( tutor != undefined )
				_child.tutor_id = tutor.person_id;
			
			//_child.tutor_id = ArrayFirstElem(teCareerReserve.tutors).person_id;
		}
		
		if ( _task.due_date.HasValue )
			_child.plan_date = DateOffset_WorkingDaysOnly( teCareerReserve.start_date, _task.due_date, regionID );
		
		if ( _task.auto_appoint_learning )
		{
			if ( _task.type == "learning" )
			{
				var _course_learning = tools.activate_course_to_person( teCareerReserve.person_id, _child.object_id );
				try
				{
					_child.active_learning_id = _course_learning.TopElem.Doc.DocID;
				}
				catch ( err )
				{
					_child.active_learning_id = _course_learning;
				}
			}
			if ( _task.type == "test_learning" )
			{
				var _test_learning = tools.activate_test_to_person( teCareerReserve.person_id, _child.object_id );
				try
				{
					_child.active_test_learning_id = _test_learning.TopElem.Doc.DocID;
				}
				catch ( err )
				{
					_child.active_test_learning_id = _test_learning;
				}
			}
		}
	}
	catch( e )
	{
		alert( e );
	}	
}

var WD_SATURDAY = 6;
var WD_SUNDAY = 0;

function isHoliday( date, xHolidays )
{
	var isHolidayToday = false;
	
	var weekDay = WeekDay( date );
	
	if ( weekDay == WD_SATURDAY || weekDay == WD_SUNDAY )
		isHolidayToday = true;
	
	var xHolidays_Cur = ArraySelect( xHolidays, "DateNewTime(This.date) == DateNewTime(date)" );
	
	if ( ArrayCount( xHolidays_Cur ) > 0 )
	{
		var xHolidays_Cur_Federal = ArraySelect( xHolidays_Cur, "!(This.region > 0)" );
		var xHolidays_Cur_Regional = ArraySelect( xHolidays_Cur, "This.region > 0" );
	
		if ( ArrayOptFind( xHolidays_Cur_Regional, "This.type == '��������'" ) != undefined )
			isHolidayToday = true;
		else if ( ArrayOptFind( xHolidays_Cur_Federal, "This.type == '��������'" ) != undefined )
			isHolidayToday = true;
		
		if ( ArrayOptFind( xHolidays_Cur_Regional, "This.type == '�������'" ) != undefined )
			isHolidayToday = false;
		else if ( ArrayOptFind( xHolidays_Cur_Federal, "This.type == '�������'" ) != undefined )
			isHolidayToday = false;	
	}

	return isHolidayToday;
}

function DateOffset_WorkingDaysOnly( origDate, offsetDays, regionID )
{
	var xHolidays_Federal = [];
	var xHolidays_Regional = [];
	
	xHolidays_Federal = ArrayDirect( XQuery( "for $elem in cc_holidays where $elem/date >= date('" + DateNewTime( origDate ) + "') and $elem/region = '' return $elem" ) );
	
	if ( regionID > 0 )
		xHolidays_Regional = ArrayDirect( XQuery( "for $elem in cc_holidays where $elem/date >= date('" + DateNewTime( origDate ) + "') and $elem/region = " + regionID + " return $elem" ) );
	
	var xHolidays = ArrayUnion( xHolidays_Federal, xHolidays_Regional );
	
	var workingDays = 0;
	var daysCnt = 0;
	var offsetDate;
	
	do
	{
		offsetDate = DateOffset( origDate, daysCnt * 86400 );
		
		if ( !isHoliday( offsetDate, xHolidays ) )
			workingDays++;
		
		daysCnt++;
	}
	while ( workingDays <= offsetDays );
	
	return offsetDate;
}

try
{
	iObjectId = OptInt( iObjectId,null );
	if ( iObjectId == null )
	{
		iObjectId = curObjectID;
	}
	var teCareerReserveID = iObjectId;
	var docCareerReserve = OpenDoc( UrlFromDocID( teCareerReserveID ) );
	var teCareerReserve = docCareerReserve.TopElem;

	RESULT.ResultSet = "";
	RESULT.ResultAction = "";
	RESULT.ResTutIds = "";
	MESSAGE = tools_web.get_web_const( "deystvieneopre", curLngWeb );

	switch( sAction )
	{
	case "set_task_status":
		var oSelected = tools.read_object( sSelectedObjects );
		var oSetSelected = Trim( sSetSelectedObjects );
		var arrTaskIDs = ArrayExtract( oSelected, "id" );

		var iChangedCounter = 0;
		var iTaskID;
		var fldTask;
		for ( iTaskID in arrTaskIDs  )
		{
			try
			{
				fldTask = teCareerReserve.tasks.GetChildByKey( iTaskID );
				if ( fldTask.status != oSetSelected )
				{
					fldTask.status = oSetSelected;
					iChangedCounter++;
				}
			}
			catch( ex )
			{	}
		}

		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		RESULT.ResultAction = sNeedUpdateList;
		MESSAGE = tools_web.get_web_const( "izmenenostatus", curLngWeb ) + ": " + iChangedCounter;
		break;
	case "delete_task":
		oSelected = tools.read_object( sSelectedObjects );
		arrTaskIDs = ArrayExtract( oSelected, "id" );

		var iDeletedCounter = 0;
		for ( iTaskID in arrTaskIDs  )
		{
			try
			{
				teCareerReserve.tasks.DeleteChildByKey( iTaskID );
				iDeletedCounter++;
			}
			catch( ex )
			{

			}

		}

		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		RESULT.ResultAction = sNeedUpdateList;
		MESSAGE = tools_web.get_web_const( "udalenozadach", curLngWeb ) + ": " + iDeletedCounter;
		break;

	case "set_boss_type":
		var iDefaultBossType = ( global_settings.ChildExists( "tutor_boss_type_id" ) ? global_settings.tutor_boss_type_id : null );
		oSelected = tools.read_object( sSelectedObjects );
		oSetSelected = tools.read_object( sSetSelectedObjects );
		var arrPersonIDs = ArrayExtract( oSelected, "id" );
		var iBossTypeID = ArrayOptFirstElem( ArrayExtract( oSetSelected, "id" ) );
		var _child;
		var iPersonID;
		for ( iPersonID in arrPersonIDs  )
		{
			try
			{
				_child = teCareerReserve.tutors.GetChildByKey( Int( iPersonID ) );
				_child.boss_type_id = OptInt( iBossTypeID,null );
			}
			catch( ex )
			{
			}

		}

		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		var arrTutors = tools_web.set_var_eval( "arrManegers", Env.curVars, XQuery( "for $elem in talent_pool_func_managers where $elem/object_id=" + teCareerReserveID + " return $elem" ), "value" );
		var arrBossTypes = tools_web.set_var_eval( "arrBossTypes", Env.curVars, QueryCatalogByKeys( "boss_types", "id", ArrayExtract( arrTutors, "boss_type_id" ) ), "value" );

		RESULT.ResultAction = sNeedUpdateList;
		MESSAGE = tools_web.get_web_const( "spisoknastavni", curLngWeb );
		break;

	case "change_managers":
		// ������ "������ �����������" � ������ "������ �����������"
		// act_1 = 1 - ������ "������ �����������"
		var sType = "";
		if ( act_1 == "1" )
		{
			iDefaultBossType = check_type_boss( "talent_pool_tutor" );
			sType = ";���������";
		}
			
		// act_1 = 2 - ������ "������ �����������"
		if ( act_1 == "2" )
		{
			iDefaultBossType = check_type_boss( "career_reserve_rb_boss" );
			sType = ";������������";
		}
			
		if ( iDefaultBossType == "0" )
		{
			iDefaultBossType = ( global_settings.ChildExists( "tutor_boss_type_id" ) ? global_settings.tutor_boss_type_id : null );
		}

		var coll_check_id = 0;
		oSelected = tools.read_object( sSelectedObjects );
		try
		{
			coll_check_id = OptInt( oSelected.id, 0 );
		}
		catch( err )
		{}

		var is_not_tutor_two = true;
		if ( act_1 == "1" )
		{
			// ��� ������ �������� - ��������� ������ ���������?
			var adapt_elem_ids = ArraySelectDistinct( ArrayExtract( XQuery( "for $elem in career_reserves where $elem/position_type = 'adaptation' and $elem/status='active' return $elem" ), "id" ) ).join( "," );
				
			if ( adapt_elem_ids != "" && coll_check_id != 0 )
			{
				var fn_mn = XQuery( "for $elem in talent_pool_func_managers where MatchSome($elem/object_id, (" + adapt_elem_ids + ")) and $elem/person_id = " + coll_check_id + " and $elem/boss_type_id = " + iDefaultBossType + " return $elem" );

				if ( ArrayCount( fn_mn ) >= 2 )
				{
					ERROR = 1;
					MESSAGE = "��������� ��� �������� ����������� � ���� ����������. ������� ������� ����������.";
					is_not_tutor_two = false;
				}
			}
		}

		if ( is_not_tutor_two )
		{
			if ( act_1 == "2" && coll_check_id != 0 )
			{
				var str_boss = Trim( String( teCareerReserve.custom_elems.ObtainChildByKey( "log_bosses" ).value ) );
				str_boss += ( str_boss != "" ? "\n" : "" ) + Date() + ";" + who_is( coll_check_id ) + sType;
				teCareerReserve.custom_elems.ObtainChildByKey( "log_bosses" ).value = str_boss;
				//tools.create_notification("adapt_new_tutor", coll_check_id, '', teCareerReserve.person_id);
/* 				if( checkPersonPositionType( teCareerReserve.person_id.sd.position_name ) == "clientOrCreditManager" )
				{
					tools.create_notification( "adapt_set_boss_for_clientOrCreditManager", coll_check_id, "", teCareerReserveID );
				}
				else 
				{
					tools.create_notification( "adapt_set_boss", coll_check_id, "", teCareerReserveID );
				} */

				tools.create_notification( "adapt_set_boss_newAdaptProc", coll_check_id, "", teCareerReserveID );
			}
				
			if ( act_1 == "1" && coll_check_id != 0 )
			{
				var str_boss = Trim( String( teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value ) );
				var nast_fio = who_is( coll_check_id );
				str_boss += ( str_boss != "" ? "\n" : "" ) + Date() + ";" + ( ( nast_fio == "" ) ? "��������� �� �����" : ( nast_fio + sType ) );
					
				teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value = str_boss;

				if( checkPersonPositionType( teCareerReserve.person_id.sd.position_name ) == "clientOrCreditManager" )
				{
					tools.create_notification( "adapt_new_tutor_for_clientOrCreditManager", coll_check_id, "", teCareerReserveID );
					tools.create_notification( "adapt_new_tutor_to_trainee_for_clientOrCreditManager", Int( teCareerReserve.person_id ), "", Int( docCareerReserve.DocID ) );
				}
				else 
				{
					tools.create_notification( "adapt_new_tutor", coll_check_id, "", teCareerReserveID );	
				}	
					
				var send_notif = false;
				//if (ArrayOptFind(teCareerReserve.tutors, "String(This.boss_type_id) == String(iDefaultBossType)") != undefined)
				{
					for ( _tsk in teCareerReserve.tasks )
					{
						if ( _tsk.status == "plan" || _tsk.status == "active" )
						{
							_tsk.tutor_id = coll_check_id;
							send_notif = true;
						}
					}
					/*
						if (send_notif)
						{
							tools.create_notification("adapt_rosbnk_1178_1", teCareerReserve.person_id, coll_check_id, teCareerReserveID);	
						}
						*/
				}
			}
				
			if ( act_1 == "1" && coll_check_id == 0 )
			{
				fldTutor = ArrayOptFirstElem( ArraySelect( teCareerReserve.tutors, "This.boss_type_id == check_type_boss('career_reserve_rb_boss')" ) );
				fldPerson = ( fldTutor != undefined ) ? fldTutor.person_id.OptForeignElem : undefined;
					
				str_boss = Trim( String( teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value ) );
				str_boss += ( str_boss != "" ? "\n" : "" ) + Date() + ";" + ( ( fldPerson == undefined ) ? "��������� �� �����" : ( fldPerson.code + ";" + fldTutor.person_fullname + ";������������" ) );
				teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value = str_boss;
					
				if ( fldTutor != undefined )
				{
					for ( _tsk in teCareerReserve.tasks )
					{
						if ( _tsk.status == "plan" || _tsk.status == "active" )
						{
							_tsk.tutor_id = fldTutor.person_id;
							send_notif = true;
						}
					}
				}
			}

			arrPersonIDs = [];
			if ( coll_check_id != 0 )
			{
				_obj = new Object();
				_obj = coll_check_id;
					
				arrPersonIDs[ArrayCount( arrPersonIDs )] = _obj;
			}
				
			//arrPersonIDs = ArrayExtract( oSelected, "id" );
			//arrManagers=ArraySelectAll(teCareerReserve.tutors);
			var arrManagers = ArraySelect( teCareerReserve.tutors, "String(This.boss_type_id) == String(iDefaultBossType)" );
			for ( fldManager in arrManagers )
			{
				if ( ArrayOptFind( arrPersonIDs,"This=='" + fldManager.PrimaryKey + "'" ) == undefined )
				{
					fldManager.Delete();
				}
			}

			for ( iPersonID in arrPersonIDs  )
			{
				try
				{
					_child = teCareerReserve.tutors.GetChildByKey( Int( iPersonID ) );
				}
				catch( ex )
				{
					_child = teCareerReserve.tutors.ObtainChildByKey( Int( iPersonID ) );
					_child.boss_type_id = iDefaultBossType;
					tools.common_filling( "collaborator", _child, Int( iPersonID ) );
				}

			}

			tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
				
			arrTutors = tools_web.set_var_eval( "arrManegers", Env.curVars, XQuery( "for $elem in talent_pool_func_managers where $elem/object_id=" + teCareerReserveID + " return $elem" ), "value" );
			arrBossTypes = tools_web.set_var_eval( "arrBossTypes", Env.curVars, QueryCatalogByKeys( "boss_types", "id", ArrayExtract( arrTutors, "boss_type_id" ) ), "value" );	

			tut_ids = ArraySelectDistinct( ArrayExtract( teCareerReserve.tutors, "person_id" ) ).join( ";" );

			RESULT.ResultAction = sNeedUpdateList;
			RESULT.ResTutIds = tut_ids;
			MESSAGE = tools_web.get_web_const( "spisoknastavni", curLngWeb );
		}
		break;

	case "edit_cr_task":

		CONTEXT = tools.read_object( CONTEXT );
		for ( fldWvarElem in TopElem.wvars )
			CONTEXT.SetProperty( fldWvarElem.name, fldWvarElem.value );

		try
		{
			if ( task_id == "new" )
			{
				throw "new";
			}
			fldTask = teCareerReserve.tasks.GetOptChildByKey( task_id );
		}
		catch( ex )
		{
			fldTask = teCareerReserve.tasks.AddChild();
		}

		var strInitialTaskType = fldTask.type.Value;
		var iInitialTaskID = fldTask.object_id.Value;
		var iInitialTutorID = fldTask.tutor_id.Value;
		var iInitialProcID = fldTask.assessment_appraise_id.Value;
		var iInitialEventID = fldTask.event_id.Value;
		var bTutorAdded = false;

		var strTaskPrefix = "";
		if ( CONTEXT.HasProperty( "field_prefix" ) )
			strTaskPrefix = CONTEXT.GetProperty( "field_prefix"  );

		var arrFields = [ 
			[ "name", "" ], 
			[ "type", "" ],
			[ "status", "" ], 
			[ "plan_date", "Date" ], 
			[ "fact_date", "Date" ], 
			[ "score", "Real" ], 
			[ "desc", "" ], 
			[ "tutor_id", "Int" ], 
			[ "person_comment", "" ], 
			[ "tutor_comment", "" ],
			[ "type_document", "" ],
			[ "competence_id", "Int" ] 
		];

		for ( fldField in arrFields )
		{
			_field_name = fldField[0];
			_field_type = fldField[1];

			strContextFieldName = strTaskPrefix + _field_name;
			if ( CONTEXT.HasProperty( strContextFieldName ) )
				_field_value = CONTEXT.GetProperty( strContextFieldName  );
			else
				continue;

			try
			{
				if ( _field_value == "" )
				{
					fldTask.Child( _field_name ).Value = null;
				}
				else
				{
					switch( _field_type )
					{
					case "Date":
						fldTask.Child( _field_name ).Value = Date( _field_value );
						break;
					case "Real":
						fldTask.Child( _field_name ).Value = Real( _field_value );
						break;
					case "Int":
						fldTask.Child( _field_name ).Value = Int( _field_value );
						break;
					default:
						fldTask.Child( _field_name ).Value = _field_value;
					}
				}
			}
			catch( err )
			{
			}
		}

		if ( CONTEXT.HasProperty( strTaskPrefix + "desc" ) )
			fldTask.desc = tools_web.convert_xhttp_res( CONTEXT.GetProperty( strTaskPrefix + "desc" ), fldTask.desc );


		iCurrentTutorID = fldTask.tutor_id.Value;
		if( iCurrentTutorID != iInitialTutorID )
		{
			if ( fldTask.tutor_id.HasValue )
			{
				if ( teCareerReserve.tutors.GetOptChildByKey( fldTask.tutor_id ) == undefined )
				{
					oNewChild = teCareerReserve.tutors.ObtainChildByKey( fldTask.tutor_id );
					tools.common_filling( "collaborator", oNewChild, fldTask.tutor_id );

					fldTaskTutorType = ArrayOptFirstElem( XQuery( "for $elem in boss_types where $elem/code = 'talent_pool_task_tutor' return $elem" ) );
					oNewChild.boss_type_id = ( fldTaskTutorType != undefined ? fldTaskTutorType.id : null );
					bTutorAdded = true;
				}
			}
			if ( iInitialTutorID != null )
			{

			}
		}


		if ( CONTEXT.HasProperty( strTaskPrefix + fldTask.type + "_object_id" ) )
			fldTask.object_id = CONTEXT.GetProperty( strTaskPrefix + fldTask.type + "_object_id" );
		if ( CONTEXT.HasProperty( strTaskPrefix + fldTask.type + "_assessment_appraise_id" ) )
			fldTask.assessment_appraise_id = CONTEXT.GetProperty( strTaskPrefix + fldTask.type + "_assessment_appraise_id" );
		if ( CONTEXT.HasProperty( strTaskPrefix + fldTask.type + "_event_id" ) )
			fldTask.event_id = CONTEXT.GetProperty( strTaskPrefix + fldTask.type + "_event_id" );

		var bObjectChanged = false;
		if ( strInitialTaskType != fldTask.type )
		{
			bObjectChanged = true;
		}
		else if ( fldTask.type == "document_learning" )
		{
			bObjectChanged = true;
		}
		else
		{
			var iCurrentObjecID = fldTask.object_id.Value;
			if( iCurrentObjecID != iInitialTaskID )
			{
				bObjectChanged = true;
			}
			if ( iInitialProcID != fldTask.assessment_appraise_id.Value )
			{
				bObjectChanged = true;
			}
			if ( iInitialEventID != fldTask.event_id.Value )
			{
				bObjectChanged = true;
			}
		}

		if ( bObjectChanged )
		{
			switch ( fldTask.type )
			{
			case "assessment_appraise":
				fldTask.type_document.Clear();
				fldTask.link_document.Clear();
				fldTask.commission_persons.Clear();
				fldTask.active_test_learning_id.Clear();
				fldTask.active_learning_id.Clear();
				fldTask.event_result_id.Clear();
				fldTask.event_id.Clear();
				fldTask.object_type = "assessment_appraise";
				if ( iInitialProcID != fldTask.assessment_appraise_id.Value )
				{
					fldTask.assessment_appraise_result_id.Clear();
				}
				break;
			case "test_learning":
				fldTask.type_document.Clear();
				fldTask.link_document.Clear();
				fldTask.commission_persons.Clear();
				fldTask.active_learning_id.Clear();
				fldTask.event_result_id.Clear();
				fldTask.event_id.Clear();
				fldTask.assessment_appraise_id.Clear();
				fldTask.assessment_appraise_result_id.Clear();
				fldTask.object_type = "assessment";
				break;
			case "learning":
				fldTask.active_test_learning_id.Clear();
				fldTask.event_result_id.Clear();
				fldTask.event_id.Clear();
				fldTask.assessment_appraise_id.Clear();
				fldTask.assessment_appraise_result_id.Clear();
				fldTask.object_type = "course";
				break;
			case "education_method":
				fldTask.type_document.Clear();
				fldTask.link_document.Clear();
				fldTask.commission_persons.Clear();
				fldTask.assessment_appraise_id.Clear();
				fldTask.assessment_appraise_result_id.Clear();
				fldTask.active_test_learning_id.Clear();
				fldTask.active_learning_id.Clear();
				if ( iInitialEventID != fldTask.event_id.Value )
				{
					fldTask.event_result_id.Clear();
				}
				fldTask.object_type = "education_method";
				break;
			case "document_learning":
				fldTask.assessment_appraise_id.Clear();
				fldTask.assessment_appraise_result_id.Clear();
				fldTask.active_test_learning_id.Clear();
				fldTask.active_learning_id.Clear();
				fldTask.event_result_id.Clear();
				fldTask.event_id.Clear();
				fldTask.commission_persons.Clear();
				if ( fldTask.type_document == "absolute_doc" )
				{
					fldTask.object_id.Clear();
					fldTask.object_type.Clear();

					if ( CONTEXT.HasProperty( strTaskPrefix + fldTask.type + "_" + fldTask.type_document + "_link_document" ) )
						fldTask.link_document = CONTEXT.GetProperty( strTaskPrefix + fldTask.type + "_" + fldTask.type_document + "_link_document" );

				}
				else
				{
					strCatName = fldTask.type_document;
					switch ( strCatName )
					{
					case "portal_doc":
						strCatName = "document";
						break;
					}
					fldTask.object_type = strCatName;
					if ( CONTEXT.HasProperty( strTaskPrefix + fldTask.type + "_" + fldTask.type_document + "_object_id" ) )
						fldTask.object_id = CONTEXT.GetProperty( strTaskPrefix + fldTask.type + "_" + fldTask.type_document + "_object_id" );
				}
				break;
			default:
				fldTask.assessment_appraise_id.Clear();
				fldTask.assessment_appraise_result_id.Clear();
				fldTask.active_test_learning_id.Clear();
				fldTask.active_learning_id.Clear();
				fldTask.event_result_id.Clear();
				fldTask.event_id.Clear();
				fldTask.object_id.Clear();
				fldTask.object_type.Clear();
				fldTask.type_document.Clear();
				fldTask.link_document.Clear();
				fldTask.commission_persons.Clear();

				break;
			}
			RESULT.SuccessActions = "REFRESH";
		}

		if ( fldTask.type == "defence" )
		{
			bHasChanges = false;

			try
			{
				oSelected = tools.read_object( CONTEXT.TempDestinationEditCRCommission );
				arrPersonIDs = ArrayExtract( oSelected, "id" );
				bHasChanges = true;
			}
			catch( ex )
			{
			}

			if ( bHasChanges )
			{
				arrComPersons = ArraySelectAll( fldTask.commission_persons );
				for ( fldComPerson in arrComPersons )
				{
					if ( ArrayOptFind( arrPersonIDs,"This=='" + fldComPerson.PrimaryKey + "'" ) == undefined )
					{
						fldComPerson.Delete();
					}
				}

				for ( iPersonID in arrPersonIDs  )
				{
					try
					{
						_child = fldTask.commission_persons.GetChildByKey( Int( iPersonID ) );
					}
					catch( ex )
					{
						_child = fldTask.commission_persons.ObtainChildByKey( Int( iPersonID ) );
						tools.common_filling( "collaborator", _child, Int( iPersonID ) );
					}

				}
			}

			for ( fldComPerson in fldTask.commission_persons )
			{
				_score_field_form_name = strTaskPrefix + fldComPerson.person_id + "_score";
				_comment_field_form_name = strTaskPrefix + fldComPerson.person_id + "_comment";
				if (  CONTEXT.HasProperty( _score_field_form_name ) && CONTEXT.GetProperty( _score_field_form_name ) != "" )
					fldComPerson.score = Real( CONTEXT.GetProperty( _score_field_form_name ) );
				if (  CONTEXT.HasProperty( _comment_field_form_name ) )
					fldComPerson.comment = CONTEXT.GetProperty( _comment_field_form_name );
			}
			commission_persons_num = ArrayCount( fldTask.commission_persons );
			if ( commission_persons_num != 0 )
				fldTask.score = Real( StrReal( ArraySum( fldTask.commission_persons, "score" ) / Real( commission_persons_num ), 2 ) );
		}

		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );

		if ( bTutorAdded )
		{
			arrTutors = tools_web.set_var_eval( "arrManegers", Env.curVars, XQuery( "for $elem in talent_pool_func_managers where $elem/object_id=" + teCareerReserveID + " return $elem" ), "value" );
			arrBossTypes = tools_web.set_var_eval( "arrBossTypes", Env.curVars, QueryCatalogByKeys( "boss_types", "id", ArrayExtract( arrTutors, "boss_type_id" ) ), "value" );
			RESULT.ResultAction = "CatalogListDataGridCRFuncManagers;";
		}
		RESULT.ResultSet = ArrayMerge( teCareerReserve.tutors,"person_id",";" );
		MESSAGE = tools_web.get_web_const( "zadachasohranena", curLngWeb );
		break;

	case "assign_test":
		try
		{
			fldTask = teCareerReserve.tasks.GetOptChildByKey( task_id );
		}
		catch( ex )
		{
			fldTask = undefined;
		}

		if ( fldTask != undefined )
		{
			if ( !fldTask.active_test_learning_id.HasValue )
			{
				_test_learning = tools.activate_test_to_person( teCareerReserve.person_id, fldTask.object_id );
				try
				{
					fldTask.active_test_learning_id = _test_learning.TopElem.Doc.DocID;
				}
				catch ( err )
				{
					fldTask.active_test_learning_id = _test_learning;
				}
			}


			tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
			MESSAGE = tools_web.get_web_const( "testnaznachen", curLngWeb );
		}
		else
		{
			ERROR = 1;
			MESSAGE = tools_web.get_web_const( "testnenaznachen", curLngWeb );
		}
		break;
	case "assign_course":
		try
		{
			fldTask = teCareerReserve.tasks.GetOptChildByKey( task_id );
		}
		catch( ex )
		{
			fldTask = undefined;
		}

		if ( fldTask != undefined )
		{
			if ( !fldTask.active_learning_id.HasValue )
			{
				_learning = tools.activate_course_to_person( teCareerReserve.person_id, fldTask.object_id );
				try
				{
					fldTask.active_learning_id = _learning.TopElem.Doc.DocID;
				}
				catch ( err )
				{
					fldTask.active_learning_id = _learning;
				}
			}


			tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
			MESSAGE = tools_web.get_web_const( "kursnaznachen", curLngWeb );
		}
		else
		{
			ERROR = 1;
			MESSAGE = tools_web.get_web_const( "kursnenaznachen", curLngWeb );
		}
		break;
	case "assign_event":
		try
		{
			fldTask = teCareerReserve.tasks.GetOptChildByKey( task_id );
		}
		catch( ex )
		{
			fldTask = undefined;
		}

		if ( fldTask != undefined )
		{
			if ( !fldTask.event_result_id.HasValue )
			{
				tools.add_person_to_event( teCareerReserve.person_id, fldTask.event_id, null, null );
				EventResult = ArrayOptFirstElem( XQuery( "for $elem in event_results where $elem/event_id=" + fldTask.event_id + " and $elem/person_id=" + teCareerReserve.person_id + " return $elem" ) );
				if ( EventResult != undefined )
				{
					fldTask.event_result_id = EventResult.id.Value;
				}
				else
				{
					ERROR = 1;
					MESSAGE = tools_web.get_web_const( "sotrudniknedob", curLngWeb );
				}
			}


			tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
			MESSAGE = tools_web.get_web_const( "sotrudnikdobav", curLngWeb );
		}
		else
		{
			ERROR = 1;
			MESSAGE = tools_web.get_web_const( "sotrudniknedob", curLngWeb );
		}
		break;
	case "assign_proc":
		try
		{
			fldTask = teCareerReserve.tasks.GetOptChildByKey( task_id );
		}
		catch( ex )
		{
			fldTask = undefined;
		}

		if ( fldTask != undefined )
		{
			if ( !fldTask.assessment_appraise_result_id.HasValue )
			{
				var bAdded = false;
				try
				{
					docProc = OpenDoc( UrlFromDocID( fldTask.assessment_appraise_id ) );

					if ( ArrayOptFind( docProc.TopElem.auditorys,"person_id==" + teCareerReserve.person_id ) == undefined )
					{
						bCanAdd = true;
						if ( docProc.TopElem.max_auditory.HasValue )
						{
							iCount = ArrayCount( docProc.TopElem.auditorys ) + 1;
							if ( iCount > docProc.TopElem.max_auditory )
							{
								bCanAdd = false;
								ERROR = 1;
								MESSAGE = tools_web.get_web_const( "vproceduruuzhez_2", curLngWeb );
							}
						}

						if ( bCanAdd )
						{
							fldAuditory = docProc.TopElem.auditorys.ObtainChildByKey( teCareerReserve.person_id );
							fldAuditory.person_name = teCareerReserve.person_id.sd.fullname;
							fldAuditory.position_name = teCareerReserve.person_id.sd.position_name;
							docProc.Save();
							bAdded = true;
						}

					}
					else
					{
						bAdded = true;
					}

					if ( bAdded )
					{
						fldTask.assessment_appraise_result_id = fldTask.assessment_appraise_id;
						tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
						MESSAGE = tools_web.get_web_const( "sotrudnikdobav_1", curLngWeb );
					}
				}
				catch( ex )
				{
					alert( ex );
					ERROR = 1;
					MESSAGE = tools_web.get_web_const( "neudalosdobavi", curLngWeb );
				}
			}

		}
		else
		{
			ERROR = 1;
			MESSAGE = tools_web.get_web_const( "neudalosdobavi", curLngWeb );
		}
		break;
		
		
	case "assign_typical_development_program":
		oSelected = tools.read_object( sSelectedObjects );
		typicalProgramID = ArrayOptFirstElem( ArrayExtract( oSelected, "id" ) );
			
		assignTypicalProgram( docCareerReserve, typicalProgramID );
		applyAssignedTypicalProgram( teCareerReserve );
			
		sLog = teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value;
		if( sLog == "" )
		{
			fldTutor = ArrayOptFirstElem( ArraySelect( teCareerReserve.tutors, "This.boss_type_id == check_type_boss('talent_pool_tutor')" ) );
			sType = ";���������";
			if( fldTutor == undefined )
			{
				fldTutor = ArrayOptFirstElem( ArraySelect( teCareerReserve.tutors, "This.boss_type_id == check_type_boss('career_reserve_rb_boss')" ) );
				sType = ";������������";
			}
			fldPerson = ( fldTutor != undefined ) ? fldTutor.person_id.OptForeignElem : undefined;

			teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value = 
					Date() + ";" + ( ( fldPerson == undefined ) ? "��������� �� �����" : ( fldPerson.code + ";" + fldTutor.person_fullname + sType ) );
		}

		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		RESULT.ResultAction = sNeedUpdateList;
		MESSAGE = tools_web.get_web_const( "zadachidobavleny", curLngWeb );
		break;
			
	case "apply_assigned_typical_development_program":
		applyAssignedTypicalProgram( teCareerReserve );
		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		RESULT.ResultAction = sNeedUpdateList;
		MESSAGE = "������ ���������";
		break;

	case "assign_typical_development_program_OLD":
		oSelected = tools.read_object( sSelectedObjects );
		arrTypicalDevProgIDs = ArrayExtract( oSelected, "id" );

		teCareerReserve.tasks.Clear();

		for ( iElemID in arrTypicalDevProgIDs  )
		{
			try
			{
				ProgramDoc = OpenDoc ( UrlFromDocID ( Int( iElemID ) ) ).TopElem;
				for ( _task in ProgramDoc.tasks )
					teCareerReserve.set_task( _task, Int( iElemID )  );
			}
			catch( err )
			{
			}
		}

		sLog = teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value;
		if( sLog == "" )
		{
			fldTutor = ArrayOptFirstElem( ArraySelect( teCareerReserve.tutors, "This.boss_type_id == check_type_boss('talent_pool_tutor')" ) );
			sType = ";���������";
			if( fldTutor == undefined )
			{
				fldTutor = ArrayOptFirstElem( ArraySelect( teCareerReserve.tutors, "This.boss_type_id == check_type_boss('career_reserve_rb_boss')" ) );
				sType = ";������������";
			}
			fldPerson = ( fldTutor != undefined ) ? fldTutor.person_id.OptForeignElem : undefined;

			teCareerReserve.custom_elems.ObtainChildByKey( "log_tutor" ).value = 
					Date() + ";" + ( ( fldPerson == undefined ) ? "��������� �� �����" : ( fldPerson.code + ";" + fldTutor.person_fullname + sType ) );
		}

		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		RESULT.ResultAction = sNeedUpdateList;
		MESSAGE = tools_web.get_web_const( "zadachidobavleny", curLngWeb );
		break;
	case "change_ipr_comp":
		MESSAGE = tools_web.get_web_const( "spisokkompeten", curLngWeb );
		if ( teCareerReserve.development_plan_id.HasValue )
		{
			docPlan = null;
			try
			{
				docPlan = OpenDoc( UrlFromDocID ( teCareerReserve.development_plan_id ) );
			}
			catch( ex )
			{
			}

			if ( docPlan != null )
			{
				oSelected = tools.read_object( sSelectedObjects );
				arrCompIDs = ArrayExtract( oSelected, "id" );

				arrComps = ArraySelectAll( docPlan.TopElem.competences );
				for ( fldComp in arrComps )
				{
					if ( ArrayOptFind( arrCompIDs,"This=='" + fldComp.PrimaryKey + "'" ) == undefined )
					{
						fldComp.Delete();
					}
				}

				for ( iCompID in arrCompIDs )
				{
					try
					{
						docPlan.TopElem.competences.GetChildByKey( Int( iCompID ) );
					}
					catch( ex )
					{
						docPlan.TopElem.competences.ObtainChildByKey( Int( iCompID ) );
					}
				}

				docPlan.Save();
				RESULT.ResultAction = sNeedUpdateList;
				RESULT.ResultSet = ArrayMerge( ArrayExtract( docPlan.TopElem.competences, "competence_id" ), "This", ";" );
				MESSAGE = tools_web.get_web_const( "spisokkompeten_1", curLngWeb );
			}
		}
		break;
	case "create_new_ipr":
		MESSAGE = tools_web.get_web_const( "neudalossozdat", curLngWeb );
		if ( teCareerReserve.current_competence_profile_id.HasValue )
		{
			try
			{
				var currentCompetenceProfileDoc = OpenDoc( UrlFromDocID( teCareerReserve.current_competence_profile_id ) ).TopElem;
			}
			catch( ex )
			{
				throw tools_web.get_web_const( "neudalosotkryt", curLngWeb );
			}
		}

		var docDevelopmentPlan = OpenNewDoc( "x-local://wtv/wtv_development_plan.xmd" );
		docDevelopmentPlan.TopElem.person_id = teCareerReserve.person_id;

		if ( teCareerReserve.target_competence_profile_id.HasValue )
		{

			try
			{
				var targetCompetenceProfileDoc = OpenDoc( UrlFromDocID( teCareerReserve.target_competence_profile_id ) ).TopElem;
			}
			catch( ex )
			{
				throw tools_web.get_web_const( "neudalosotkryt_1", curLngWeb );
			}

			var _terget_competence;
			var _current_competence;
			var competenceDoc;
			var _current_scale;
			for ( _terget_competence in targetCompetenceProfileDoc.competences )
			{
				if ( currentCompetenceProfileDoc != null && currentCompetenceProfileDoc.competences.ChildByKeyExists( _terget_competence.PrimaryKey ) )
				{
					_current_competence = currentCompetenceProfileDoc.competences.GetChildByKey( _terget_competence.PrimaryKey );

					if ( _current_competence.plan != _terget_competence.plan )
					{
						try
						{
							competenceDoc = OpenDoc( UrlFromDocID( _terget_competence.PrimaryKey ) ).TopElem;
						}
						catch( ex )
						{
							continue;
						}
						_current_scale = competenceDoc.scales.GetOptChildByKey( _current_competence.plan );
						_terget_scale = competenceDoc.scales.GetOptChildByKey( _terget_competence.plan );

						if ( _current_scale == undefined || _terget_scale == undefined )
							continue;

						if ( _current_scale.percent.HasValue && _terget_scale.percent.HasValue )
							_create_flag = ( _current_scale.percent < _terget_scale.percent );
						else
							_create_flag = ( _current_scale.ChildIndex < _terget_scale.ChildIndex );

						if ( _create_flag )
							docDevelopmentPlan.TopElem.competences.ObtainChildByKey( _terget_competence.PrimaryKey );
					}
				}
				else
				{
					docDevelopmentPlan.TopElem.competences.ObtainChildByKey( _terget_competence.PrimaryKey );
				}
			}
		}
		else if ( teCareerReserve.current_competence_profile_id.HasValue )
		{
			var fldCurrentCompetence;
			for ( fldCurrentCompetence in currentCompetenceProfileDoc .competences )
			{
				try
				{
					competenceDoc = OpenDoc( UrlFromDocID( fldCurrentCompetence.PrimaryKey ) ).TopElem;
				}
				catch( ex )
				{
					continue;
				}
				docDevelopmentPlan.TopElem.competences.ObtainChildByKey( fldCurrentCompetence.PrimaryKey );
			}
		}

		docDevelopmentPlan.TopElem.career_reserve_id = teCareerReserve.Doc.DocID;
		docDevelopmentPlan.BindToDb( DefaultDb );
		docDevelopmentPlan.Save();

		docCareerReserve.TopElem.development_plan_id = docDevelopmentPlan.DocID;
		tools_web.save_cur_object_doc( docCareerReserve,Request.Session.Env );
		MESSAGE = tools_web.get_web_const( "sozdannovyypla", curLngWeb );
		break;
	}
	//alert('RESULT.ResultAction='+RESULT.ResultAction)
}
catch ( err )
{
	tools.log( "talent_pool_cr_actions.bs: " + err, "error" );
	ERROR = 1;
	MESSAGE = tools_web.get_web_const( "c_error", curLngWeb ) + ": " + err;
}