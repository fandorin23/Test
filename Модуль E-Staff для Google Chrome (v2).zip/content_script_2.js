"use strict";

var info = new Object;
info.actionID = 'HttpRequestResult';
info.url = window.location.href;
info.html = document.body.outerHTML;

chrome.runtime.connect().postMessage( info );

