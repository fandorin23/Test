"use strict";

var		gNativePort;
var		gWebViews = new Object;
var		gLastMsgDate = new Date();
var		gIsOldNativeHost = false;


//alert( 'background.js' );

function OnStartup()
{
	gNativePort = chrome.runtime.connectNative( 'estaff' );
	//alert( 'Port: ' + gNativePort );

	gNativePort.onMessage.addListener( OnNativeMessage );
	gNativePort.onDisconnect.addListener( OnNativeHostDisconnect );

	if ( false )
	{
		var reqObj = new Object;
		reqObj.actionID = 'GetAppInfo';
		reqObj.browserType = 'chrome';

		gNativePort.postMessage( reqObj, OnNativeMessageCallback );
		gLastMsgDate = new Date();
	}
}


function OnContentMsg( info, tabID )
{
	var		reqObj;
	
	if ( info.actionID == 'LoadResumeResult' )
	{
		reqObj = new Object;
		reqObj.actionID = 'LoadResume';
		reqObj.html = info.html;
		reqObj.selHtml = info.selHtml;
		reqObj.url = info.url;

		if ( gIsOldNativeHost )
		{
			chrome.runtime.sendNativeMessage( 'estaff', reqObj, OnNativeMessageCallback );
		}
		else
		{
			gNativePort.postMessage( reqObj, OnNativeMessageCallback );
			gLastMsgDate = new Date();
		}
	}
	else if ( info.actionID == 'HttpRequestResult' )
	{
		var			webView;

		webView = FindWebViewByTabID( tabID );
		if ( webView == undefined )
			return;

		reqObj = new Object;
		reqObj.actionID = 'HttpRequestResult';
		reqObj.webEngineID = webView.webEngineID;
		reqObj.html = info.html;
		reqObj.url = info.url;

		gNativePort.postMessage( reqObj, OnNativeMessageCallback );
	}
}


function OnNativeMessageCallback( response )
{
	if ( response == undefined )
	{
		alert( chrome.i18n.getMessage( 'unable_to_connect_to_native_host' ) + ':\r\n' + chrome.runtime.lastError.message );
		return;
	}

	//alert( response.text );
	//console.log("Received " + response);
}


function OnNativeMessage( msg )
{
	//alert( "OnNativeMessage " + msg );

	if ( msg.actionID == 'HttpRequest' )
		ProcessActionHttpRequest( msg );
	else if ( msg.actionID == 'InjectPageScript' )
		ProcessActionInjectPageScript( msg );
	else if ( msg.actionID == 'GetAppInfoResult' )
		ProcessActionGetAppInfoResult( msg );
	else
		alert( 'Unknown action: ' + msg.actionID );
}


function OnNativeHostDisconnect()
{
	if ( gIsOldNativeHost )
		return;

	//alert( "OnNativeHostDisconnect()" );
	var diff = (new Date()).getTime() - gLastMsgDate.getTime();
	//alert( 'Diff: ' + diff );
	if ( diff < 1000 )
		gIsOldNativeHost = true;
}


function OnTabCreated( tab )
{
	//alert( tab.id );
}


function OnTabClosed( tabID )
{
	var webView = FindWebViewByTabID( tabID );
	if ( webView == undefined )
		return;

	delete gWebViews[webView.webEngineID];
}


function ProcessActionGetAppInfoResult( reqObj )
{
	//alert( JSON.stringify( reqObj ) );
}


function ProcessActionHttpRequest( reqObj )
{
	var		webView;
	
	webView = gWebViews[reqObj.webEngineID];
	if ( webView == undefined )
	{
		webView = new Object;
		webView.webEngineID = reqObj.webEngineID;

		var options = new Object;
		options.active = false;
		options.url = reqObj.url;
	
		chrome.tabs.create( options, function( tab ) {webView.tabID = tab.id} );

		gWebViews[reqObj.webEngineID] = webView;
	}
	else
	{
		webView.curPageLoaded = false;
		chrome.tabs.update( webView.tabID, {url:reqObj.url}, function () {OnHttpRequestCompleted(tabID)} );
	}
}


function OnHttpRequestCompleted( tabID )
{
	//alert( 'OnHttpRequestCompleted' );
}


function ProcessActionInjectPageScript( reqObj )
{
	var		webView;
	
	webView = gWebViews[reqObj.webEngineID];
	if ( webView == undefined )
		return;

	chrome.tabs.executeScript( webView.tabID, {code: reqObj.scriptStr}, function () {OnInjectPageScriptCompleted( webView.tabID )} );
}


function OnInjectPageScriptCompleted( tabID )
{
	var webView = FindWebViewByTabID( tabID );
	if ( webView == undefined )
		return;
	
	var reqObj = new Object;
	reqObj.actionID = 'InjectPageScriptResult';
	reqObj.webEngineID = webView.webEngineID;

	gNativePort.postMessage( reqObj, OnNativeMessageCallback );
}


function OnTabPageLoaded( tabID )
{
	var			webView;

	webView = FindWebViewByTabID( tabID );
	if ( webView == undefined )
		return;
	
	if ( webView.curPageLoaded )
		return;

	webView.curPageLoaded = true;
	chrome.tabs.executeScript( tabID, {file: "content_script_2.js"} );
}


function FindWebViewByTabID( tabID )
{
	var			webView;

	for ( var webEngineID in gWebViews )
	{
		webView = gWebViews[webEngineID];
		if ( webView.tabID == tabID )
			return webView;
	}

	return undefined;
}





chrome.runtime.onStartup.addListener( OnStartup );

  
chrome.runtime.onConnect.addListener(function(port) {
	var tab = port.sender.tab;
	port.onMessage.addListener( function( info ) {OnContentMsg( info, tab.id) } );
});


chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.tabs.executeScript( null, {file: "content_script.js"} );
});


chrome.tabs.onUpdated.addListener(function (tabID , info) {
	if (info.status === 'complete')
		OnTabPageLoaded( tabID );
});


chrome.tabs.onRemoved.addListener(function(tabID, removeInfo ) {
 if ( ! removeInfo.isWindowClosing )
	OnTabClosed( tabID );
})


try
{
	/*chrome.webNavigation.onCompleted.addListener( function( details ) {
		if ( details.frameId != 0 )
			return;
		alert( 'onCompleted: ' + details.url );
	})*/


	if ( true )
	{
		chrome.webNavigation.onDOMContentLoaded.addListener( function( details ) {
			if ( details.frameId != 0 )
				return;
			//alert( 'onDOMContentLoaded: ' + details.url );

			OnTabPageLoaded( details.tabId );
		})
	}
}
catch ( e )
{
	alert( e );
}
