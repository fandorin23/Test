$(function(){
    $('.')
}());